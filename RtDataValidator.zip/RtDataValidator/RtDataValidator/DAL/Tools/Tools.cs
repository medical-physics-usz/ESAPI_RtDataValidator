﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.DAL.Tools
{
    class Tools
    {
        public static string PlanID_2_PlanAbbreviation (string PlanID)
        {
            string temp_out = "";

            if (PlanID.Length >= 9)
            {
                temp_out = PlanID.Substring(0, 2);
            }

            return temp_out;
        }

        public static string PlanID_2_SiteAbbreviation(string PlanID)
        {
            string temp_out = "";

            if (PlanID.Length >= 9)
            {
                temp_out = PlanID.Substring(2, 3);
            }

            return temp_out;
        }

        public static string PlanID_2_PlanVersion(string PlanID)
        {
            string temp_out = "";

            if (PlanID.Length >= 9)
            {
                temp_out = PlanID.Substring(PlanID.Length - 2, 2);

                if (Tools.PlanID_2_IsRevision(PlanID))
                {
                    // this is a revision plan, take one more character
                    temp_out = PlanID.Substring(PlanID.Length - 3, 3);
                }
            }

            return temp_out;
        }

        public static bool PlanID_2_IsRevision(string PlanID)
        {
            bool temp_out = false;

            if (PlanID.EndsWith("1") || PlanID.EndsWith("2") || PlanID.EndsWith("3") || PlanID.EndsWith("4") || PlanID.EndsWith("5") || PlanID.EndsWith("6") || PlanID.EndsWith("7") || PlanID.EndsWith("8") || PlanID.EndsWith("9"))
            {
                // this is a revision plan
                temp_out = true;
            }

            return temp_out;
        }

        public static string PlanID_2_Connector(string PlanID)
        {
            string temp_out = "";

            if (PlanID.Length >= 9)
            {
                temp_out = PlanID.Substring(PlanID.Length - 3, 1);

                if (Tools.PlanID_2_IsRevision(PlanID))
                {
                    // this is a revision plan, go back one more character
                    temp_out = PlanID.Substring(PlanID.Length - 4, 1);
                }
            }

            return temp_out;
        }

        public static string PlanID_2_Volumes(string PlanID)
        {
            string temp_out = "";

            if (PlanID.Length >= 9)
            {
                temp_out = PlanID.Substring(5, PlanID.Length - 8);

                if (Tools.PlanID_2_IsRevision(PlanID))
                {
                    // this is a revision plan, exclude one more character
                    temp_out = PlanID.Substring(5, PlanID.Length - 9);
                }
            }

            return temp_out;
        }


    }
}


