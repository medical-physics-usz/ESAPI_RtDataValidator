﻿using RtDataValidator.BLL;
using RtDataValidator.UIL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the patient db output.
    /// </summary>
    class PatientDbOutput
    {
               
        /// <summary>
        /// Get patient from db.
        /// </summary>
        public Patient GetPatient(string patientIdInput)
        {
            bool isValidPatientId = false;
            bool isValidPatientId2 = false;
           
            PatientQuery qry = new PatientQuery();

            // Test patient id.
            isValidPatientId = qry.IsValidPatientId(patientIdInput, @"SELECT COUNT(1) FROM dbo.Patient WHERE dbo.Patient.PatientId = @patientid");


            if (isValidPatientId == false)
            {
                // Test patient id2.
                isValidPatientId2 = qry.IsValidPatientId(patientIdInput, @"SELECT COUNT(1) FROM dbo.Patient WHERE dbo.Patient.PatientId2 = @patientid");
            }

            Patient patient = new Patient("Unknown", "Unknown", "Unknown", "Unknown", DateTime.MaxValue, PatientSex.Unknown, "Unknown", "Unknown", DateTime.MaxValue, null, "Unknown");

            // Valid patient id.
            if (isValidPatientId)
            {
                // Get patient info.               
                patient = qry.GetPatientInfo(PatientQuery.QueryStringId1, patientIdInput);
            }

            // No valid patient id, but a valid id2.
            if (isValidPatientId2)
            {
                // Get patient info.               
                patient = qry.GetPatientInfo(PatientQuery.QueryStringId2, patientIdInput);

            }

            // No valid patient id, but a valid id2.
            if ((!isValidPatientId) && (!isValidPatientId2))
            {
                // Return invalid patient id to form.
                FormOperations.ISVALIDPATIENT = false;

                MessageBox.Show("Patient ID '" + patientIdInput + "' unknown. Please enter a valid ID!", "Unknown Patient ID", MessageBoxButton.OK,
             MessageBoxImage.Warning);
            }
            else
            {
                // Return valid patient id to form.
                FormOperations.ISVALIDPATIENT = true;
            }
           
            return patient;
        }
    }
}
