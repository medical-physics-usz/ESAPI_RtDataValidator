﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the appointment output.
    /// </summary>
    class AppointmentDbOutput
    {
        /// <summary>
        /// Get appointments.
        /// </summary>
        public List<Appointment> GetAppointments(Patient patient)
        {
            List<Appointment> appointments = new List<Appointment>();

            // Get appointments from db.
            AppointmentQuery qry = new AppointmentQuery();

            appointments = qry.GetAppointments(patient);

            appointments = appointments.Where(a => Appointment.IsStatusOpen(a.ScheduledActivityCode)).ToList();

            return appointments;
        }
    }
}