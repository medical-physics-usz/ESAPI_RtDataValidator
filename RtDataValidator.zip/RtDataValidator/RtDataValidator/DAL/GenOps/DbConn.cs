﻿using RtDataValidator.BLL;
using System;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the database connection.
    /// </summary>
    class DbConn
    {

        private static DbConn instance = null;
        private DbConn() { }
        public static DbConn Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DbConn();
                }
                return instance;
            }
        }

        private SqlConnection conn = null;
        public SqlConnection Connection
        {
            get
            {
                return conn;
            }
        }

        public void OpenConnection()
        {
            conn = new SqlConnection(BLL.Settings.ConnectionString());
            conn.Open();

            using (SqlCommand cmd = new SqlCommand(BLL.Settings.AppRoleCommand(), conn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        public void CloseConnection()
        {
            if (conn != null) conn.Close();
        }

        /// <summary>
        /// Get string value from attribute db.
        /// </summary>
        public static string GetValueQueryString(SqlDataReader reader, int colIndex)
        {
            string stringvalue = "";

            // Try catch block to get the string value.
            if (!reader.IsDBNull(colIndex))
            {
                try
                {
                    stringvalue = reader[colIndex].ToString();
                }
                catch (Exception)
                {
                    throw;
                }
                return stringvalue;
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Get date time value from attribute db.
        /// </summary>
        public static DateTime GetValueQueryDateTime(SqlDataReader reader, int colIndex)
        {
            DateTime datetime = DateTime.MaxValue;

            if (!reader.IsDBNull(colIndex))
            {
                // Try catch block to get the date time value.
                try
                {
                    datetime = (DateTime)reader.GetDateTime(colIndex);
                }
                catch (Exception)
                {
                    throw;
                }
                return datetime;
            }
            else
            {
                return DateTime.MaxValue;
            }
        }

        /// <summary>
        /// Get patient sex value from attribute db.
        /// </summary>
        public static PatientSex GetValueQueryPatientSex(SqlDataReader reader, int colIndex)
        {
            string patsex = "";
            PatientSex patientsex = PatientSex.Unknown;

            if (!reader.IsDBNull(colIndex))
            {
                // Try catch block to get the patient sex value.
                try
                {
                    patsex = reader[colIndex].ToString().Trim();
                    patientsex = (PatientSex)Enum.Parse(typeof(PatientSex), patsex);
                }
                catch (Exception)
                {
                    throw;
                }
                return patientsex;
            }
            else
            {
                return PatientSex.Unknown;
            }
        }

        /// <summary>
        /// Get int value from attribute db.
        /// </summary>
        public static int GetValueQueryInt(SqlDataReader reader, int colIndex)
        {
            int intvalue = 0;

            // Try catch block to get the string value.
            if (!reader.IsDBNull(colIndex))
            {
                try
                {
                    string input = reader[colIndex].ToString().Trim();

                    int temp;
                    if (int.TryParse(input, out temp))
                    {
                        intvalue = temp;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return intvalue;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Get long value from attribute db.
        /// </summary>
        public static long GetValueQueryLong(SqlDataReader reader, int colIndex)
        {
            long longvalue = 0;

            // Try catch block to get the string value.
            if (!reader.IsDBNull(colIndex))
            {
                try
                {
                    string input = reader[colIndex].ToString().Trim();

                    long temp;
                    if (long.TryParse(input, out temp))
                    {
                        longvalue = temp;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return longvalue;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Get double value from attribute db.
        /// </summary>
        public static double GetValueQueryDouble(SqlDataReader reader, int colIndex)
        {
            double doublevalue = 0d;

            // Try catch block to get the string value.
            if (!reader.IsDBNull(colIndex))
            {
                try
                {
                    string input = reader[colIndex].ToString().Trim();

                    double temp;
                    if (double.TryParse(input, out temp))
                    {
                        doublevalue = temp;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return doublevalue;
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Get double value from attribute db.
        /// </summary>
        public static byte[] GetValueQueryBytes(SqlDataReader reader, int colIndex, int size)
        {
            if (!reader.IsDBNull(colIndex))
            {
                byte[] buffer = new byte[size];
                reader.GetBytes(colIndex, 0, buffer, 0, size);
                return buffer;
            }
            else
            {
                return null;
            }
        }
    }
}