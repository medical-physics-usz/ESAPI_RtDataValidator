﻿using RtDataValidator.BLL;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the external field dosimetry query.
    /// </summary>
    class ExternalFieldDosimetryQuery
    {
        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
  SELECT 
dbo.Radiation.RadiationId, 
dbo.EnergyMode.Energy,
dbo.EnergyMode.RadiationType,
dbo.ExternalField.DoseRate,
dbo.vv_syFieldMU.MU,
dbo.Technique.TechniqueId,  
dbo.AddOn.AddOnId,
dbo.ExternalFieldCommon.SourceFieldEntryDistance,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,
dbo.PlanSetup.PlanSetupId, 
dbo.RTPlan.NoFractions,
dbo.RTPlan.PrescribedDose,
dbo.PlanSetup.Status,
dbo.PlanSetup.TreatmentOrientation,
dbo.PlanSetup.CalcModelOptions,
dbo.PlanSetup.CreationDate,
dbo.PlanSetup.PlanSetupName,
dbo.PlanSetup.Intent
    FROM dbo.Course,   
         dbo.Patient,   
         dbo.PlanSetup,   
         dbo.vv_syFieldMU,   
         dbo.Radiation,   
         dbo.ExternalFieldCommon,   
         dbo.Technique,   
         dbo.EnergyMode,
dbo.ExternalField,
dbo.FieldAddOn,   
         dbo.AddOn,
dbo.RTPlan  
   WHERE (dbo.vv_syFieldMU.RadiationSer = dbo.Radiation.RadiationSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND  
         (dbo.PlanSetup.CourseSer = dbo.Course.CourseSer) AND  
         (dbo.Radiation.RadiationSer = dbo.ExternalFieldCommon.RadiationSer) AND  
(dbo.PlanSetup.PlanSetupSer = dbo.vv_syFieldMU.PlanSetupSer) AND
 (dbo.PlanSetup.PlanSetupSer = dbo.RTPlan.PlanSetupSer) AND
         (dbo.Technique.TechniqueSer = dbo.ExternalFieldCommon.TechniqueSer) AND  
         (dbo.EnergyMode.EnergyModeSer = dbo.ExternalFieldCommon.EnergyModeSer) AND 
 (dbo.Radiation.RadiationSer = dbo.ExternalField.RadiationSer) AND   
  (dbo.ExternalField.RadiationSer = dbo.FieldAddOn.RadiationSer) AND  
         (dbo.AddOn.AddOnSer = dbo.FieldAddOn.AddOnSer) AND  
         (dbo.ExternalFieldCommon.SetupFieldFlag = 0) AND  
         (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND
         (upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND  
         (dbo.Patient.PatientId = @patientid)     
ORDER BY dbo.PlanSetup.PlanSetupId ASC,   
         dbo.Technique.TechniqueId ASC";
            }
        }

        /// <summary>
        /// Get treatment external fields from the database.
        /// </summary>
        public List<ExternalField> GetExternalFields(Patient patient)
        {
            // Create list with external fields.
            List<ExternalField> externalfields = new List<ExternalField>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string radiationId = DbConn.GetValueQueryString(rdr, 0);
                    double energy = DbConn.GetValueQueryDouble(rdr, 1);
                    string radiationType = DbConn.GetValueQueryString(rdr, 2).Trim();
                    int doseRate = DbConn.GetValueQueryInt(rdr, 3);
                    double monitorUnits = DbConn.GetValueQueryDouble(rdr, 4);
                    string techniqueId = DbConn.GetValueQueryString(rdr, 5).Trim();
                    string addOnType = DbConn.GetValueQueryString(rdr, 6).Trim();
                    double ssd = DbConn.GetValueQueryDouble(rdr, 7);
                    string courseId = DbConn.GetValueQueryString(rdr, 8);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 9);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 10);
                    int noFractions = DbConn.GetValueQueryInt(rdr, 11);
                    double prescribedDose = DbConn.GetValueQueryDouble(rdr, 12);
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 13).Trim();
                    string treatmentOrientation = DbConn.GetValueQueryString(rdr, 14).Trim();
                    string calcModelOptions = DbConn.GetValueQueryString(rdr, 15).Trim();
                    DateTime creationDate = DbConn.GetValueQueryDateTime(rdr, 16);
                    string Name = DbConn.GetValueQueryString(rdr, 17);
                    string planIntent = DbConn.GetValueQueryString(rdr, 18);

                    // Create object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, noFractions, prescribedDose, planSetupStatus, treatmentOrientation, calcModelOptions, creationDate, Name, planIntent);

                    ExternalField externalfield = new ExternalField(radiationId, energy, radiationType, doseRate, monitorUnits, techniqueId, addOnType, ssd, plan);

                    externalfields.Add(externalfield);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            // initialize dictionary (Key, List<ExternalField) with empty lists
            Dictionary<Tuple<long, string>, List<ExternalField>> map = new Dictionary<Tuple<long, string>, List<ExternalField>>();
            externalfields.ForEach(e => map[new Tuple<long, string>(e.Plan.PlanSetupSer, e.RadiationId)] = new List<ExternalField>());
            // distribute externalFields in dictionary according to key
            externalfields.ForEach(e => map[new Tuple<long, string>(e.Plan.PlanSetupSer, e.RadiationId)].Add(e));

            List<ExternalField> externalfieldsfinal = new List<ExternalField>();

            // for each key, keep only one ExternalField entry such that: AddOnType == FFF,EDW* or null
            foreach (Tuple<long, string> key in map.Keys) {
                List<ExternalField> fields = map[key];

                ExternalField field = fields.FirstOrDefault(e => (e.AddOnType.Equals("FFF") || e.AddOnType.StartsWith("EDW")));
                if (field != null)
                {
                    externalfieldsfinal.Add(field);
                }
                else
                {
                    field = fields.ElementAt(0);
                    field.AddOnType = "";
                    externalfieldsfinal.Add(field);
                }
            }
            return externalfieldsfinal;
        }
    }
}
