﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the structure query.
    /// </summary>
    class StructureQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @" 
  SELECT DISTINCT dbo.Structure.StructureId,   
         dbo.Structure.Status,
dbo.Structure.StatusUserName,
 dbo.Structure.VolumeTypeSer,  
dbo.Course.CourseId,  
dbo.PlanSetup.PlanSetupSer,
         dbo.PlanSetup.PlanSetupId,   
         dbo.PlanSetup.Status,
dbo.Structure.MaterialCTValue,
dbo.Structure.StructureSer,
dbo.Structure.FileName
    FROM dbo.PatientVolume,   
         dbo.Course,   
         dbo.PlanSetup,   
         dbo.Structure,   
         dbo.StructureSet,   
         dbo.VolumeType,   
         dbo.Patient  
   WHERE
         (dbo.StructureSet.StructureSetSer = dbo.Structure.StructureSetSer) AND  
         (dbo.StructureSet.StructureSetSer = dbo.PlanSetup.StructureSetSer) AND  
         (dbo.Course.CourseSer = dbo.PlanSetup.CourseSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND 
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'QA%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'KV[_]%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'CBCT[_]%') AND  
         (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND  
         (dbo.Patient.PatientId = @patientid)   
ORDER BY dbo.Structure.StructureId ASC ";
            }
        }

        /// <summary>
        /// Get structure information from the database.
        /// </summary>
        public List<Structure> GetStructures(Patient patient)
        {
            // Create list with structures.
            List<Structure> structures = new List<Structure>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    string structureId = DbConn.GetValueQueryString(rdr, 0);      
                    string structureStatus = DbConn.GetValueQueryString(rdr, 1).Trim();
                    string statusUserName = DbConn.GetValueQueryString(rdr, 2).Trim();
                    string volumeTypeSer = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string courseId = DbConn.GetValueQueryString(rdr, 4); 
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 5);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 6).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 7).Trim();
                    string MaterialCTValue = DbConn.GetValueQueryString(rdr, 8).Trim();
                    string structureSer = DbConn.GetValueQueryString(rdr, 9).Trim();
                    string fileName = DbConn.GetValueQueryString(rdr, 10).Trim();

                    // assign the correct type to PTV and GTV from their VolumeTypeSer
                    string volumeType = "not_retreived";
                    if (volumeTypeSer.Equals("4")) { volumeType = "PTV"; }
                    if (volumeTypeSer.Equals("3")) { volumeType = "CTV"; }
                    if (volumeTypeSer.Equals("2")) { volumeType = "GTV"; }


                    // read the file containing the info on the structure to find out if it is high resolution or standard resolution (do it only for target volumes)
                    string resString = "na";
                    if (volumeTypeSer.Equals("2") || volumeTypeSer.Equals("3") || volumeTypeSer.Equals("4"))
                    {
                        // prefix depending on folder where data was saved and byte from where to start reading
                        string filePrefix = @"\\vm-90660\va_data$\IMAGEDIR6\";
                        int posRes = 0;
                        if (fileName.StartsWith("%%imagedir1")) { filePrefix = @"\\vm-90660\va_data$\"; posRes = 47; } // not-tested
                        if (fileName.StartsWith("%%imagedir2")) { filePrefix = @"\\vm-90660\va_data$\Filedata1\"; posRes = 47; } // not-tested
                        if (fileName.StartsWith("%%imagedir3")) { filePrefix = @"\\vm-90660\Filedata2$\"; posRes = 47; } // tested
                        if (fileName.StartsWith("%%imagedir4")) { filePrefix = @"\\vm-90660\Filedata4$\"; posRes = 47; } // tested
                        if (fileName.StartsWith("%%imagedir5")) { filePrefix = @"\\vm-90660\filedata5$\"; posRes = 47; } // tested
                        if (fileName.StartsWith("%%imagedir6")) { filePrefix = @"\\vm-90660\va_data$\IMAGEDIR6\"; posRes = 47; } // tested

                        // when it updates to a new imagedir, check the absolute path in eclipse > help > About external beam planning > More info > Image directories

                        // crop filename from SQL database and add prefix
                        fileName = fileName.Substring(fileName.IndexOf("Patients"));
                        fileName = filePrefix + fileName;

                        // read byte by byte and crop the beginning until the point where the resolution is saved (manually found by looking at the files)
                        byte[] fileBytes = null;
                        try
                        {
                            fileBytes = System.IO.File.ReadAllBytes(fileName);
                            Array.Copy(fileBytes, posRes, fileBytes, 0, 5);
                            resString = System.Text.Encoding.Default.GetString(fileBytes);

                        } catch (Exception e)
                        {
                           // System.Windows.Forms.MessageBox.Show(e.ToString());  // used to debug
                            resString = "Error in System.IO.File.ReadAllBytes(fileName);";
                        }
                        
                        
                        
                    }



                    // Create structure object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Structure structure = new Structure(structureId, structureStatus, statusUserName, volumeType, plan, MaterialCTValue, structureSer, resString);



                    structures.Add(structure);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return structures;
        }
    }
}