﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the operating limit query.
    /// </summary>
    class OperatingLimitQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
        SELECT DISTINCT   
         dbo.OperatingLimit.MaxSpeed 
    FROM dbo.Machine,   
         dbo.OperatingLimit  
   WHERE (dbo.OperatingLimit.ResourceSer = dbo.Machine.ResourceSer) AND
(dbo.OperatingLimit.ParameterType = @parameterType) AND
(dbo.Machine.MachineId = @machineId)";
            }
        }

        /// <summary>
        /// Get operating limit from the database.
        /// </summary>
        public double GetOperatingLimit(Machine machine, string parameterType)
        {
            double operatingLimit = 0;

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@parameterType", parameterType);
            cmd.Parameters.AddWithValue("@machineId", machine.MachineId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    operatingLimit = DbConn.GetValueQueryDouble(rdr, 0);                
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return operatingLimit;
        }
    }
}