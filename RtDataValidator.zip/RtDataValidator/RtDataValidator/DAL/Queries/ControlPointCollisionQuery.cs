﻿using RtDataValidator.BLL;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the collisio control point query.
    /// </summary>
    class ControlPointCollisionQuery
    {

        /// <summary>
        /// Query string.
        /// Get control points for ARC fields and support angle. 
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
 SELECT DISTINCT dbo.Radiation.RadiationId,   
           dbo.ExternalFieldCommon.PatientSupportAngle,
         dbo.ControlPoint.GantryRtn,
 dbo.ExternalField.GantryRtn,
dbo.ExternalField.StopAngle,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,
         dbo.PlanSetup.PlanSetupId,
dbo.PlanSetup.Status,
dbo.Machine.MachineId,
dbo.Machine.MachineScale,
dbo.PlanSetup.PlanSetupName
    FROM dbo.ControlPoint,   
         dbo.Radiation,   
         dbo.Course,   
         dbo.Patient,   
         dbo.PlanSetup,   
         dbo.ExternalField,   
         dbo.ExternalFieldCommon,
dbo.Technique,
dbo.Machine  
   WHERE (dbo.ControlPoint.RadiationSer = dbo.Radiation.RadiationSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND  
         (dbo.PlanSetup.CourseSer = dbo.Course.CourseSer) AND  
         (dbo.PlanSetup.PlanSetupSer = dbo.Radiation.PlanSetupSer) AND  
         (dbo.Radiation.RadiationSer = dbo.ExternalField.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.ExternalField.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.Radiation.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.ControlPoint.RadiationSer) AND  
 (dbo.Technique.TechniqueSer = dbo.ExternalFieldCommon.TechniqueSer ) AND
(dbo.Machine.ResourceSer = dbo.Radiation.ResourceSer) AND
 (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
    (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND
    (upper(dbo.Technique.TechniqueId) NOT LIKE 'STATIC') AND
(dbo.ExternalFieldCommon.PatientSupportAngle <> 0) AND
         (dbo.Patient.PatientId = @patientid) 
ORDER BY dbo.PlanSetup.PlanSetupId ASC";
            }
        }

        /// <summary>
        /// Get control points from the database.
        /// </summary>
        public List<ControlPoint> GetControlPoints(Patient patient)
        {
            // Create list with external fields.
            List<ControlPoint> controlpoints = new List<ControlPoint>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string radiationId = DbConn.GetValueQueryString(rdr, 0).Trim();
                    double patientSupportAngleTemp = DbConn.GetValueQueryDouble(rdr, 1);
                    double gantryRtn = DbConn.GetValueQueryDouble(rdr, 2);
                    double gantryRtnExField = DbConn.GetValueQueryDouble(rdr, 3);
                    double stopAngleExField = DbConn.GetValueQueryDouble(rdr, 4);
                    string courseId = DbConn.GetValueQueryString(rdr, 5);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 6);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 7).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 8).Trim();
                    string machineId = DbConn.GetValueQueryString(rdr, 9).Trim();
                    string machineScale = DbConn.GetValueQueryString(rdr, 10).Trim();
                    string planSetupName = DbConn.GetValueQueryString(rdr, 11).Trim();

                    // Convert support angle to varian iec scale.
                    double patientSupportAngle = ScaleHandler.GetVarianIecScaleDouble(patientSupportAngleTemp, machineScale);


                    // Create control point object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Machine machine = new Machine(machineId, machineScale);
                    ControlPoint controlpoint = new ControlPoint(radiationId, patientSupportAngle, gantryRtn, gantryRtnExField, stopAngleExField, plan, machine, planSetupName);

                    controlpoints.Add(controlpoint);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return controlpoints;
        }
    }
}