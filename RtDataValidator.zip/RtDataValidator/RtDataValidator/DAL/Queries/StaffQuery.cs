﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the staff query.
    /// </summary>
    class StaffQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
       SELECT DISTINCT dbo.Staff.StaffId,   
         dbo.Staff.AliasName
    FROM dbo.Staff LEFT OUTER JOIN dbo.Resource ON dbo.Staff.ResourceSer = dbo.Resource.ResourceSer 
ORDER BY dbo.Staff.StaffId ASC";
            }
        }

        /// <summary>
        /// Get the staff members from the database.
        /// </summary>
        public List<Staff> GetStaffMembers()
        {

            // Create list with staff members.
            List<Staff> staffmembers = new List<Staff>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string staffId = DbConn.GetValueQueryString(rdr, 0).Trim();
                    string aliasName = DbConn.GetValueQueryString(rdr, 1).Trim();

                    // Create staff object and add it to the list.
                    Staff staffmember = new Staff(staffId, aliasName);

                    staffmembers.Add(staffmember);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return staffmembers;
        }
    }
}