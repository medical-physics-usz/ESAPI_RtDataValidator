﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the oncologist query.
    /// </summary>
    class OncologistQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
       SELECT DISTINCT dbo.Doctor.DoctorId,   
         dbo.Doctor.AliasName
    FROM dbo.Doctor LEFT OUTER JOIN dbo.Resource ON dbo.Doctor.ResourceSer = dbo.Resource.ResourceSer 
WHERE  
(dbo.Doctor.OncologistFlag = '1') 
ORDER BY dbo.Doctor.DoctorId ASC";
            }
        }

        /// <summary>
        /// Get the oncologists from the database.
        /// </summary>
        public List<Oncologist> GetOncologists()
        {

            // Create list with oncologists.
            List<Oncologist> oncologists = new List<Oncologist>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string doctorId = DbConn.GetValueQueryString(rdr, 0).Trim();
                    string aliasName = DbConn.GetValueQueryString(rdr, 1).Trim();

                    // Create oncologist object and add it to the list.
                    Oncologist oncologist = new Oncologist(doctorId, aliasName);

                    oncologists.Add(oncologist);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return oncologists;
        }
    }
}