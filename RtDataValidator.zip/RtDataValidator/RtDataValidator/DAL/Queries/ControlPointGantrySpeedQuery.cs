﻿using RtDataValidator.BLL;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the gantry speed control point query.
    /// </summary>
    class ControlPointGantrySpeedQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
   SELECT DISTINCT 
dbo.Radiation.RadiationId,   
dbo.ControlPoint.ControlPointIndex, 
dbo.ControlPoint.MetersetWeight,   
dbo.ControlPoint.GantryRtn,
dbo.ExternalField.DoseRate,   
dbo.vv_syFieldMU.MU, 
dbo.Machine.MachineId,
dbo.Machine.MachineScale,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,
dbo.PlanSetup.PlanSetupId,   
dbo.PlanSetup.PlanSetupName,
dbo.PlanSetup.CreationDate,
dbo.PlanSetup.Status
      FROM dbo.ControlPoint,   
         dbo.Radiation,   
         dbo.Course,   
         dbo.Patient,   
         dbo.PlanSetup,   
         dbo.ExternalField,   
         dbo.ExternalFieldCommon,
dbo.vv_syFieldMU,
dbo.Machine,
dbo.Technique
   WHERE (dbo.ControlPoint.RadiationSer = dbo.Radiation.RadiationSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND  
         (dbo.PlanSetup.CourseSer = dbo.Course.CourseSer) AND  
         (dbo.PlanSetup.PlanSetupSer = dbo.Radiation.PlanSetupSer) AND  
         (dbo.Radiation.RadiationSer = dbo.ExternalField.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.ExternalField.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.Radiation.RadiationSer) AND  
         (dbo.ExternalFieldCommon.RadiationSer = dbo.ControlPoint.RadiationSer) AND  
         (dbo.ExternalFieldCommon.SetupFieldFlag = 0) AND  
(dbo.vv_syFieldMU.RadiationSer = dbo.Radiation.RadiationSer) AND 
(dbo.Machine.ResourceSer = dbo.Radiation.ResourceSer) AND
 (dbo.Technique.TechniqueSer = dbo.ExternalFieldCommon.TechniqueSer) AND
         (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
    (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND  
  (upper(dbo.Technique.TechniqueId) NOT LIKE 'STATIC') AND
(dbo.Patient.PatientId = @patientid) 
ORDER BY dbo.PlanSetup.PlanSetupId ASC,   
         dbo.Radiation.RadiationId ASC,   
         dbo.ControlPoint.ControlPointIndex ASC";
            }
        }

        /// <summary>
        /// Get control points from the database.
        /// </summary>
        public List<ControlPoint> GetControlPoints(Patient patient)
        {
            // Create list with external fields.
            List<ControlPoint> controlpoints = new List<ControlPoint>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string radiationId = DbConn.GetValueQueryString(rdr, 0).Trim();
                    int controlPointIndex = DbConn.GetValueQueryInt(rdr, 1);
                    double metersetWeight = DbConn.GetValueQueryDouble(rdr, 2);
                    double gantryRtn = DbConn.GetValueQueryDouble(rdr, 3);
                    int doseRate = DbConn.GetValueQueryInt(rdr, 4);
                    double monitorUnits = DbConn.GetValueQueryDouble(rdr, 5);
                    string machineId = DbConn.GetValueQueryString(rdr, 6).Trim();
                    string machineScale = DbConn.GetValueQueryString(rdr, 7).Trim();
                    string courseId = DbConn.GetValueQueryString(rdr, 8);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 9);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 10).Trim();
                    string planSetupName = DbConn.GetValueQueryString(rdr, 11).Trim();
                    DateTime planCreationDate = DbConn.GetValueQueryDateTime(rdr, 12);
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 13).Trim();

                    // Create control point object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Machine machine = new Machine(machineId, machineScale);
                    ControlPoint controlpoint = new ControlPoint(radiationId, controlPointIndex, metersetWeight, gantryRtn, doseRate, monitorUnits, machine, plan, planSetupName);

                    controlpoints.Add(controlpoint);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return controlpoints;
        }
    }
}