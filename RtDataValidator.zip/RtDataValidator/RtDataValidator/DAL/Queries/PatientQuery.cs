﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using RtDataValidator.BLL;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the patient query.
    /// </summary>
    class PatientQuery
    {
      
        /// <summary>
        /// Query string.
        /// </summary>
        public static string QueryStringId1
        {
            get
            {
                return @" 
 SELECT 
dbo.Patient.PatientId,   
         dbo.Patient.PatientId2,   
         dbo.Patient.LastName,   
         dbo.Patient.FirstName,   
         dbo.Patient.DateOfBirth,   
         dbo.Patient.Sex,
dbo.Patient.MobilePhone,
dbo.PatientParticular.UserDefAttrib01,
dbo.PatientParticular.DeathDate,
dbo.PatientDoctor.ResourceSer,
dbo.PatientActuals.PatientStatus  
    FROM
dbo.Patient 
LEFT OUTER JOIN dbo.PatientActuals ON dbo.Patient.PatientSer = dbo.PatientActuals.PatientSer
LEFT OUTER JOIN dbo.PatientParticular ON dbo.Patient.PatientSer = dbo.PatientParticular.PatientSer
LEFT OUTER JOIN PatientDoctor ON Patient.PatientSer = PatientDoctor.PatientSer AND dbo.PatientDoctor.PrimaryFlag = '1'  AND dbo.PatientDoctor.OncologistFlag = '1' 
   WHERE  
(dbo.Patient.PatientId = @patientid)";
            }
        }

        /// <summary>
        /// Query string.
        /// </summary>
        public static string QueryStringId2
        {
            get
            {
                return @" 
 SELECT
dbo.Patient.PatientId,   
         dbo.Patient.PatientId2,   
         dbo.Patient.LastName,   
         dbo.Patient.FirstName,   
         dbo.Patient.DateOfBirth,   
         dbo.Patient.Sex,
dbo.Patient.MobilePhone,
dbo.PatientParticular.UserDefAttrib01,
dbo.PatientParticular.DeathDate,
dbo.PatientDoctor.ResourceSer,  
dbo.PatientActuals.PatientStatus  
    FROM
dbo.Patient 
LEFT OUTER JOIN dbo.PatientActuals ON dbo.Patient.PatientSer = dbo.PatientActuals.PatientSer
LEFT OUTER JOIN dbo.PatientParticular ON dbo.Patient.PatientSer = dbo.PatientParticular.PatientSer
LEFT OUTER JOIN PatientDoctor ON Patient.PatientSer = PatientDoctor.PatientSer AND dbo.PatientDoctor.PrimaryFlag = '1'  AND dbo.PatientDoctor.OncologistFlag = '1' 
   WHERE  
(dbo.Patient.PatientId2 = @patientid)";
            }
        }

        /// <summary>
        /// Get patient information from the database.
        /// </summary>
        public Patient GetPatientInfo(string query, string patientIdInput)
        {

            string patientId = "";
            string patientId2 = "";
            string lastName = "";
            string firstName = "";
            DateTime dateoOfBirth = DateTime.MaxValue;
            PatientSex patientSex = PatientSex.Unknown;
            string mobilePhone = "";
            string insurance = "";
            DateTime deathDate = DateTime.MaxValue;
            int primaryOncologistSer = 0;
            string patientStatus = "";

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(query, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patientIdInput);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    patientId = DbConn.GetValueQueryString(rdr, 0);
                    patientId2 = DbConn.GetValueQueryString(rdr, 1);
                    lastName = DbConn.GetValueQueryString(rdr, 2);
                    firstName = DbConn.GetValueQueryString(rdr, 3);
                    dateoOfBirth = DbConn.GetValueQueryDateTime(rdr, 4);
                    patientSex = DbConn.GetValueQueryPatientSex(rdr, 5);
                    mobilePhone = DbConn.GetValueQueryString(rdr, 6);
                    insurance = DbConn.GetValueQueryString(rdr, 7).Trim();
                    deathDate = DbConn.GetValueQueryDateTime(rdr, 8);
                    primaryOncologistSer = DbConn.GetValueQueryInt(rdr, 9);
                    patientStatus = DbConn.GetValueQueryString(rdr, 10).Trim();
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            Oncologist oncologist = new Oncologist(primaryOncologistSer);
            Patient patient = new Patient(patientId, patientId2, lastName, firstName, dateoOfBirth, patientSex, mobilePhone, insurance, deathDate, oncologist, patientStatus);

            return patient;
        }
    
        /// <summary>
        /// Verify if patient id exists.
        /// </summary>
        public bool IsValidPatientId(string patientId, string query)
        {

            string available = "0";

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(query, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {
                    // Get  result of each column.
                    available = DbConn.GetValueQueryString(rdr, 0);    
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            if (available.Equals("0"))
            {        
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
