﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the image series plan query.
    /// </summary>
    class ImageSeriesPlanQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
  SELECT DISTINCT 
    dbo.Series.SeriesId,
    dbo.Series.SeriesModality,
    dbo.Series.PatientOrientation, 
    dbo.Image.ImageId,
    dbo.Image.CreationDate,  
    dbo.Course.CourseId, 
    dbo.PlanSetup.PlanSetupSer,
    dbo.PlanSetup.PlanSetupId,   
    dbo.PlanSetup.Status,   
    dbo.PlanSetup.TreatmentOrientation,   
    dbo.PlanSetup.CreationDate,
    dbo.Image.UserOrigin,
    dbo.PlanSetup.PlanSetupName,
    dbo.PlanSetup.Intent

    FROM dbo.Image,   
         dbo.Patient,   
         dbo.PlanSetup,   
         dbo.StructureSet,   
         dbo.Course,   
         dbo.Series  
   WHERE (dbo.StructureSet.StructureSetSer = dbo.PlanSetup.StructureSetSer) AND  
         (dbo.Course.CourseSer = dbo.PlanSetup.CourseSer) AND  
         (dbo.Course.PatientSer = dbo.Patient.PatientSer) AND  
         (dbo.StructureSet.ImageSer = dbo.Image.ImageSer) AND  
         (dbo.Series.SeriesSer = dbo.Image.SeriesSer) AND  
         (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
        (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND   
         (dbo.Patient.PatientId = @patientid)   
ORDER BY dbo.PlanSetup.PlanSetupId ASC";
            }
        }

        /// <summary>
        /// Get image and plan information from the database.
        /// </summary>
        public List<ImageSeries> GetImageSeries(Patient patient)
        {
            // Create list with image/series.
            List<ImageSeries> imageseries = new List<ImageSeries>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {
                    string seriesId = DbConn.GetValueQueryString(rdr, 0);
                    string seriesModality = DbConn.GetValueQueryString(rdr, 1).Trim();
                    string patientOrientation = DbConn.GetValueQueryString(rdr, 2).Trim();
                    string imageId = DbConn.GetValueQueryString(rdr, 3);
                    DateTime creationDateImage = DbConn.GetValueQueryDateTime(rdr, 4);
                    string courseId = DbConn.GetValueQueryString(rdr, 5);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 6);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 7).Trim();
                    int noFractions = 0;
                    double prescribedDose = 0;
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 8).Trim();
                    string treatmentOrientation = DbConn.GetValueQueryString(rdr, 9).Trim();
                    string calcModelOptions = "";
                    DateTime creationDatePlan = DbConn.GetValueQueryDateTime(rdr, 10);
                    string Name = DbConn.GetValueQueryString(rdr, 12);
                    string planIntent = DbConn.GetValueQueryString(rdr, 13);

                    byte[] bytes = DbConn.GetValueQueryBytes(rdr, 11, 24);
                    double userOriginX = BitConverter.ToDouble(bytes, 0);
                    double userOriginY = BitConverter.ToDouble(bytes, 8);
                    double userOriginZ = BitConverter.ToDouble(bytes, 16);
                    // Console.WriteLine(planSetupId + "  :  " + userOriginX + ":"+userOriginY + ":"+userOriginZ);
                    Tuple<double, double, double> userOrigin = new Tuple<double, double, double>(userOriginX, userOriginY, userOriginZ);


                    // Create image object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, noFractions, prescribedDose, planSetupStatus, treatmentOrientation, calcModelOptions, creationDatePlan, Name, planIntent);

                    ImageSeries imageserie = new ImageSeries(seriesId, seriesModality, patientOrientation, imageId, creationDateImage, userOrigin, plan);

                    imageseries.Add(imageserie);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return imageseries;
        }
    }
}