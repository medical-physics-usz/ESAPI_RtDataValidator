﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the reference point query.
    /// </summary>
    class RefPointQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
SELECT DISTINCT
dbo.RefPoint.RefPointId,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,  
dbo.PlanSetup.PlanSetupId,
dbo.PlanSetup.Status,
dbo.PatientVolume.VolumeTypeSer,  
dbo.RefPoint.TotalDoseLimit,
dbo.RefPoint.DailyDoseLimit,
dbo.RefPoint.SessionDoseLimit,
dbo.RTPlan.NoFractions,
dbo.RTPlan.PrescribedDose,
dbo.RefPointLocation.RefPointSer
    FROM dbo.PatientVolume,
    dbo.RefPoint  
	JOIN dbo.RadiationRefPoint ON dbo.RadiationRefPoint.RefPointSer = dbo.RefPoint.RefPointSer 
	JOIN dbo.RTPlan ON dbo.RTPlan.RTPlanSer = dbo.RadiationRefPoint.RTPlanSer
	JOIN dbo.PlanSetup ON dbo.PlanSetup.PlanSetupSer = dbo.RTPlan.PlanSetupSer
	JOIN dbo.Course ON dbo.Course.CourseSer = dbo.PlanSetup.CourseSer
	JOIN dbo.Patient ON dbo.Patient.PatientSer = dbo.Course.PatientSer 
	LEFT JOIN dbo.RefPointLocation ON dbo.RefPointLocation.RefPointSer = dbo.RefPoint.RefPointSer
         
WHERE dbo.Patient.PatientId = @patientid AND
(dbo.RefPoint.PatientVolumeSer = dbo.PatientVolume.PatientVolumeSer) AND  
(upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND
(upper(Course.CourseId) NOT LIKE '%IMPAC%') AND
(upper(Course.CourseId) NOT LIKE '%QA%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
(upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
(upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%')  AND
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE 'FL[_]%') AND   
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FLAB%') AND  
(dbo.PlanSetup.PlanSetupSer = dbo.RTPlan.PlanSetupSer) AND
(upper(dbo.Course.CourseId) NOT LIKE '%TEST%') 
ORDER BY dbo.RefPoint.RefPointId ASC";
            }
        }

        /// <summary>
        /// Get ref point information from the database.
        /// </summary>
        public List<RefPoint> GetRefPoints(Patient patient)
        {
            // Create list with ref points.
            List<RefPoint> refpoints = new List<RefPoint>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    string refPointId = DbConn.GetValueQueryString(rdr, 0);
                    string courseId = DbConn.GetValueQueryString(rdr, 1);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 2);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 4).Trim();
                    string volumeTypeSer = DbConn.GetValueQueryString(rdr, 5);
                    long refPointTotalDoseLimit = DbConn.GetValueQueryLong(rdr, 6);
                    long refPointDailyDoseLimit = DbConn.GetValueQueryLong(rdr, 7);
                    long refPointSessionDoseLimit = DbConn.GetValueQueryLong(rdr, 8);
                    int planNoFractions = DbConn.GetValueQueryInt(rdr, 9);
                    double planPrescribedDose = DbConn.GetValueQueryDouble(rdr, 10);

                    long refPointLocationSer = DbConn.GetValueQueryLong(rdr, 11);
                    bool hasRefPointLocation = (refPointLocationSer != 0);
                    // Console.WriteLine(planSetupId + " : " + hasRefPointLocation);

                    string refPointType = "not_retreived";
                    if (volumeTypeSer.Equals("4")) { refPointType = "Target"; }
                    if (volumeTypeSer.Equals("5")) { refPointType = "Organ at Risk"; }

                    // Create ref point object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    RefPoint refpoint = new RefPoint(refPointId, plan, hasRefPointLocation, refPointType, refPointTotalDoseLimit, refPointDailyDoseLimit, refPointSessionDoseLimit, planNoFractions, planPrescribedDose);
                    refpoints.Add(refpoint);

                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return refpoints;
        }
    }
}