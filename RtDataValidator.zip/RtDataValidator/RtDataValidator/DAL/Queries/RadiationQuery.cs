﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the radiation query.
    /// </summary>
    class RadiationQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
SELECT DISTINCT 
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer, 
dbo.PlanSetup.PlanSetupId,
dbo.PlanSetup.Status,
         dbo.Machine.MachineId,
dbo.Course.ClinicalStatus
    FROM dbo.Patient,   
         dbo.Machine,   
         dbo.Radiation,   
         dbo.PlanSetup,   
         dbo.Course  
   WHERE (dbo.Machine.ResourceSer = dbo.Radiation.ResourceSer) AND  
         (dbo.PlanSetup.PlanSetupSer = dbo.Radiation.PlanSetupSer) AND  
         (dbo.Course.CourseSer = dbo.PlanSetup.CourseSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND 
(upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND
(upper(Course.CourseId) NOT LIKE '%IMPAC%') AND
(upper(Course.CourseId) NOT LIKE '%QA%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
(upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%' ) AND  
(upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
    (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND 
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND  
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE 'QA[_]%') AND
         (dbo.Patient.PatientId = @patientid)";
            }
        }

        /// <summary>
        /// Get radiation information from the database.
        /// </summary>
        public List<Radiation> GetRadiationData(Patient patient)
        {
            // Create list with radiation data.
            List<Radiation> radiationdata = new List<Radiation>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {
                    string courseId = DbConn.GetValueQueryString(rdr, 0);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 1);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 2).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string machineId = DbConn.GetValueQueryString(rdr, 4).Trim();
                    string courseStatus = DbConn.GetValueQueryString(rdr, 5).Trim();
                    
                    // Create radiation object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Radiation radiation = new Radiation(plan, machineId, courseStatus);
                    radiationdata.Add(radiation);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return radiationdata;
        }
    }
}