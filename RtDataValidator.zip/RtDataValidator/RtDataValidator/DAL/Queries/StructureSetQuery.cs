﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the structure set query.
    /// </summary>
    class StructureSetQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @" 
 SELECT DISTINCT dbo.StructureSet.StructureSetId,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,   
         dbo.PlanSetup.PlanSetupId, 
dbo.PlanSetup.Status,
dbo.StructureSet.ROIMaterialVersion,
dbo.Image.ImageId
    FROM dbo.StructureSet,
dbo.PlanSetup,   
         dbo.Course,   
         dbo.Patient,
         dbo.Image
   WHERE
dbo.StructureSet.ImageSer = dbo.Image.ImageSer AND
dbo.StructureSet.StructureSetSer = dbo.PlanSetup.StructureSetSer AND
 (dbo.Course.CourseSer = dbo.PlanSetup.CourseSer) AND  
         (dbo.Patient.PatientSer = dbo.Course.PatientSer) AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'QA%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'KV[_]%') AND  
         (upper(dbo.StructureSet.StructureSetId) NOT LIKE 'CBCT[_]%') AND 
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND  
         (dbo.Patient.PatientId = @patientid)   
ORDER BY dbo.StructureSet.StructureSetId ASC";
            }
        }

        /// <summary>
        /// Get structure set information from the database.
        /// </summary>
        public List<StructureSet> GetStructureSets(Patient patient)
        {
            // Create list with structure sets.
            List<StructureSet> structuresets = new List<StructureSet>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {
                    string structureSetId = DbConn.GetValueQueryString(rdr, 0);
                    string courseId = DbConn.GetValueQueryString(rdr, 1);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 2);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 4).Trim();
                    string physicalMaterialTable = DbConn.GetValueQueryString(rdr, 5).Trim();
                    string imageId = DbConn.GetValueQueryString(rdr, 6).Trim();


                    // Create structure set object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    StructureSet structureset = new StructureSet(structureSetId, physicalMaterialTable, plan, imageId);

                    structuresets.Add(structureset);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return structuresets;
        }
    }
}