﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the image series query.
    /// </summary>
    class ImageSeriesQuery
    {
        
        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
        SELECT DISTINCT   
        dbo.Series.SeriesId,
        dbo.Series.SeriesModality,
dbo.Series.PatientOrientation, 
        dbo.Image.ImageId,
        dbo.Image.CreationDate
        FROM 
        dbo.Patient,   
        dbo.Series,      
        dbo.Study,
        dbo.Image
        WHERE 
        (dbo.Study.PatientSer = dbo.Patient.PatientSer) AND
        (dbo.Study.StudySer = dbo.Series.StudySer) AND 
        (dbo.Image.SeriesSer = dbo.Series.SeriesSer) AND  
        (dbo.Image.ImageType = 'Image') AND
        (dbo.Image.ImageId NOT LIKE 'kV[_]%') AND
(dbo.Image.ImageId NOT LIKE 'CBCT[_]%') AND
        (dbo.Image.ImageId NOT LIKE 'Z[_]%') AND
        (dbo.Patient.PatientId = @patientid) 
        ORDER BY dbo.Series.SeriesId ASC";
            }
        }

        /// <summary>
        /// Get image and series information from the database.
        /// </summary>
        public List<ImageSeries> GetImageSeries(Patient patient)
        {
            // Create list with image/series.
            List<ImageSeries> imageseries = new List<ImageSeries>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    string seriesId = DbConn.GetValueQueryString(rdr, 0);
                    string seriesModality = DbConn.GetValueQueryString(rdr, 1).Trim();
                    string patientOrientation = DbConn.GetValueQueryString(rdr, 2).Trim();
                    string imageId = DbConn.GetValueQueryString(rdr, 3);
                    DateTime creationDate = DbConn.GetValueQueryDateTime(rdr,4);
               
                    // Create image object and add it to the list.
                    ImageSeries imageserie = new ImageSeries(seriesId, seriesModality, patientOrientation, imageId, creationDate);

                    imageseries.Add(imageserie);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return imageseries;
        }
    }
}