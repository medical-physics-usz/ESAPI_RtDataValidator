﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the course query.
    /// </summary>
    class CourseQuery
    {

        /// <summary>
        /// Query string with filtered clinical courses.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
           SELECT DISTINCT
dbo.Course.CourseId,   
dbo.Course.StartDateTime,   
dbo.Course.CompletedDateTime,
dbo.Course.ClinicalStatus,
dbo.Diagnosis.DiagnosisCode,
dbo.Diagnosis.DiagnosisTableName,
dbo.Diagnosis.DateStamp,
dbo.Diagnosis.Description,
vv_CourseIntent.Expression1 AS 'CourseIntent',
dbo.PlanSetup.PlanSetupSer,
dbo.PlanSetup.PlanSetupId,
dbo.PlanSetup.Status
FROM  
dbo.Patient 
INNER JOIN dbo.Course ON dbo.Course.PatientSer=dbo.Patient.PatientSer
LEFT OUTER JOIN PhysicianIntent ON dbo.Course.CourseSer=dbo.PhysicianIntent.CourseSer 
LEFT OUTER JOIN vv_CourseIntent ON dbo.PhysicianIntent.TreatmentIntentType = dbo.vv_CourseIntent.LookupValue AND 
vv_CourseIntent.LanguageId='ENU'
LEFT OUTER JOIN dbo.CourseDiagnosis ON dbo.CourseDiagnosis.CourseSer = dbo.Course.CourseSer
LEFT JOIN dbo.Diagnosis ON dbo.Diagnosis.DiagnosisSer = dbo.CourseDiagnosis.DiagnosisSer AND dbo.Diagnosis.ObjectStatus <> 'Deleted'
LEFT JOIN dbo.PlanSetup ON dbo.PlanSetup.CourseSer = dbo.Course.CourseSer
WHERE 
(upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND
(upper(Course.CourseId) NOT LIKE '%IMPAC%') AND
(upper(Course.CourseId) NOT LIKE '%QA%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND 
(upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND 
(upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%OPTIMIZ%') AND
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND 
dbo.Patient.PatientId = @patientid
ORDER BY dbo.Course.StartDateTime ASC";
            }
        }

        /// <summary>
        /// Get courses from the database. 
        /// </summary>
        public List<Course> GetCourses(Patient patient)
        {
            // Create list with courses.
            List<Course> courses = new List<Course>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string courseId = DbConn.GetValueQueryString(rdr, 0);
                    DateTime courseStartDate = DbConn.GetValueQueryDateTime(rdr, 1);
                    DateTime courseCompletedDate = DbConn.GetValueQueryDateTime(rdr, 2);
                    string clinicalStatus = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string diagnosisCode = DbConn.GetValueQueryString(rdr, 4).Trim();
                    string diagnosisTableName = DbConn.GetValueQueryString(rdr, 5).Trim();
                    DateTime dateStamp = DbConn.GetValueQueryDateTime(rdr, 6);
                    string description = DbConn.GetValueQueryString(rdr, 7).Trim();
                    string courseIntent = DbConn.GetValueQueryString(rdr, 8).Trim();
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 9);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 10);
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 11).Trim();

                    // Create course object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Diagnosis diagnosis = new Diagnosis(diagnosisCode, diagnosisTableName, dateStamp, description);
                    Course course = new Course(patient, diagnosis, courseId, courseStartDate, courseCompletedDate, clinicalStatus, courseIntent, plan);

                    courses.Add(course);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return courses;
        }
    }
}