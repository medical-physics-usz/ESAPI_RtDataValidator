﻿using RtDataValidator.BLL;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the external field query.
    /// </summary>
    class ExternalFieldGeometryQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
  SELECT DISTINCT dbo.Radiation.RadiationId,   
         dbo.Radiation.RadiationName, 
dbo.ExternalFieldCommon.SetupFieldFlag,
         dbo.ExternalFieldCommon.IsoCenterPositionX,   
         dbo.ExternalFieldCommon.IsoCenterPositionY,   
         dbo.ExternalFieldCommon.IsoCenterPositionZ,
dbo.ExternalFieldCommon.PatientSupportAngle,
dbo.ExternalFieldCommon.SSD,
dbo.ExternalField.GantryRtn,
dbo.ExternalField.CollX1,   
         dbo.ExternalField.CollX2,   
         dbo.ExternalField.CollY1,   
         dbo.ExternalField.CollY2,
dbo.ExternalField.CollRtn,
dbo.Technique.TechniqueId,
dbo.Course.CourseId,
dbo.PlanSetup.PlanSetupSer,
dbo.PlanSetup.PlanSetupId,
dbo.PlanSetup.Status,
dbo.Machine.MachineId,
dbo.Machine.MachineScale,
dbo.ExternalFieldCommon.CouchLat,
dbo.ExternalFieldCommon.CouchLatDelta,
dbo.ExternalFieldCommon.CouchLng,
dbo.ExternalFieldCommon.CouchLngDelta,
dbo.ExternalFieldCommon.CouchVrt,
dbo.ExternalFieldCommon.CouchVrtDelta,
dbo.ExternalFieldCommon.MotionCompSource,
dbo.ExternalFieldCommon.MotionCompTechnique,
dbo.ExternalField.GantryRtnDirection
    FROM dbo.PlanSetup,   
         dbo.RTPlan,   
         dbo.Patient,   
         dbo.Course,   
         dbo.Radiation,   
         dbo.ExternalFieldCommon,
dbo.Technique,
dbo.ExternalField,
dbo.Machine
   WHERE (dbo.Course.PatientSer = dbo.Patient.PatientSer) AND  
         (dbo.PlanSetup.PlanSetupSer = dbo.RTPlan.PlanSetupSer) AND  
         (dbo.PlanSetup.CourseSer = dbo.Course.CourseSer) AND  
         (dbo.PlanSetup.PlanSetupSer = dbo.Radiation.PlanSetupSer) AND  
         (dbo.Radiation.RadiationSer = dbo.ExternalFieldCommon.RadiationSer) AND  
  (dbo.Technique.TechniqueSer = dbo.ExternalFieldCommon.TechniqueSer ) AND 
 (dbo.Radiation.RadiationSer = dbo.ExternalField.RadiationSer) AND  
(dbo.Machine.ResourceSer = dbo.Radiation.ResourceSer) AND
         (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%') AND
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
    (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND 
               (dbo.Patient.PatientId = @patientid)   
ORDER BY dbo.Radiation.RadiationId ASC";
            }
        }

        /// <summary>
        /// Get external fields from the database.
        /// </summary>
        public List<ExternalField> GetExternalFields(Patient patient)
        {
            // Create list with external fields.
            List<ExternalField> externalfields = new List<ExternalField>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string radiationId = DbConn.GetValueQueryString(rdr, 0);
                    string radiationName = DbConn.GetValueQueryString(rdr, 1); 
                    int setupFieldFlag = DbConn.GetValueQueryInt(rdr, 2);
                    double isoCenterPositionX = DbConn.GetValueQueryDouble(rdr, 3);
                    double isoCenterPositionY = DbConn.GetValueQueryDouble(rdr, 4);
                    double isoCenterPositionZ = DbConn.GetValueQueryDouble(rdr, 5);
                    double patientSupportAngleTemp = DbConn.GetValueQueryDouble(rdr, 6);
                    double ssd = DbConn.GetValueQueryDouble(rdr, 7);
                    double gantryRtn = DbConn.GetValueQueryDouble(rdr, 8);
                    double collX1 = DbConn.GetValueQueryDouble(rdr, 9);
                    double collX2 = DbConn.GetValueQueryDouble(rdr, 10);
                    double collY1 = DbConn.GetValueQueryDouble(rdr, 11);
                    double collY2 = DbConn.GetValueQueryDouble(rdr, 12);
                    double collRtn = DbConn.GetValueQueryDouble(rdr, 13);
                    string techniqueId = DbConn.GetValueQueryString(rdr, 14).Trim();
                    string courseId = DbConn.GetValueQueryString(rdr, 15).Trim();
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 16);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 17).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 18).Trim();
                    string machineId = DbConn.GetValueQueryString(rdr, 19).Trim();
                    string machineScale = DbConn.GetValueQueryString(rdr, 20).Trim();
                    double couchLat = DbConn.GetValueQueryDouble(rdr, 21);
                    double couchLatDelta = DbConn.GetValueQueryDouble(rdr, 22);
                    double couchLng = DbConn.GetValueQueryDouble(rdr, 23);
                    double couchLngDelta = DbConn.GetValueQueryDouble(rdr, 24);
                    double couchVrt = DbConn.GetValueQueryDouble(rdr, 25);
                    double couchVrtDelta = DbConn.GetValueQueryDouble(rdr, 26);
                    string motionCompSource = DbConn.GetValueQueryString(rdr, 27).Trim();
                    string motionCompTechnique = DbConn.GetValueQueryString(rdr, 28).Trim();
                    string gantryRtnDirection = DbConn.GetValueQueryString(rdr, 29).Trim();

                    bool gating = false;
                    if ( motionCompSource.Equals("EXTERNAL_MARKER") & motionCompTechnique.Equals("GATING") ){ gating = true; }

                    // Convert support angle to varian iec scale.
                    double patientSupportAngle = ScaleHandler.GetVarianIecScaleDouble(patientSupportAngleTemp, machineScale);

                    // Create external field object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    Machine machine = new Machine(machineId, machineScale);
                    ExternalField externalfield = new ExternalField(radiationId, radiationName, setupFieldFlag, isoCenterPositionX, isoCenterPositionY, isoCenterPositionZ, patientSupportAngle, ssd, gantryRtn, collX1, collX2, collY1, collY2, collRtn, techniqueId, plan, machine, couchLat, couchLatDelta, couchLng, couchLngDelta, couchVrt, couchVrtDelta, gating, gantryRtnDirection);

                    externalfields.Add(externalfield);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return externalfields;
        }
    }
}