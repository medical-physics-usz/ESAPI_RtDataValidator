﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the plan query.
    /// </summary>
    class PlanQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
SELECT 
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,
dbo.PlanSetup.PlanSetupId, 
dbo.RTPlan.NoFractions,
dbo.RTPlan.PrescribedDose,
dbo.PlanSetup.Status,
dbo.PlanSetup.TreatmentOrientation,
dbo.PlanSetup.CalcModelOptions,
dbo.PlanSetup.CreationDate,
dbo.PlanSetup.PlanSetupName,
dbo.PlanSetup.Intent,
dbo.DoseMatrix.CreationNote
FROM  
dbo.PlanSetup,
dbo.RTPlan,
dbo.Patient,
dbo.DoseMatrix,
dbo.Course
WHERE   
(dbo.DoseMatrix.PlanSetupSer=dbo.PlanSetup.PlanSetupSer) AND
(dbo.Course.PatientSer=dbo.Patient.PatientSer) AND
(dbo.PlanSetup.PlanSetupSer = dbo.RTPlan.PlanSetupSer) AND
(dbo.PlanSetup.CourseSer = dbo.Course.CourseSer) AND
(upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND
(upper(Course.CourseId) NOT LIKE '%IMPAC%') AND
(upper(Course.CourseId) NOT LIKE '%QA%') AND
(upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
(upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%' ) AND  
(upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
(upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND
(upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
    (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
(upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND 
(dbo.Patient.PatientId = @patientid)
ORDER BY Course.StartDateTime ASC";
            }
        }

        /// <summary>
        /// Get plans from the database.
        /// </summary>
        public List<Plan> GetPlans(Patient patient)
        {
            // Create list with plans.
            List<Plan> plans = new List<Plan>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {
                    // Get  result of each column.
                    string courseId = DbConn.GetValueQueryString(rdr, 0);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 1);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 2);
                    int noFractions = DbConn.GetValueQueryInt(rdr, 3);
                    double prescribedDose = DbConn.GetValueQueryDouble(rdr, 4);
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 5).Trim();
                    string treatmentOrientation = DbConn.GetValueQueryString(rdr, 6).Trim();
                    string calcModelOptions = DbConn.GetValueQueryString(rdr, 7).Trim();
                    DateTime creationDate = DbConn.GetValueQueryDateTime(rdr, 8);
                    string Name = DbConn.GetValueQueryString(rdr, 9);
                    string planIntent = DbConn.GetValueQueryString(rdr, 10);
                    string creationNote = DbConn.GetValueQueryString(rdr, 11);

                    // calcModelOptions is populated for EBRT and creationNote for Brachy. Merge in one variable
                    string calcModelOptions_creationNote = calcModelOptions + creationNote;

                    // Create plan object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, noFractions, prescribedDose, planSetupStatus, treatmentOrientation, calcModelOptions_creationNote, creationDate, Name, planIntent);

                    plans.Add(plan);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return plans;
        }
    }
}