﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the patient diagnosis query.
    /// </summary>
    class PatientDiagnosisQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
SELECT 
dbo.Diagnosis.DiagnosisCode,
dbo.Diagnosis.DiagnosisTableName,
dbo.Diagnosis.DateStamp,
dbo.Diagnosis.Description
FROM  
Diagnosis
LEFT OUTER JOIN dbo.Patient ON dbo.Diagnosis.PatientSer=dbo.Patient.PatientSer AND dbo.Diagnosis.ObjectStatus <> 'Deleted'
WHERE 
dbo.Patient.PatientId = @patientid
ORDER BY dbo.Diagnosis.DiagnosisCode ASC";
            }
        }

        /// <summary>
        /// Get patient diagnoses from the database.
        /// </summary>
        public List<Diagnosis> GetPatientDiagnoses(Patient patient)
        {
            // Create list with plans.
            List<Diagnosis> diagnosislist = new List<Diagnosis>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    string diagnosisCode = DbConn.GetValueQueryString(rdr, 0).Trim();
                    string diagnosisTableName = DbConn.GetValueQueryString(rdr, 1).Trim();
                    DateTime dateStamp = DbConn.GetValueQueryDateTime(rdr, 2);
                    string description = DbConn.GetValueQueryString(rdr, 3).Trim();

                    // Create diagnosis object and add it to the list.
                    Diagnosis diagnosis = new Diagnosis(diagnosisCode, diagnosisTableName, dateStamp, description);

                    diagnosislist.Add(diagnosis);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return diagnosislist;
        }
    }
}