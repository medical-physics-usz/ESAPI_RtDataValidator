﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the image slice query.
    /// </summary>
    class ImageSlicesQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"
         SELECT DISTINCT
dbo.Series.SeriesId,  
 dbo.Image.ImageId,
         dbo.Slice.SliceModality,   
         dbo.Slice.Thickness,
  dbo.Slice.SliceNumber,  
dbo.Slice.Position,
dbo.Course.CourseId, 
dbo.PlanSetup.PlanSetupSer,
         dbo.PlanSetup.PlanSetupId,   
         dbo.PlanSetup.Status,
         dbo.StructureSet.StructureSetId
    FROM dbo.Image,   
         dbo.Patient,   
         dbo.PlanSetup,   
         dbo.StructureSet,   
         dbo.Course,   
         dbo.Series,   
         dbo.Slice  
   WHERE (dbo.StructureSet.StructureSetSer = dbo.PlanSetup.StructureSetSer ) and  
         (dbo.Course.CourseSer = dbo.PlanSetup.CourseSer) and  
         (dbo.Course.PatientSer = dbo.Patient.PatientSer) and  
         (dbo.StructureSet.ImageSer = dbo.Image.ImageSer) and  
         (dbo.Series.SeriesSer = dbo.Image.SeriesSer) and  
         (dbo.Series.SeriesSer = dbo.Slice.SeriesSer) and  
         (upper(dbo.Course.CourseId) NOT LIKE '0[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%FLAB%') AND  
         (upper(Course.CourseId) NOT LIKE '%IMPAC%') AND  
         (upper(Course.CourseId) NOT LIKE '%QA%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%ONTROL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%VERRID%') AND 
         (upper(dbo.Course.CourseId) NOT LIKE '%TRIAL%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%DO%NOT%USE%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%STUDENT%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%PLAN%SUM%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TOTAL%DOSE%' ) AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'Z[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%TEST%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE 'EQ[_]%') AND  
         (upper(dbo.Course.CourseId) NOT LIKE '%EQ2GY%') AND  
        (upper(dbo.PlanSetup.PlanSetupId) NOT LIKE '%FL[_]%') AND 
         (dbo.Patient.PatientId = @patientid)   
ORDER BY dbo.PlanSetup.PlanSetupId ASC";
            }
        }

        /// <summary>
        /// Get slice information from the database.
        /// </summary>
        public List<ImageSlice> GetImageSlices(Patient patient)
        {
            // Create list with slices.
            List<ImageSlice> imageslices = new List<ImageSlice>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    string seriesId = DbConn.GetValueQueryString(rdr, 0);    
                    string imageId = DbConn.GetValueQueryString(rdr, 1);
                    string sliceModality = DbConn.GetValueQueryString(rdr, 2).Trim();
                    double thickness = DbConn.GetValueQueryDouble(rdr, 3);
                    int sliceNumber = DbConn.GetValueQueryInt(rdr, 4);
                    double position = DbConn.GetValueQueryDouble(rdr, 5);
                    string courseId = DbConn.GetValueQueryString(rdr, 6);
                    long planSetupSer = DbConn.GetValueQueryLong(rdr, 7);
                    string planSetupId = DbConn.GetValueQueryString(rdr, 8).Trim();
                    string planSetupStatus = DbConn.GetValueQueryString(rdr, 9).Trim();
                    string structureSetId = DbConn.GetValueQueryString(rdr, 10).Trim();

                    // Create slice object and add it to the list.
                    Plan plan = new Plan(courseId, planSetupSer, planSetupId, planSetupStatus);
                    ImageSlice imageslice = new ImageSlice(seriesId, imageId, sliceModality, thickness, sliceNumber,position, plan, structureSetId);

                    imageslices.Add(imageslice);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return imageslices;
        }
    }
}