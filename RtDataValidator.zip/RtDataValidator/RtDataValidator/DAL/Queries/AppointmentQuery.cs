﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace RtDataValidator.DAL
{
    /// <summary>
    /// Represents the appointment query.
    /// </summary>
    class AppointmentQuery
    {

        /// <summary>
        /// Query string.
        /// </summary>
        private static string queryString
        {
            get
            {
                return @"  
       SELECT DISTINCT
dbo.Machine.MachineId,
dbo.Machine.MachineScale,
ScheduledActivity.ScheduledStartTime,
vv_ActivityLng.Expression1,
dbo.ScheduledActivity.ScheduledActivityCode
        FROM
        Activity,
        ActivityCategory,
        ActivityInstance,
        ResourceActivity,
        vv_ActivityLng,
        Resource,
        ScheduledActivity,
        Patient,
        Attendee,
        vv_ResourceName,
Machine
        WHERE
        (Patient.PatientSer = ScheduledActivity.PatientSer) AND
        (ScheduledActivity.ObjectStatus = 'Active') AND
        (ScheduledActivity.ActivityInstanceSer = ActivityInstance.ActivityInstanceSer) AND
        (ActivityInstance.ActivitySer = Activity.ActivitySer) AND
        (ActivityCategory.ActivityCategorySer = Activity.ActivityCategorySer) AND
        (Activity.ActivityCode = vv_ActivityLng.LookupValue) AND
        (ScheduledActivity.ScheduledActivitySer = ResourceActivity.ScheduledActivitySer) AND
        (ResourceActivity.ResourceSer = Resource.ResourceSer) AND
        (Attendee.ResourceSer = Resource.ResourceSer) AND
        (Resource.ResourceSer = vv_ResourceName.ResourceSer) AND
        (Attendee.ActivityInstanceSer = ScheduledActivity.ActivityInstanceSer) AND
        (Patient.PatientId = @patientid) AND
(dbo.Resource.ResourceSer = dbo.Machine.ResourceSer) AND
(upper(dbo.ActivityCategory.ActivityCategoryCode) NOT LIKE 'PLANNING%') AND
(upper(dbo.ActivityCategory.ActivityCategoryCode) NOT LIKE 'PHYSICS') AND
(upper(dbo.ActivityCategory.ActivityCategoryCode) NOT LIKE 'MAINTENANCE') AND
((upper(vv_ActivityLng.Expression1) LIKE '%START%') OR
(upper(vv_ActivityLng.Expression1) LIKE '%ERST%'))
        ORDER BY dbo.Machine.MachineId ASC";
            }
        }

        /// <summary>
        /// Get the appointments from the database.
        /// </summary>
        public List<Appointment> GetAppointments(Patient patient)
        {

            // Create list with appointments.
            List<Appointment> appointments = new List<Appointment>();

            // Create SqlDataReader instance.
            SqlDataReader rdr = null;

            // Create a command object.
            SqlCommand cmd = new SqlCommand(queryString, DAL.DbConn.Instance.Connection);

            // Add value.
            cmd.Parameters.AddWithValue("@patientid", patient.PatientId);

            try
            {
                // Get instance of SqlDataReader.
                rdr = cmd.ExecuteReader();

                // Get columns of each record.
                while (rdr.Read())
                {

                    // Get  result of each column.
                    string machineId = DbConn.GetValueQueryString(rdr, 0).Trim();
                    string machineScale = DbConn.GetValueQueryString(rdr, 1).Trim();
                    DateTime scheduledStartTime = DbConn.GetValueQueryDateTime(rdr, 2);
                    string activityName = DbConn.GetValueQueryString(rdr, 3).Trim();
                    string scheduledActivityCode = DbConn.GetValueQueryString(rdr, 4).Trim();

                    // Create appointment object and add it to the list.
                    Machine machine = new Machine(machineId, machineScale);
                    Appointment appointment = new Appointment(machine, scheduledStartTime, activityName, scheduledActivityCode);

                    appointments.Add(appointment);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            finally
            {
                if (rdr != null) rdr.Close();
                if (cmd != null) cmd.Dispose();
            }

            return appointments;
        }
    }
}