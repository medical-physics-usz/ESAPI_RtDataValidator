﻿using RtDataValidator.BLL;
using RtDataValidator.DAL;
using RtDataValidator.UIL;
using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace RtDataValidator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        /// <summary>
        /// Constructor.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            DAL.DbConn.Instance.OpenConnection();
        }

        /// <summary>
        /// Close clicked.
        /// </summary>
        private void cmdClose_Click(object sender, RoutedEventArgs e)
        {
            DAL.DbConn.Instance.CloseConnection();
            this.Close();
        }
 

        /// <summary>
        /// Main window loaded.
        /// </summary>
        private void windowMain_Loaded(object sender, RoutedEventArgs e)
        {
            fillValidationComboBox();
            fillStatusComboBox();
            fillRtGroupComboBox();
            fillRtInformation1InitialComboBox();

            getCommandLineInfo();

            getPersonInformation();
        }


        /// <summary>
        /// Fill rt information 1 combobox during window load.
        /// </summary>
        private void fillRtInformation1InitialComboBox()
        {

            cboRtInformation1.Items.Add(FormOperations.LABELALL);
            cboRtInformation1.SelectedIndex = 0;
        }


        /// <summary>
        /// Fill validation combobox.
        /// </summary>
        private void fillValidationComboBox()
        {

            cboValidation.Items.Add(FormOperations.LABELACTIVEVALIDATION);
            cboValidation.Items.Add(FormOperations.LABELCOMPLETEDVALIDATION);
            cboValidation.SelectedIndex = 0;
        }

        /// <summary>
        /// Search button clicked.
        /// </summary>
        private void cmdSearch_Click(object sender, RoutedEventArgs e)
        {
            // Set results in data grid.
            setInitialInformation();
        }

        /// <summary>
        /// Filter button clicked.
        /// </summary>
        private void cmdFilter_Click(object sender, RoutedEventArgs e)
        {
            filterSettings_CoursePlan();
        }

        /// <summary>
        /// Clip board button clicked.
        /// </summary>
        private void cmdClipBoard_Click(object sender, RoutedEventArgs e)
        {

            dgridResults.SelectAllCells();
            dgridResults.ClipboardCopyMode = DataGridClipboardCopyMode.IncludeHeader;
            ApplicationCommands.Copy.Execute(null, dgridResults);

            dgridResults.UnselectAllCells();
        }

        /// <summary>
        /// Temporary label clicking for testing.
        /// </summary>
        private void lblPatientIdTitle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtPatientId.Text = "Empty";
        }

        /// <summary>
        /// Combobox rt group changed.
        /// </summary>
        private void cboRtGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filterSettings();
        }

        /// <summary>
        /// Combobox status changed.
        /// </summary>
        private void cboStatus_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filterSettings();
        }

        /// <summary>
        /// Combobox editable changed.
        /// </summary>
        private void cboEditable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filterSettings();
        }

        /// <summary>
        /// Filter all settings.
        /// </summary>
        private void filterAllSettings()
        {
            cboRtGroup.SelectedItem = FormOperations.LABELALL;

            cboStatus.SelectedItem = FormOperations.LABELALL;

            cboRtInformation1.SelectedItem = FormOperations.LABELALL;

            filterSettings();
        }

        /// <summary>
        /// Filter settings.
        /// </summary>
        private void filterSettings()
        {
            string filterStatus = getComboBoxItem(cboStatus);

            string filterRtGroup = getComboBoxItem(cboRtGroup);

            string filterRtInformation1 = getComboBoxItem(cboRtInformation1);


            List<TestObject> tobjects = FormOperations.tobjectsGLOBAL;

            if (tobjects.Count > 0)
            {

                tobjects = FormOperations.FilterStatus(filterStatus, tobjects);

                tobjects = FormOperations.FilterRtGroup(filterRtGroup, tobjects);

                tobjects = FormOperations.FilterRtInformation1(filterRtInformation1, tobjects);

                if (!getComboBoxItem(cboRtInformation1).Equals("ALL") && getComboBoxItem(cboRtInformation1).Length > 7)
                {
                    if (getComboBoxItem(cboRtInformation1).Substring(0,6).Equals("PLAN: "))
                    {
                        txtPlanId.Text = getComboBoxItem(cboRtInformation1).Remove(0, 6);
                        sendErrorsDB();
                    }
                }

                setDataGridLayout(tobjects);
                
            }
        }

        /// <summary>
        /// Send errors to DB
        /// </summary>
        private void sendErrorsDB()
        {
            // Every time that the validator is called, send the errors to a csv DB for future statistics 

            // It crashes if ran in the debug folder, avoid writing but warn for it
            bool debug = false;
            if (debug) { System.Windows.Forms.MessageBox.Show("Running in debug mode without saving to database, please change in Mainwindow.xaml.cs > private void sendErrorsDB()"); }

            // Collect some info
            DateTime today = DateTime.Today;
            string checker_ID = FormOperations.USERIDGLOBAL;
            string PTVs_UID = FormOperations.PTVUID;
            string Course_ID = FormOperations.COURSEIDGLOBAL;
            string Plan_ID = FormOperations.PLANSETUPIDGLOBAL;
            string PlanStatus_ID = FormOperations.PLANSETUPSTATUSGLOBAL;

            // Filter the RT information as in the filter option
            string patientID = txtPatientId.Text;
            string filterStatus = getComboBoxItem(cboStatus);
            string filterRtGroup = getComboBoxItem(cboRtGroup);
            string filterCourse = RtGroup.COURSE.ToString() + ": " + txtCourseId.Text;
            string filterPlan = RtGroup.PLAN.ToString() + ": " + txtPlanId.Text;

            List<TestObject> tobjects_DB = FormOperations.tobjectsGLOBAL;

            if (tobjects_DB.Count > 0)
            {
                tobjects_DB = FormOperations.FilterStatus(CheckResult.FAILED.ToString(), tobjects_DB);
                tobjects_DB = FormOperations.FilterRtGroup(filterRtGroup, tobjects_DB);
                tobjects_DB = FormOperations.FilterByCoursePlanInformation(filterCourse, filterPlan, tobjects_DB);
            }

            // Transform the test objects into a data table
            TestObjectOutput moo = new TestObjectOutput();
            DataTable myDataTable = moo.GetDataTable(tobjects_DB);
            StringBuilder stringb_DB = new StringBuilder();

            if (myDataTable.Rows.Count > 0)
            {
                // Add the info regarding patient, plan, checker and comment
                myDataTable.Columns.Add("PatientID", typeof(System.String));
                myDataTable.Columns.Add("CheckerID", typeof(System.String));
                myDataTable.Columns.Add("Date", typeof(System.String));
                myDataTable.Columns.Add("PTVsUID", typeof(System.String));
                myDataTable.Columns.Add("Course_ID", typeof(System.String));
                myDataTable.Columns.Add("Plan_ID", typeof(System.String));
                myDataTable.Columns.Add("PlanStatus_ID", typeof(System.String));

                foreach (DataRow row in myDataTable.Rows)
                {
                    row["PatientID"] = patientID;
                    row["CheckerID"] = checker_ID;
                    row["Date"] = today.ToString("G");
                    row["PTVsUID"] = PTVs_UID;
                    row["Course_ID"] = Course_ID;
                    row["Plan_ID"] = Plan_ID;
                    row["PlanStatus_ID"] = PlanStatus_ID;
                }

                foreach (DataRow row in myDataTable.Rows)
                {
                    string[] fields = row.ItemArray.Select(field => field.ToString()).
                                                    ToArray();
                    char[] charsToTrim = { ',' };
                    List<string> fieldsTrimmed = new List<string>();
                    foreach (string field in fields)
                    {
                        string field_trimmed = field.Trim(charsToTrim);
                        fieldsTrimmed.Add(field_trimmed);
                    }

                    string[] fields_trimmed = fieldsTrimmed.ToArray();

                    stringb_DB.AppendLine(string.Join("\t", fields));
                }

                //setDataGridLayout(tobjects_DB); // commented othewrsie only errors are shown
                if (!debug) {File.AppendAllText(@"Validator_Database\" + patientID + "_" + PTVs_UID.ToString() + ".tsv", "###\tNEW_VALIDATOR_CALL\t###\t" + today.ToString("G") + "\t###\t" + checker_ID + "\t###\t" + PlanStatus_ID + "\t###\n"); }
                if (!debug) {File.AppendAllText(@"Validator_Database\" + patientID + "_" + PTVs_UID.ToString() + ".tsv", stringb_DB.ToString()); }

            }
            else
            {
                if (!debug) {File.AppendAllText(@"Validator_Database\" + patientID + "_" + PTVs_UID.ToString() + ".tsv", "###\tNEW_VALIDATOR_CALL\t###\t" + today.ToString("G") + "\t###\t" + checker_ID + "\t###\t" + PlanStatus_ID + "\t###\n"); }
                //System.Windows.Forms.MessageBox.Show("There are no error entries for the selected plan/course, no data will be saved to the database", "Cancelled");
            }

        }

        /// <summary>
        /// Filter settings from Course and Plan
        /// </summary>
        private void filterSettings_CoursePlan()
        {
            string filterStatus = getComboBoxItem(cboStatus);

            string filterRtGroup = getComboBoxItem(cboRtGroup);

            string filterCourse = RtGroup.COURSE.ToString() + ": " + txtCourseId.Text;

            string filterPlan = RtGroup.PLAN.ToString() + ": " + txtPlanId.Text;


            List<TestObject> tobjects = FormOperations.tobjectsGLOBAL;

            if (tobjects.Count > 0)
            {

                tobjects = FormOperations.FilterStatus(filterStatus, tobjects);

                tobjects = FormOperations.FilterRtGroup(filterRtGroup, tobjects);

                tobjects = FormOperations.FilterByCoursePlanInformation(filterCourse, filterPlan, tobjects);


                setDataGridLayout(tobjects);
            }

            // After filtering, send the record to a DB
            sendErrorsDB();

        }

        /// <summary>
        /// Get combobox item.
        /// </summary>
        private string getComboBoxItem(ComboBox comboBox)
        {
            string item = FormOperations.LABELALL;

            if ((comboBox.Items.Count > 0) && (comboBox.SelectedItem != null))
            {
                try
                {
                    item = comboBox.SelectedItem.ToString();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            if (item.Equals(""))
            {
                item = FormOperations.LABELALL;
            }

            return item;
        }

        /// <summary>
        /// Get the information and set the data grid view.
        /// </summary>
        private void setInitialInformation()
        {

            lblUser.Content = FormOperations.USERIDGLOBAL;

            ValidationType type = ValidationType.Unknown;

            if (cboValidation.SelectedItem.Equals(FormOperations.LABELACTIVEVALIDATION))
            {
                type = ValidationType.ActiveCases;
            }

            if (cboValidation.SelectedItem.Equals(FormOperations.LABELCOMPLETEDVALIDATION))
            {
                type = ValidationType.CompletedCases;
            }

            PatientDbOutput pdo = new PatientDbOutput();
            Patient patient = pdo.GetPatient(txtPatientId.Text);

            if (FormOperations.ISVALIDPATIENT)
            {
                // Get static lists with staff and oncologists.
                getPersonInformation();

                TestObjectOutput output = new TestObjectOutput();
                List<TestObject> tobjects = output.GetTestObjects(type, patient);

                FormOperations.tobjectsGLOBAL = tobjects;

                PatientOutput po = new PatientOutput();

                lblPatientIdResult.Content = po.GetPatientDisplayInfo(patient);


                setRtInformation1ComboBox();

                // Filter items by plan if a valid plan id is available.
                if (FormOperations.PLANSETUPIDGLOBAL.Equals(""))
                {
                    setDataGridLayout(tobjects);
                }
                else
                {
                    setRtInformation1ComboBoxSelectedItem();
                    tobjects = FormOperations.FilterByPlanSetupId(tobjects);
                    setDataGridLayout(tobjects);
                }
            }
        }

        /// <summary>
        /// Set selected item in rt information 1 combobox to empty state (-1).
        /// Used for initial loading if the plan setup id is known.
        /// </summary>
        private void setRtInformation1ComboBoxSelectedItem()
        {

            try
            {

                cboRtInformation1.SelectedIndex = -1;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Set information in rt information 1 combobox.
        /// </summary>
        private void setRtInformation1ComboBox()
        {
            // Get filter information
            string filterStatus = getComboBoxItem(cboStatus);

            string filterRtGroup = getComboBoxItem(cboRtGroup);

            string filterRtInformation1 = getComboBoxItem(cboRtInformation1);

            List<TestObject> tobjects = FormOperations.tobjectsGLOBAL;

            if (tobjects.Count > 0)
            {
                // Filter first the objects.
                tobjects = FormOperations.FilterStatus(filterStatus, tobjects);

                tobjects = FormOperations.FilterRtGroup(filterRtGroup, tobjects);

                // Set information based on selection.
                cboRtInformation1.Items.Clear();

                cboRtInformation1.Items.Add(FormOperations.LABELALL);

                if (tobjects.Count > 0)
                {
                    // Get distinct rt information 1.
                    List<string> values = tobjects.Select(t => t.RtInformation1).Where(t => !t.Equals("")).Distinct().OrderBy(t => t).ToList();

                    // Add distinct items.
                    foreach (string v in values)
                    {

                        cboRtInformation1.Items.Add(v);
                    }
                }

                cboRtInformation1.SelectedIndex = 0;
                setDataGridLayout(tobjects);
            }
        }

        /// <summary>
        /// Get the information and set the data grid.
        /// </summary>
        private void setDataGridLayout(List<TestObject> tobjects)
        {

            TestObjectOutput moo = new TestObjectOutput();

            DataTable myDataTable = moo.GetDataTable(tobjects);

            // Bind DataTable to DataGrid.
            dgridResults.ItemsSource = myDataTable.DefaultView;

            // Set size columns.

            // status.
            DataGridColumn column0 = dgridResults.Columns[0];
            column0.Width = 70;

            // rt group.
            DataGridColumn column1 = dgridResults.Columns[1];
            column1.Width = 80;

            // rt information 1.
            DataGridColumn column2 = dgridResults.Columns[2];
            column2.Width = 220;

            // rt information 1.
            DataGridColumn column3 = dgridResults.Columns[3];
            column3.Width = 220;

            // comment.
            DataGridColumn column4 = dgridResults.Columns[4];
            column4.Width = 5000;

            // Set status information label.
            lblStatusInformation.Content = FormOperations.GetStatusInformation(tobjects);

            dgridResults.CanUserAddRows = false;
        }

        /// <summary>
        /// Set background color row depending on status.
        /// </summary>
        private void dgridResults_LoadingRow(object sender, DataGridRowEventArgs e)
        {

            // Get DataRow corresponding to DataGridRow that is loading.
            DataRowView item = e.Row.Item as DataRowView;

            if (item != null)
            {
                DataRow row = item.Row;

                // Access cell values.
                var colValue = row["STATUS"];

                e.Row.Background = new SolidColorBrush(Colors.White);

                // Set background color row based on result.
                if (colValue.ToString().Equals(CheckResult.PASSED.ToString()))
                {

                    e.Row.Background = new SolidColorBrush(Colors.MediumSeaGreen);
                }

                if (colValue.ToString().Equals(CheckResult.FAILED.ToString()))
                {

                    e.Row.Background = new SolidColorBrush(Colors.DarkSalmon);
                }

                if (colValue.ToString().Equals(CheckResult.NOCHECK.ToString()))
                {

                    e.Row.Background = new SolidColorBrush(Colors.LightBlue);
                }

                if (colValue.ToString().Equals(CheckResult.MANREV.ToString()))
                {

                    e.Row.Background = new SolidColorBrush(Colors.MediumPurple);
                }

                if (colValue.ToString().Equals(CheckResult.NORESULT.ToString()))
                {

                    e.Row.Background = new SolidColorBrush(Colors.LightGray);
                }
            }
        }

        /// <summary>
        /// Fill status combobox.
        /// </summary>
        private void fillStatusComboBox()
        {
            cboStatus.Items.Add(FormOperations.LABELALL);
            cboStatus.Items.Add(CheckResult.FAILED.ToString());
            cboStatus.Items.Add(CheckResult.NOCHECK.ToString());
            cboStatus.Items.Add(CheckResult.MANREV.ToString());
            cboStatus.Items.Add(CheckResult.PASSED.ToString());

            cboStatus.SelectedIndex = 0;
        }

        /// <summary>
        /// Fill rt group combobox.
        /// </summary>
        private void fillRtGroupComboBox()
        {

            cboRtGroup.Items.Add(FormOperations.LABELALL);
            cboRtGroup.Items.Add(RtGroup.COURSE.ToString());
            cboRtGroup.Items.Add(RtGroup.FIELD.ToString());
            cboRtGroup.Items.Add(RtGroup.IMAGE.ToString());
            cboRtGroup.Items.Add(RtGroup.PATIENT.ToString());
            cboRtGroup.Items.Add(RtGroup.MACHINE.ToString());
            cboRtGroup.Items.Add(RtGroup.PLAN.ToString());
            cboRtGroup.Items.Add(RtGroup.REFP.ToString());
            cboRtGroup.Items.Add(RtGroup.STRUCT.ToString());

            cboRtGroup.SelectedIndex = 0;
        }

        /// <summary>
        /// Read command line information.
        /// Global patient id is loaded if application is started with Eclipse script.
        /// </summary>
        private void getCommandLineInfo()
        {

            string[] args = Environment.GetCommandLineArgs();

            if (args.Length >= 5)
            {

                FormOperations.PATIENTIDGLOBAL = args[1];

                FormOperations.PLANSETUPIDGLOBAL = args[2];

                FormOperations.COURSEIDGLOBAL = args[3];

                FormOperations.USERIDGLOBAL = args[4]; 


            }

            if ((FormOperations.PATIENTIDGLOBAL.Length < 20) && (!FormOperations.PATIENTIDGLOBAL.Equals("") && (!FormOperations.COURSEIDGLOBAL.Equals(""))))
            {
                txtPatientId.Text = FormOperations.PATIENTIDGLOBAL.Trim();
                txtPlanId.Text = FormOperations.PLANSETUPIDGLOBAL.Trim();
                txtCourseId.Text = FormOperations.COURSEIDGLOBAL.Trim();

                setInitialInformation();
            }

            if (args.Length >= 5)
            {
                filterSettings_CoursePlan(); // if all the information is there, filter already without asking for user to click
            }
        }

        /// <summary>
        /// Set static lists with staff and oncologists.
        /// </summary>
        private void getPersonInformation()
        {
            OncologistOutput oo = new OncologistOutput();
            oo.SetOncologists();

            StaffOutput so = new StaffOutput();
            so.SetStaff();
        }

        /// <summary>
        /// Reset filter button clicked.
        /// </summary>
        private void cmdResetFilter_Click(object sender, RoutedEventArgs e)
        {
            filterAllSettings();
        }

        /// <summary>
        /// Enter button clicked within patient id text box.
        /// </summary>
        private void txtPatientId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Set results in data grid.
                setInitialInformation();
            }
        }

        /// <summary>
        /// Combobox rt information 1 changed.
        /// </summary>
        private void cboRtInformation1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filterSettings();
        }


        /// <summary>
        /// Quick filter button clicked.
        /// </summary>
        private void cmdQuickFilterPlan_Click(object sender, RoutedEventArgs e)
        {

            cboStatus.SelectedItem = FormOperations.LABELALL;

            cboRtGroup.SelectedItem = FormOperations.LABELALL;

            List<TestObject> tobjects = FormOperations.tobjectsGLOBAL;

            if (tobjects.Count > 0)
            {

                tobjects = FormOperations.FilterQuickSettingsPlan(tobjects);

                setDataGridLayout(tobjects);
            }
        }

        private void txtPlanId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtCourseId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}