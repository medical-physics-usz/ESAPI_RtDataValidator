﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Respresent the staff output.
    /// </summary>
    class StaffOutput
    {
        public static List<Staff> STAFF = new List<Staff>();

        /// <summary>
        /// Get the staff members from the database.
        /// </summary>
        public void SetStaff()
        {
            STAFF.Clear();

            StaffQuery qry = new StaffQuery();

            STAFF = qry.GetStaffMembers();
        }

        /// <summary>
        /// Get the staff member by user name.
        /// </summary>
        public Staff GetStaffByUserName(string staffId, List<Staff> staffmembers)
        {
            Staff staffmember = new Staff("Unknown", "Unknown");

            staffmembers = staffmembers.Where(o => o.StaffId.Equals(staffId)).ToList();

            if (staffmembers.Count > 0)
            {
                staffmember = staffmembers.First();
            }

            return staffmember;
        }

        /// <summary>
        /// Verify if user is a staff member.
        /// </summary>
        public bool IsStaffByUserName(string staffId, List<Staff> staffmembers)
        {
            bool isStaffMember = false;

            isStaffMember = staffmembers.Any(x => x.StaffId.Equals(staffId));

            return isStaffMember;
        }
    }
}