﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the treatment site abbreviations.
    /// </summary>
    class TreatmentSite
    {

        /// <summary>
        /// Constructor.
        /// </summary>
        public TreatmentSite()
        {

        }

        /// <summary>
        /// Get treatment site description.
        /// </summary>
        public static string GetTreatmentSiteFromPlanId(string planId)
        {
            string key = "Unknown";

            // Example 3D_BRA (3D brain).
            if (planId.Contains("_"))
            {
                // Get length after first occurrence of _.
                int length = planId.Length - (planId.IndexOf('_') + 1);

                // Length must be at least 3.
                if (length >= 3)
                {
                    key = planId.Substring(planId.IndexOf('_') + 1, 3).ToUpper().Trim();
                }
            }

            string output = "Unknown";

            // Get value from dictionary if existing.
            Dictionary<string, string> treatmentsites = TreatmentSites();

            if (treatmentsites.ContainsKey(key))
            {
                treatmentsites.TryGetValue(key, out output);
            }

            return output;
        }

        /// <summary>
        /// Dictionary with treatment sites.
        /// </summary>
        /// <remarks>  
        /// Values in treatmentsites.xml.
        /// </remarks>
        private static Dictionary<string, string> TreatmentSites()
        {

            Dictionary<string, string> dictionary =
        new Dictionary<string, string>();

            List<string> keys = new List<string>();
            List<string> values = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"treatmentsites.xml");

            XmlNodeList keyList = doc.SelectNodes("treatmentsites/treatmentsite/sitekey");
            foreach (XmlNode Name in keyList)
            {
                keys.Add(Name.InnerText);
            }

            XmlNodeList valueList = doc.SelectNodes("treatmentsites/treatmentsite/sitevalue");
            foreach (XmlNode Name in valueList)
            {
                values.Add(Name.InnerText);
            }

            for (int i = 0; i < keys.Count; i++)
            {
                string key = keys.ElementAt(i);
                string value = values.ElementAt(i);

                dictionary.Add(key, value);
            }

            return dictionary;
        }
    }
}
