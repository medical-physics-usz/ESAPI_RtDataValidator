﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the general operations.
    /// </summary>
    class GenOperations
    {
        /// <summary>
        /// Validate date format.
        /// </summary>
        public static bool IsValidDateFormat(string input)
        {

            DateTime parsed;
            bool isValid = false;

            try
            {
                isValid = DateTime.TryParseExact(input, "yy-MM-dd",
                                                       CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed);
            }

            catch (Exception)
            {

                throw;
            }

            return isValid;
        }

        /// <summary>
        /// Validate date format after first appearance of underscore.
        /// </summary>
        public static bool IsValidDateFormatAfterUnderscore(string input)
        {

            bool isValid = false;

            string timestamp = "";

            // Start index = location underscore + 1 (e.g. CT_15-05-15 = 3).
            int s = input.IndexOf("_") + 1;

            // Validate input as date if length sub string > 8 and input string contains an underscore.
            if ((input.Length - s >= 8) && (input.IndexOf("_") > 0))
            {
                try
                {
                    timestamp = input.Substring(s, 8);
                   
                    isValid = GenOperations.IsValidDateFormat(timestamp);
                }
                catch (Exception)
                {

                    throw;
                }
            }
            
            return isValid;
        }

        /// <summary>
        /// Get date after first appearance of underscore.
        /// </summary>
        public static DateTime DateAfterUnderscore(string input)
        {
            DateTime parsed = DateTime.MaxValue;

            bool isValid = false;

            string timestamp = "";

            // Start index = location underscore + 1 (e.g. CT_15-05-15 = 3).
            int s = input.IndexOf("_") + 1;

            // Validate input as date if length sub string > 8 and input string contains an underscore.
            if ((input.Length - s >= 8) && (input.IndexOf("_") > 0))
            {
                try
                {
                    timestamp = input.Substring(s, 8);

                    isValid = GenOperations.IsValidDateFormat(timestamp);
                }
                catch (Exception)
                {

                    throw;
                }
            }

            if (isValid)
            {
                DateTime.TryParseExact(timestamp, "yy-MM-dd",
                                                       CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed);
            }

            return parsed;
        }
    }
}

