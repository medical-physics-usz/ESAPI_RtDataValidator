﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml;
using System.Xml.Linq;
using System.Windows.Forms;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the plan calculation model options.
    /// </summary>
    class PlanCalcModelOptionsExtractor
    {
        private string inputXmlString;

        /// <summary>
        /// Constructor.
        /// </summary>
        public PlanCalcModelOptionsExtractor( string inputXmlString )
        {

            this.inputXmlString = inputXmlString;
        }

        /// <summary>
        /// Get calculation model name string.
        /// </summary>
        public string CalculationModelName(uint skipNoOccurrences )
        {

            return getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithm[@CapabilityName='FieldVolumeDose']", "CalculationModelName", skipNoOccurrences );
        }

        /// <summary>
        /// Get particle type string.
        /// </summary>
        public string ParticleType(uint skipNoOccurrences )
        {

            return getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithm[@CapabilityName='FieldVolumeDose']", "ParticleType", skipNoOccurrences );
        }

        /// <summary>
        /// Get calculation grid size string.
        /// </summary>
        public string CalculationGridSizeInCm()
        {
            string value = "";

            // AAA. Not used anymore, search only for Acuros
            // value = getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithmOptions/AAACalculationOptions", "CalculationGridSizeInCM", 0);

            // Acuros.
            value = getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithmOptions/AcurosCalculationOptions", "CalculationGridSizeInCM", 0);
   

            return value;
        }

        public string CalculationGridSizeInCmForSRS()
        {
            string value = "";

            // Acuros SRS.
            value = getValueFromXmlString("CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithmOptions/AcurosCalculationOptions", "CalculationGridSizeInCMForSRSAndHyperArc", 0);


            return value;
        }

        /// <summary>
        /// Get field normalization type string.
        /// </summary>
        public string FieldNormalizationType( )
        {

            string value = "";

            // AAA. Not used anymore, search only for Acuros
            // value = getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithmOptions/AAACalculationOptions", "FieldNormalizationType", 0 );

            // Acuros.
            value = getValueFromXmlString( "CalculationDefinitions", "/CalculationDefinitions/SelectedAlgorithmOptions/AcurosCalculationOptions", "FieldNormalizationType", 0 );

            return value;
        }

        /// <summary>
        /// Get value from xml string.
        /// </summary>
        private string getValueFromXmlString( string nodeSelection, string elementSelection, string compareValue, uint skipNoOccurrences )
        {
            // 170123, MM: faulty implementation -- does not check for multiple occurrences of searched-for XML element
            //
            // work-around for now: additional input parameter to skip first N occurrences and return the one after that

            uint OccurrencesToSkip = skipNoOccurrences;


            //string name = "";

            // Verify if root exists
            if ( inputXmlString.Contains( nodeSelection ) )
            {
                XmlDocument xd = new XmlDocument( );

                // Additional try/catch if problem.
                try
                {
                    xd.LoadXml( inputXmlString );
                }
                catch ( Exception )
                {

                   // throw;
                }

                XmlNodeList xn = xd.SelectNodes( nodeSelection );

                //System.Windows.Forms.MessageBox.Show(xd.OuterXml);  // used to debug

                // Iterate over elements.
                foreach ( XmlElement emp in xd.SelectNodes( elementSelection ) )
                {
                    // Iterate over attributes.
                    foreach ( XmlAttribute att in emp.Attributes )
                    {
                        if ( att.Name.Equals( compareValue ) )
                        {
                            if ( OccurrencesToSkip.Equals( 0 ) )
                            {
                                return att.Value;
                            }
                            else
                            {
                                --OccurrencesToSkip;
                            }
                        }
                    }
                }
            }

            // if reach here, have not had enough occurrences in loop above, so return empty string
            return "";
        }
    }
}
