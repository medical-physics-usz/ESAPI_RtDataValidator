﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml;
using System.Xml.Linq;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the xml file handler.
    /// </summary>
    class XmlFileHandler
    {

        /// <summary>
        /// List string values.
        /// List values from a one node xml file.
        /// </summary>
        public List<string> GetStringList(string fileName, string nodeRoot)
        {
            List<string> values = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);

            XmlNodeList abbreviationList = doc.SelectNodes(nodeRoot);
            foreach (XmlNode Name in abbreviationList)
            {
                values.Add(Name.InnerText);
            }

            return values;
        }

        /// <summary>
        /// Check if value is in xml file.
        /// </summary>
        public bool HasValueInXmlList(string compValue, string fileName, string nodeRoot)
        {
            bool hasValue = false;

            List<string> values = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);

            XmlNodeList abbreviationList = doc.SelectNodes(nodeRoot);
            foreach (XmlNode Name in abbreviationList)
            {
                values.Add(Name.InnerText);
            }

            if (values.Contains(compValue))
            {
                hasValue = true;
            }

            return hasValue;
        }

        /// <summary>
        /// Get the single admin setting value.
        /// </summary>
        /// <remarks>  
        /// Values in adminsettings.xml.
        /// </remarks> 
        public static string GetSetting(string setting)
        {
            string settingvalue = "";

            XDocument doc = XDocument.Load(@"adminsettings.xml");

            var settingvalues = doc.Descendants(setting);

            foreach (var mysettingvalue in settingvalues)
            {
                settingvalue = mysettingvalue.Value;
            }

            return settingvalue;
        }
    }
}
