﻿using System.Text;
using System.Xml.Linq;
using System.Data.SqlClient;
using static Microsoft.VisualBasic.Interaction;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the general settings.
    /// </summary>
    static class Settings
    {

        // Retrieve value names.
        private static readonly string dbserver = "dbserver";
        private static readonly string dbname = "dbname";

        private static readonly string approlename = "approle";
        private static readonly string approlepwd = "approlepwd";

        /// <summary>
        /// Get the setting value.
        /// </summary>
        private static string GetSetting(string setting)
        {
            string settingvalue = "";

            XDocument doc = XDocument.Load(@"settings.xml");

            var settingvalues = doc.Descendants(setting);

            foreach (var mysettingvalue in settingvalues)
            {
                settingvalue = mysettingvalue.Value;
            }
			
            return settingvalue;
        }

        /// <summary>
        /// Database connection string.
        /// </summary>
        public static string ConnectionString()
        {
            SqlConnectionStringBuilder s = new SqlConnectionStringBuilder();

            s.DataSource = GetSetting(dbserver);
            s.InitialCatalog = GetSetting(dbname);
            s.IntegratedSecurity = true;
            s.ApplicationIntent = ApplicationIntent.ReadOnly;

            return s.ToString();
        }

        /// <summary>
        /// Command for setting application role on SQL server.
        /// </summary>
        /// <returns>Application Role command string for execution as an SQL command on an already opened SQL connection.</returns>
        public static string AppRoleCommand()
        {
            StringBuilder builder = new StringBuilder();

            // prepare to decrypt approle password
            string approlePwdHashed = GetSetting(approlepwd);
            Encryption ec = new Encryption();

            builder.Append("EXEC sp_setapprole ");
            builder.Append("'").Append(GetSetting(approlename)).Append("', ");
            builder.Append("'").Append(ec.Decrypt(approlePwdHashed)).Append("'");

            return builder.ToString();
        }
    }
}