﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the gantry speed handler.
    /// </summary>
    class GantrySpeedHandler
    {
        /// <summary>
        /// Calculate delta angle.
        /// </summary>
        private double getDeltaAngle(double a1, double a2)
        {
            double diff = Math.Abs(a1 - a2);

            if (diff > 300)
            {
                diff = 360.0 - Math.Max(a1, a2) + Math.Min(a1, a2);
            }

            return diff;
        }

        /// <summary>
        /// Calculate sdt.
        /// </summary>
        private double calculateSdt(double deltaAngle, double deltaMu, double maxGantrySpeed, double maxDoseRate)
        {
            double rotationTimeUsingMaxSpeed = deltaAngle / maxGantrySpeed;
            double deliveryTimeUsingMaxDoseRate = deltaMu / maxDoseRate;

            return Math.Max(deliveryTimeUsingMaxDoseRate, rotationTimeUsingMaxSpeed);
        }

        /// <summary>
        /// Get gantry speeds.
        /// </summary>
        public List<double> GetGantrySpeeds(List<ControlPoint> controlpoints, double maxGantrySpeed, string inPlanSetupId, string inCourseId)
        {
            StringBuilder sb = new StringBuilder();

            List<double> gantrySpeeds = new List<double>();

            // Sort by index.
            controlpoints = controlpoints.OrderBy(c => c.ControlPointIndex).ToList();
            //controlpoints = controlpoints.OrderBy(c => c.MetersetWeight).ToList();

            List<ControlPoint> PlanCourseControlpoints = new List<ControlPoint>();

            // Select only the control points from the desired plan in the desired course
            for (int i = 1; i < controlpoints.Count; i++)
            {
                if (controlpoints[i].Plan.PlanSetupId.Equals(inPlanSetupId) && controlpoints[i].Plan.CourseId.Equals(inCourseId))
                {
                    PlanCourseControlpoints.Add(controlpoints[i]);
                }

            }


            if (PlanCourseControlpoints.Count > 0)
            {

                double mu = PlanCourseControlpoints.First().MonitorUnits;
                double doseRate = PlanCourseControlpoints.First().DoseRate;

                // Iterate over control points starting from second element.
                for (int i = 1; i < PlanCourseControlpoints.Count; i++)
                {

                    var cpPrev = PlanCourseControlpoints[i - 1];
                    var cp = PlanCourseControlpoints[i];
                    double cpPrevGantryRtn = cpPrev.GantryRtn;
                    double cpGantryRtn = cp.GantryRtn;

                    double deltaAngle = getDeltaAngle(cpPrev.GantryRtn, cp.GantryRtn);
                    double deltaMU = mu * (cp.MetersetWeight - cpPrev.MetersetWeight);
                    double segmentDeliveryTime = calculateSdt(deltaAngle, deltaMU, maxGantrySpeed, cp.DoseRate / 60.0);
                    double gantrySpeed = Math.Abs(deltaAngle / segmentDeliveryTime);



                    if (deltaMU > 0 && deltaAngle > 0 && gantrySpeed > 0)
                    {
                        gantrySpeeds.Add(gantrySpeed);
                        sb.AppendLine(cp.Plan.PlanSetupId + ";" + cp.RadiationId + ";" + gantrySpeed.ToString("0.##"));

                    }
                    
                    

                }
            }

            return gantrySpeeds;
        }

        /// <summary>
        /// Verify if gantry speeds are valid.
        /// </summary>
        public bool HasValidGantrySpeeds(List<double> gantrySpeeds, double minSpeed, double maxSpeed)
        {
            bool hasValidGantrySpeeds = true;

            int counter = 0;

            // Min validation.
            counter = gantrySpeeds.Where(d => d <= minSpeed).Count();

            // Max. validation.
            counter = counter + gantrySpeeds.Where(d => d > maxSpeed).Count();

            if (counter > 0)
            {
                hasValidGantrySpeeds = false;
            }

            return hasValidGantrySpeeds;
        }
    }
}