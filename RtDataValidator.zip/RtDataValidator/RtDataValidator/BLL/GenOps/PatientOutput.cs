﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the patient output.
    /// </summary>
    class PatientOutput
    {

        /// <summary>
        /// Get patient display information.
        /// </summary>
        public string GetPatientDisplayInfo(Patient patient)
        {
            string sexinfo = "";
            if (patient.PatientSex.Equals(PatientSex.Female))
            {
                sexinfo = "Mrs. ";
            }
            if (patient.PatientSex.Equals(PatientSex.Male))
            {
                sexinfo = "Mr. ";
            }

            return sexinfo + patient.LastName + "; " + patient.FirstName + "; DOB: " + patient.DateOfBirth.ToShortDateString() + "; ID: " + patient.PatientId + "; RT-No: " + patient.PatientId2 + ".";
        }

    }
}
