﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the scale handler.
    /// </summary>
    class ScaleHandler
    {

        /// <summary>
        /// Get varian iec scale double.
        /// </summary>
        public static double GetVarianIecScaleDouble(double input, string scale)
        {
            double output = -1;

            if (GeometricScale.VAR_IEC.ToString().Equals(scale.ToUpper().Trim()))
            {
                output = 360 - input;

                if (output == 360)
                {
                    output = 0;
                }
            }

            return output;
        }
    }

    /// <summary>
    /// Enum geometric scale.
    /// Default values in database IEC1217.
    /// </summary>
    public enum GeometricScale
    {
        /// <summary>
        /// Enum geometric scale varian iec.
        /// </summary>
        VAR_IEC
    }
}