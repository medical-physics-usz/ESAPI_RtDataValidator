﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Interface validator.
    /// </summary>
  interface Validator
    {
        /// <summary>
        /// Inferface method to retrieve the validation output.
        /// </summary>
        List<TestObject> GetValidationOutput(ValidationType type, Patient patient);
    }
}
