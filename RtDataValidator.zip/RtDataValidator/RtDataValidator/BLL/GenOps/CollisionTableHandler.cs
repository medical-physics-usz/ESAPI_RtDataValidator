﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the collision table handler.
    /// </summary>
    class CollisionTableHandler
    {

        /// <summary>
        /// Validate if support angle and gantry angle combination is existing.
        /// Values to compare are rounded to one decimal place.
        /// </summary>
        public bool HasElementInCollisionTable(List<CollisionElement> collisionElements, double supportAngleToCheck, double gantryAngleToCheck)
        {
            bool hasElementInCollisionTable = false;

            supportAngleToCheck = Math.Round(supportAngleToCheck, 1);
            gantryAngleToCheck = Math.Round(gantryAngleToCheck, 1);

            hasElementInCollisionTable = collisionElements.Where(g => g.GantryAngle == gantryAngleToCheck).Any(p => p.SupportAngle == supportAngleToCheck);
            
            return hasElementInCollisionTable;
        }
    
        /// <summary>
        /// Get collision elements from xml file.
        /// </summary>
        /// <remarks>  
        /// Values in collisiontable.xml.
        /// </remarks>
        public List<CollisionElement> CollisionElementsInTable()
        {
            List<CollisionElement> collisions = new List<CollisionElement>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"collisiontable.xml");

            List<double> supportAngles = new List<double>();

            XmlNodeList supportAngleList = doc.SelectNodes(@"collisions/collision/supportangle");
            foreach (XmlNode Name in supportAngleList)
            {
                double supportAngle = -1;

                supportAngle = Math.Round(XmlConvert.ToDouble(Name.InnerText), 1);

                supportAngles.Add(supportAngle);
            }

            List<double> gantryAngles = new List<double>();

            XmlNodeList gantryAngleList = doc.SelectNodes(@"collisions/collision/gantryangle");
            foreach (XmlNode Name in gantryAngleList)
            {
                double gantryAngle = -1;

                gantryAngle = Math.Round(XmlConvert.ToDouble(Name.InnerText), 1);

                gantryAngles.Add(gantryAngle);
            }

            if (gantryAngles.Count == supportAngles.Count)
            {

                for (int i = 0; i < supportAngles.Count; i++)
                {
                    collisions.Add(new CollisionElement(supportAngles.ElementAt(i), gantryAngles.ElementAt(i)));
                }
            }

            return collisions;
        }
    }

    /// <summary>
    /// Represent the collision element object.
    /// </summary>
    class CollisionElement
    {
        private double supportAngle;
        /// <summary>
        /// Support angle.
        /// </summary>
        public double SupportAngle
        {
            get
            {
                return supportAngle;
            }
        }

        private double gantryAngle;
        /// <summary>
        /// Gantry angle
        /// </summary>
        public double GantryAngle
        {
            get
            {
                return gantryAngle;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public CollisionElement(double supportAngle, double gantryAngle)
        {
            this.supportAngle = supportAngle;
            this.gantryAngle = gantryAngle;
        }
    }
}