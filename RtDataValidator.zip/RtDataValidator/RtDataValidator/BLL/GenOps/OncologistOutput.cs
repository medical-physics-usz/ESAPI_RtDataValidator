﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Respresent the oncologist output.
    /// </summary>
   internal class OncologistOutput
    {
        public static List<Oncologist> ONCOLOGISTS = new List<Oncologist>();

        /// <summary>
        /// Get the oncologists from the database.
        /// </summary>
        public void SetOncologists()
        {
           ONCOLOGISTS.Clear();

           OncologistQuery qry = new OncologistQuery();

           ONCOLOGISTS = qry.GetOncologists();
        }

        /// <summary>
        /// Get the oncologists by user name.
        /// </summary>
        public Oncologist GetOncologistByUserName(string doctorId, List<Oncologist> oncologists)
        {
            Oncologist oncologist = new Oncologist("Unknown", "Unknown");

            oncologists = oncologists.Where(o => o.DoctorId.Equals(doctorId)).ToList();

            if (oncologists.Count > 0)
            {
                oncologist = oncologists.First();
            }
            return oncologist;
        }

        /// <summary>
        /// Verify if user is a oncologist.
        /// </summary>
        public bool IsOncologistByUserName(string doctorId, List<Oncologist> oncologists)
        {
            bool isOncologist = false;

            isOncologist = oncologists.Any(x => x.DoctorId.Equals(doctorId));

            return isOncologist;
        }
    }
}
