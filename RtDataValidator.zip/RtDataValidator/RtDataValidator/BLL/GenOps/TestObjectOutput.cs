﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using RtDataValidator.UIL;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the test object output.
    /// </summary>
    class TestObjectOutput
    {

        /// <summary>
        /// Get test object output for all tests.
        /// </summary>
        public List<TestObject> GetTestObjects(ValidationType type, Patient patient)
        {

            List<TestObject> tobjects = new List<TestObject>();

            // Valid patient.
            if (!patient.PatientId.Equals("Unknown"))
            {

                // Start patient validator.
                PatientValidator patientval = new PatientValidator();
                tobjects.AddRange(patientval.GetValidationOutput(type, patient));

                // Start patient-diagnosis validator.
                PatientDiagnosisValidator patdiagnval = new PatientDiagnosisValidator();
                tobjects.AddRange(patdiagnval.GetValidationOutput(type, patient));

                // Start course validator.
                CourseValidator courseval = new CourseValidator();
                tobjects.AddRange(courseval.GetValidationOutput(type, patient));

                // Start plan validator.
                PlanValidator planval = new PlanValidator();
                tobjects.AddRange(planval.GetValidationOutput(type, patient));

                // Start ref point validator.
                RefPointValidator refpointval = new RefPointValidator();
                tobjects.AddRange(refpointval.GetValidationOutput(type, patient));

                // Start structure set validator.
                StructureSetValidator structuresetval = new StructureSetValidator();
                tobjects.AddRange(structuresetval.GetValidationOutput(type, patient));

                // Start structure validator.
                StructureValidator structuresval = new StructureValidator();
                tobjects.AddRange(structuresval.GetValidationOutput(type, patient));

                // Start image/series validator.
                ImageSeriesValidator imageseriesval = new ImageSeriesValidator();
                tobjects.AddRange(imageseriesval.GetValidationOutput(type, patient));

                // Start slices validator.
                ImageSliceValidator slicesval = new ImageSliceValidator();
                tobjects.AddRange(slicesval.GetValidationOutput(type, patient));

                // Start geometric field validator.
                ExternalFieldGeometryValidator efgeoval = new ExternalFieldGeometryValidator();
                tobjects.AddRange(efgeoval.GetValidationOutput(type, patient));

                // Start dosimetric field validator.
                ExternalFieldDosimetryValidator efdosval = new ExternalFieldDosimetryValidator();
                tobjects.AddRange(efdosval.GetValidationOutput(type, patient));

                // Start collision control point validator.
                ControlPointCollisionValidator cpcolval = new ControlPointCollisionValidator();
                tobjects.AddRange(cpcolval.GetValidationOutput(type, patient));

                // Start general control point validator.
                ControlPointGantrySpeedValidator cpgenval = new ControlPointGantrySpeedValidator();
                tobjects.AddRange(cpgenval.GetValidationOutput(type, patient));
                
                // Start radiation validator.
                RadiationValidator radiationval = new RadiationValidator();
                tobjects.AddRange(radiationval.GetValidationOutput(type, patient));
            }

            return tobjects;
        }

        /// <summary>
        /// Empty test object.
        /// </summary>
        public TestObject EmptyTestObject(RtGroup rtGroup)
        {

            CheckResult status = CheckResult.NORESULT;

            EditableStatus editable = EditableStatus.NO;
            string rtInformation0 = "";
            string rtInformation1 = rtGroup.ToString();
            string rtInformation2 = "";
            string comment = "NO RESULTS: Empty set for RT group '" + rtGroup.ToString() + "'.";
 
            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Get the data table.
        /// </summary>
        public DataTable GetDataTable(List<TestObject> tobjects)
        {
            // Sort final list.
            tobjects = tobjects.OrderBy(t => t.RtInformation1).ThenBy(t => t.RtGroup.ToString()).ThenBy(t => t.Comment).ToList();

            DataTable dt = new DataTable();

            dt.Columns.Add(FormOperations.LABELSTATUS, typeof(string));
            dt.Columns.Add(FormOperations.LABELGROUP, typeof(string));
            dt.Columns.Add(FormOperations.LABELRTINFO1, typeof(string));
            dt.Columns.Add(FormOperations.LABELRTINFO2, typeof(string));
            dt.Columns.Add(FormOperations.LABELCOMMENT, typeof(string));
       
            foreach (var item in tobjects)
            {
                var row = dt.NewRow();

                row[FormOperations.LABELSTATUS] = item.CheckResult.ToString();
                row[FormOperations.LABELGROUP] = item.RtGroup.ToString();
                row[FormOperations.LABELRTINFO1] = item.RtInformation1;
                row[FormOperations.LABELRTINFO2] = item.RtInformation2;
                row[FormOperations.LABELCOMMENT] = item.Comment;

                dt.Rows.Add(row);
            }

            return dt;
        }
    }
}
