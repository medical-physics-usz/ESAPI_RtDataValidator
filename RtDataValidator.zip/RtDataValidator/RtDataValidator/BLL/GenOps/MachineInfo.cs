﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the machine information handler.
    /// </summary>
    class MachineInfo
    {
        /// <summary>
        /// Get min speed gantry speed.
        /// </summary>
        public double GetMinSpeedGantrySpeed(Machine machine)
        {
            double minSpeed = 0;

            List<Machine> machines = getMachineInfo();

            machines = machines.Where(m => m.MachineId.Equals(machine.MachineId)).ToList();

            if (machines.Count > 0)
            {
                minSpeed = machines.First().GantryMinSpeed;
            }

            return minSpeed;
        }

        /// <summary>
        /// Get machine information from xml file.
        /// Only for values that are not saved in the database.
        /// </summary>
        /// <remarks>  
        /// Values in machineinfo.xml.
        /// </remarks>
        private List<Machine> getMachineInfo()
        {
            List<Machine> machines = new List<Machine>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"machineinfo.xml");

            List<string> machineIds = new List<string>();

            XmlNodeList supportAngleList = doc.SelectNodes(@"machines/machine/machineid");
            foreach (XmlNode Name in supportAngleList)
            {
                machineIds.Add(Name.InnerText);
            }

            List<double> gantryMinSpeeds = new List<double>();

            XmlNodeList gantryMinSpeedList = doc.SelectNodes(@"machines/machine/gantryminspeed");
            foreach (XmlNode Name in gantryMinSpeedList)
            {
                double gantryMinSpeed = -1;

                gantryMinSpeed = Math.Round(XmlConvert.ToDouble(Name.InnerText), 1);

                gantryMinSpeeds.Add(gantryMinSpeed);
            }

            if (gantryMinSpeeds.Count == machineIds.Count)
            {

                for (int i = 0; i < machineIds.Count; i++)
                {
                    machines.Add(new Machine(machineIds.ElementAt(i), gantryMinSpeeds.ElementAt(i)));
                }
            }

            return machines;
        }
    }
}