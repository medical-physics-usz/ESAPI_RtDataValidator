﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Enum printable status.
    /// </summary>
   public enum Printable
    {
        /// <summary>
        /// Enum printable status YES.
        /// </summary>
       YES,
       /// <summary>
       /// Enum printable status NO.
       /// </summary>
       NO
    }
}
