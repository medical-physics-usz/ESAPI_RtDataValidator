﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Enum editable status.
    /// </summary>
    public enum EditableStatus
    {
        /// <summary>
        /// Enum editable status yes.
        /// </summary>
        YES,
        /// <summary>
        /// Enum editable status no.
        /// </summary>
        NO
    }
}
