﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Enum rt group.
    /// </summary>
    public enum RtGroup
    {
        /// <summary>
        /// Enum rt group course.
        /// </summary>
        COURSE,
        /// <summary>
        /// Enum rt group ICD code.
        /// </summary>
        ICD,
        /// <summary>
        /// Enum rt group external field.
        /// </summary>
        FIELD,
        /// <summary>
        /// Enum rt group image.
        /// </summary>
        IMAGE,
        /// <summary>
        /// Enum rt group machine.
        /// </summary>
        MACHINE,
        /// <summary>
        /// Enum rt group patient.
        /// </summary>
        PATIENT,
        /// <summary>
        /// Enum rt group plan.
        /// </summary>
        PLAN,
        /// <summary>
        /// Enum rt group reference point.
        /// </summary>
        REFP,
        /// <summary>
        /// Enum rt group structure set.
        /// </summary>
        STRUCT
    }
}
