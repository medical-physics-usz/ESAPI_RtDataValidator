﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Enum check result.
    /// </summary>
    public enum CheckResult
    {
        /// <summary>
        /// Enum check result failed.
        /// </summary>
        FAILED,
        /// <summary>
        /// Enum check result no check.
        /// </summary>
        NOCHECK,
        /// <summary>
        /// Enum check result no result.
        /// </summary>
        NORESULT,
        /// <summary>
        /// Enum check result passed.
        /// </summary>
        PASSED,
        /// <summary>
        /// Enum check result manual review.
        /// </summary>
        MANREV,
        /// <summary>
        /// Enum check result unknown.
        /// </summary>
        UNKNOWN
    }
}
