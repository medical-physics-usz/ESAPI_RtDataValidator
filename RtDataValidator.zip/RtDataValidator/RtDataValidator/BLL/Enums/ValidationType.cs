﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Enum validation type.
    /// </summary>
    public enum ValidationType
    {
        /// <summary>
        /// Unknown validation type.
        /// </summary>
        Unknown,
        /// <summary>
        /// ActiveCases validation type.
        /// </summary>
        ActiveCases,
        /// <summary>
        /// CompletedCases validation type.
        /// </summary>
        CompletedCases
    }
}
