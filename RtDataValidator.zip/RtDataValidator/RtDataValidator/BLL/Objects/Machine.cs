﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the machine object.
    /// </summary>
    class Machine
    {

        private string machineId;
        /// <summary>
        /// Machine id.
        /// </summary>
        public string MachineId
        {
            get
            {
                return machineId;
            }
        }

        private string machineScale;
        /// <summary>
        /// Machine scale.
        /// </summary>
        public string MachineScale
        {
            get
            {
                return machineScale;
            }
        }

        private double gantryMinSpeed;
        /// <summary>
        /// Gantry speed min value.
        /// </summary>
        public double GantryMinSpeed
        {
            get
            {
                return gantryMinSpeed;
            }
        }
       
        /// <summary>
        /// Constructor.
        /// Implemented for database access.
        /// </summary>
        public Machine(string machineId, string machineScale)
        {
            this.machineId = machineId;
            this.machineScale = machineScale;
        }

        /// <summary>
        /// Constructor.
        /// Implemented for xml file access.
        /// </summary>
        public Machine(string machineId, double gantryMinSpeed)
        {
            this.machineId = machineId;
            this.gantryMinSpeed = gantryMinSpeed;
        }
    }
}
