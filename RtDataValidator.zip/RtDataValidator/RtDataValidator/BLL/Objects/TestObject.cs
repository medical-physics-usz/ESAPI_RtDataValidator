﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the test object.
    /// </summary>
    public class TestObject
    {

        private CheckResult checkResult;
        /// <summary>
        /// Check result.
        /// </summary>
        public CheckResult CheckResult
        {
            get
            {
                return checkResult;
            }
        }

        private RtGroup rtGroup;
        /// <summary>
        /// Rt group.
        /// </summary>
        public RtGroup RtGroup
        {
            get
            {
                return rtGroup;
            }
        }

        private EditableStatus editableStatus;
        /// <summary>
        /// Editable status.
        /// </summary>
        public EditableStatus EditableStatus
        {
            get
            {
                return editableStatus;
            }
        }

        private string rtInformation0;
        /// <summary>
        /// Rt information 0.
        /// </summary>
        public string RtInformation0
        {
            get
            {
                return rtInformation0;
            }
        }

        private string rtInformation1;
        /// <summary>
        /// Rt information 1.
        /// </summary>
        public string RtInformation1
        {
            get
            {
                return rtInformation1;
            }
        }

        private string rtInformation2;
        /// <summary>
        /// Rt information 2.
        /// </summary>
        public string RtInformation2
        {
            get
            {
                return rtInformation2;
            }
        }

        private string comment;
        /// <summary>
        /// comment.
        /// </summary>
        public string Comment
        {
            get
            {
                return comment;
            }
        }

        private Printable printable;
        /// <summary>
        /// Printable.
        /// </summary>
        public Printable Printable
        {
            get
            {
                return printable;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public TestObject(CheckResult checkResult, RtGroup rtGroup, EditableStatus editableStatus, string rtInformation0, string rtInformation1, string rtInformation2, string comment, Printable printable)
        {
            this.checkResult = checkResult;
            this.rtGroup = rtGroup;
            this.editableStatus = editableStatus;
            this.rtInformation0 = rtInformation0;
            this.rtInformation1 = rtInformation1;
            this.rtInformation2 = rtInformation2;
            this.comment = comment;
            this.printable = printable;
        }
    }
}
