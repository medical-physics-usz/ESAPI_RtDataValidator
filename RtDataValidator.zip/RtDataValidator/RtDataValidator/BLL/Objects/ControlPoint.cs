﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the control point object.
    /// </summary>
    class ControlPoint
    {

        private string radiationId;
        /// <summary>
        /// Radiation id.
        /// </summary>
        public string RadiationId
        {
            get
            {
                return radiationId;
            }
        }

        private string planSetupName;
        /// <summary>
        /// planSetupName
        /// </summary>
        public string PlanSetupName
        {
            get
            {
                return planSetupName;
            }
        }

        private int controlPointIndex;
        /// <summary>
        /// Control point index.
        /// </summary>
        public int ControlPointIndex
        {
            get
            {
                return controlPointIndex;
            }
        }

        private double metersetWeight;
        /// <summary>
        /// Meter set weight.
        /// </summary>
        public double MetersetWeight
        {
            get
            {
                return metersetWeight;
            }
        }

        private double gantryRtn;
        /// <summary>
        /// Gantry rotation.
        /// </summary>
        public double GantryRtn
        {
            get
            {
                return gantryRtn;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        private Machine machine;
        /// <summary>
        /// Machine.
        /// </summary>
        public Machine Machine
        {
            get
            {
                return machine;
            }
        }

        private double patientSupportAngle;
        /// <summary>
        /// Patient support angle.
        /// </summary>
        public double PatientSupportAngle
        {
            get
            {
                return patientSupportAngle;
            }
        }

        private double gantryRtnExField;
        /// <summary>
        /// Gantry angle external field.
        /// </summary>
        public double GantryRtnExField
        {
            get
            {
                return gantryRtnExField;
            }
        }

        private double stopAngleExField;
        /// <summary>
        /// Stop angle external field.
        /// </summary>
        public double StopAngleExField
        {
            get
            {
                return stopAngleExField;
            }
        }

        private int doseRate;
        /// <summary>
        /// Dose rate.
        /// </summary>
        public int DoseRate
        {
            get
            {
                return doseRate;
            }
        }

        private double monitorUnits;
        /// <summary>
        /// Monitor units.
        /// </summary>
        public double MonitorUnits
        {
            get
            {
                return monitorUnits;
            }
        }
         /// <summary>
        /// Constructor gantry collision detection.
        /// </summary>
        public ControlPoint(string radiationId, double patientSupportAngle, double gantryRtn, double gantryRtnExField, double stopAngleExField, Plan plan, Machine machine, string planSetupName)
        {
            this.radiationId = radiationId;
            this.patientSupportAngle = patientSupportAngle;
            this.gantryRtn = gantryRtn;
            this.gantryRtnExField = gantryRtnExField;
            this.stopAngleExField = stopAngleExField;
            this.plan = plan;
            this.machine = machine;
            this.planSetupName = planSetupName;
        }

        /// <summary>
        /// Constructor general control point information.
        /// </summary>
        public ControlPoint(string radiationId, int controlPointIndex, double metersetWeight, double gantryRtn, int doseRate, double monitorUnits, Machine machine, Plan plan, string planSetupName)
        {
            this.radiationId = radiationId;
            this.controlPointIndex = controlPointIndex;
            this.metersetWeight = metersetWeight;
            this.gantryRtn = gantryRtn;
            this.doseRate = doseRate;
            this.monitorUnits = monitorUnits;
            this.machine = machine;
            this.plan = plan;
            this.planSetupName = planSetupName;
        }
    }
}