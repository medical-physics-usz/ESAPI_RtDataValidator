﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the staff object.
    /// </summary>
    public class Staff
    {

        private string staffId;
        /// <summary>
        /// Staff id.
        /// </summary>
        public string StaffId
        {
            get
            {
                return staffId;
            }
        }

        private string aliasName;
        /// <summary>
        /// Alias name.
        /// </summary>
        public string AliasName
        {
            get
            {
                return aliasName;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Staff(string staffId, string aliasName)
        {
            this.staffId = staffId;
            this.aliasName = aliasName;
        }
    }
}
