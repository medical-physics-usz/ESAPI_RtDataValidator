﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the patient object.
    /// </summary>
   public class Patient
    {
        private string patientId;
        /// <summary>
        /// Patient id.
        /// </summary>
        public string PatientId
        {
            get
            {
                return patientId;
            }
        }

        private string patientId2;
        /// <summary>
        /// Patient id 2.
        /// </summary>
        public string PatientId2
        {
            get
            {
                return patientId2;
            }
        }

        private string lastName;
        /// <summary>
        /// Last name.
        /// </summary>
        public string LastName
        {
            get
            {
                return lastName;
            }
        }

        private string firstName;
        /// <summary>
        /// First name.
        /// </summary>
        public string FirstName
        {
            get
            {
                return firstName;
            }
        }

        private DateTime dateOfBirth;
        /// <summary>
        /// Date of birth.
        /// </summary>
        public DateTime DateOfBirth
        {
            get
            {
                return dateOfBirth;
            }
        }

        private PatientSex patientSex;
        /// <summary>
        /// Patient sex.
        /// </summary>
        public PatientSex PatientSex
        {
            get
            {
                return patientSex;
            }
        }

        private string mobilePhone;
        /// <summary>
        /// Mobile phone number.
        /// </summary>
        public string MobilePhone
        {
            get
            {
                return mobilePhone;
            }
        }

        private string insurance;
        /// <summary>
        /// Insurance status.
        /// </summary>
        public string Insurance
        {
            get
            {
                return insurance;
            }
        }

        private DateTime deathDate;
        /// <summary>
        /// Death date.
        /// </summary>
        public DateTime DeathDate
        {
            get
            {
                return deathDate;
            }
        }

        private Oncologist primaryOncologist;
        /// <summary>
        /// Primary oncologist.
        /// </summary>
        public Oncologist PrimaryOncologist
        {
            get
            {
                return primaryOncologist;
            }
        }

        private string patientStatus;
        /// <summary>
        /// Patient status.
        /// </summary>
        public string PatientStatus
        {
            get
            {
                return patientStatus;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Patient(string patientId, string patientId2, string lastName, string firstName, DateTime dateoOfBirth, PatientSex patientSex, string mobilePhone, string insurance, DateTime deathDate, Oncologist primaryOncologist, string patientStatus)
        {
            this.patientId = patientId;
            this.patientId2 = patientId2;
            this.lastName = lastName;
            this.firstName = firstName;
            this.dateOfBirth = dateoOfBirth;
            this.patientSex = patientSex;
            this.mobilePhone = mobilePhone;
            this.insurance = insurance;
            this.deathDate = deathDate;
            this.primaryOncologist = primaryOncologist;
            this.patientStatus = patientStatus;
        }
    }

    /// <summary>
    /// Enum patient sex.
    /// </summary>
    public enum PatientSex
    {   
        /// <summary>
        /// Unknown patient sex.
        /// </summary>
        Unknown,
        /// <summary>
        /// Female patient sex.
        /// </summary>
        Female,
        /// <summary>
        /// Male patient sex.
        /// </summary>
        Male,
        /// <summary>
        /// Other patient sex.
        /// </summary>
        Other
    }
}