﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the plan type handler.
    /// </summary>
    class PlanType
    {

        /// <summary>
        /// Constructor.
        /// </summary>
        public PlanType()
        {

        }

        /// <summary>
        /// Get plan type description.
        /// </summary>
        public static string GetPlanTypeFromPlanId(string planId)
        {
            string key = "Unknown";

            // Example 3D_BRA (3D brain).
            if (planId.Length >= 2)
            {
                key = planId.Substring(0, 2);
            }

            string output = "Unknown";

            // Get value from dictionary if existing.
            Dictionary<string, string> treatmentsites = PlanTypes();

            if (treatmentsites.ContainsKey(key))
            {
                treatmentsites.TryGetValue(key, out output);
            }

            return output;
        }

        /// <summary>
        /// Dictionary with plan types.
        /// </summary>
        /// <remarks>  
        /// Values in plantypes.xml.
        /// </remarks>
        private static Dictionary<string, string> PlanTypes()
        {

            Dictionary<string, string> dictionary =
        new Dictionary<string, string>();

            List<string> keys = new List<string>();
            List<string> values = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"plantypes.xml");

            XmlNodeList planKeyList = doc.SelectNodes("plantypes/plantype/plankey");
            foreach (XmlNode Name in planKeyList)
            {
                keys.Add(Name.InnerText);
            }

            XmlNodeList planValueList = doc.SelectNodes("plantypes/plantype/planvalue");
            foreach (XmlNode Name in planValueList)
            {
                values.Add(Name.InnerText);
            }

            for (int i = 0; i < keys.Count; i++)
            {
                string key = keys.ElementAt(i);
                string value = values.ElementAt(i);

                dictionary.Add(key, value);
            }

            return dictionary;
        }
    }
}
