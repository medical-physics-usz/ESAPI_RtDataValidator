﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the appointment object.
    /// </summary>
    class Appointment
    {

        private Machine machine;
        /// <summary>
        /// Machine.
        /// </summary>
        public Machine Machine
        {
            get
            {
                return machine;
            }
        }

        private DateTime scheduledStartTime;
        /// <summary>
        /// Scheduled start time.
        /// </summary>
        public DateTime ScheduledStartTime
        {
            get
            {
                return scheduledStartTime;
            }
        }

        private string activityName;
        /// <summary>
        /// Activity name.
        /// </summary>
        public string ActivityName
        {
            get
            {
                return activityName;
            }
        }

        private string scheduledActivityCode;
        /// <summary>
        /// Scheduled activity code.
        /// </summary>
        public string ScheduledActivityCode
        {
            get
            {
                return scheduledActivityCode;
            }
        }

        /// <summary>
        /// Validation appointment status open.
        /// </summary>
        /// <remarks>  
        /// Values in openstatus.xml.
        /// </remarks> 
        public static bool IsStatusOpen(string input)
        {
            bool hasValue = false;

            List<string> statusopen = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"openstatus.xml");

            XmlNodeList statusopenList = doc.SelectNodes("openstatus/statusvalue");
            foreach (XmlNode Name in statusopenList)
            {
                statusopen.Add(Name.InnerText);
            }

            if (statusopen.Contains(input.ToUpper()))
            {
                hasValue = true;
            }

            return hasValue;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Appointment(Machine machine, DateTime scheduledStartTime, string activityName, string scheduledActivityCode)
        {
            this.machine = machine;
            this.scheduledStartTime = scheduledStartTime;
            this.activityName = activityName;
            this.scheduledActivityCode = scheduledActivityCode;
        }
    }
}