﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the image series.
    /// </summary>
    class ImageSeries
    {

        private string seriesId;
        /// <summary>
        /// Series id.
        /// </summary>
        public string SeriesId
        {
            get
            {
                return seriesId;
            }
        }

        private string seriesModality;
        /// <summary>
        /// Series modality.
        /// </summary>
        public string SeriesModality
        {
            get
            {
                return seriesModality;
            }
        }

        private string patientOrientation;
        /// <summary>
        /// Patient orientation.
        /// </summary>
        public string PatientOrientation
        {
            get
            {
                return patientOrientation;
            }
        }

        private DateTime creationDate;
        /// <summary>
        /// Creation date.
        /// </summary>
        public DateTime CreationDate
        {
            get
            {
                return creationDate;
            }
        }

        private string imageId;
        /// <summary>
        /// Image id.
        /// </summary>
        public string ImageId
        {
            get
            {
                return imageId;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        public Tuple<double, double, double> UserOrigin { get; }

        /// <summary>
        /// Constructor series and without plan.
        /// </summary>
        public ImageSeries(string seriesId, string seriesModality, string patientOrientation, string imageId, DateTime creationDate)
        {
            this.seriesId = seriesId;
            this.seriesModality = seriesModality;
            this.patientOrientation = patientOrientation;
            this.imageId = imageId;
            this.creationDate = creationDate;
        }

        /// <summary>
        /// Constructor series and plan.
        /// </summary>
        public ImageSeries(string seriesId, string seriesModality, string patientOrientation, string imageId, DateTime creationDate, Tuple<double, double, double> userOrigin, Plan plan)
        {
            this.seriesId = seriesId;
            this.seriesModality = seriesModality;
            this.patientOrientation = patientOrientation;
            this.imageId = imageId;
            this.creationDate = creationDate;
            this.UserOrigin = userOrigin;
            this.plan = plan;
        }
    }
}
