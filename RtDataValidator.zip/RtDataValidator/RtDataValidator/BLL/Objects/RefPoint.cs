﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the reference point.
    /// </summary>
    class RefPoint
    {

        private string refPointId;
        /// <summary>
        /// Ref point id.
        /// </summary>
        public string RefPointId
        {
            get
            {
                return refPointId;
            }
        }

        private string refPointType;

        public string RefPointType
        {
            get
            {
                return refPointType;
            }
        }

        private long refPointTotalDoseLimit;

        public long RefPointTotalDoseLimit
        {
            get
            {
                return refPointTotalDoseLimit;
            }
        }

        private long refPointDailyDoseLimit;

        public long RefPointDailyDoseLimit
        {
            get
            {
                return refPointDailyDoseLimit;
            }
        }


        private long refPointSessionDoseLimit;

        public long RefPointSessionDoseLimit
        {
            get
            {
                return refPointSessionDoseLimit;
            }
        }

        private int planNoFractions;

        public int PlanNoFractions
        {
            get
            {
                return planNoFractions;
            }
        }


        private double planPrescribedDose;

        public double PlanPrescribedDose
        {
            get
            {
                return planPrescribedDose;
            }
        }



        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        public bool hasRefPointLocation;

        public bool HasRefPointLocation 
        {
            get
            {
                return hasRefPointLocation;
            }
        }

         /// <summary>
        /// Constructor.
        /// </summary>
        public RefPoint(string refPointId, Plan plan, bool hasRefPointLocation, string refPointType, long refPointTotalDoseLimit, long refPointDailyDoseLimit, long refPointSessionDoseLimit, int planNoFractions, double planPrescribedDose)
        {
            this.refPointId = refPointId;
            this.plan = plan;
            this.hasRefPointLocation = hasRefPointLocation;
            this.refPointType = refPointType;
            this.refPointTotalDoseLimit = refPointTotalDoseLimit;
            this.refPointDailyDoseLimit = refPointDailyDoseLimit;
            this.refPointSessionDoseLimit = refPointSessionDoseLimit;
            this.planNoFractions = planNoFractions;
            this.planPrescribedDose = planPrescribedDose;
        }
    }
}