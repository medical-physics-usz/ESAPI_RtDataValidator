﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the structure object.
    /// </summary>
    class Structure
    {

        private string structureId;
        /// <summary>
        /// Structure id.
        /// </summary>
        public string StructureId
        {
            get
            {
                return structureId;
            }
        }

        private string structureStatus;
        /// <summary>
        /// Structure status.
        /// </summary>
        public string StructureStatus
        {
            get
            {
                return structureStatus;
            }
        }

        private string volumeType;
        /// <summary>
        /// Volume type.
        /// </summary>
        public string VolumeType
        {
            get
            {
                return volumeType;
            }
        }

        private string statusUserName;
        /// <summary>
        /// Structure status user name.
        /// </summary>
        public string StatusUserName

        {
            get
            {
                return statusUserName;
            }
        }

        /// <summary>
        /// Density override
        /// </summary>
        public string AssignedHU { get; set; }


        private string structureSer;
        /// <summary>
        /// Structure UID
        /// </summary>
        public string StructureSer

        {
            get
            {
                return structureSer;
            }
        }

        private string resolution;
        /// <summary>
        /// Structure resolution
        /// </summary>
        public string Resolution

        {
            get
            {
                return resolution;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Structure(string structureId, string structureStatus, string statusUserName, string volumeType, Plan plan, string AssignedHU, string structureSer, string resolution)
        {   
            this.structureId = structureId;       
            this.structureStatus = structureStatus;
            this.statusUserName = statusUserName;
            this.volumeType = volumeType;
            this.plan = plan;
            this.AssignedHU = AssignedHU;
            this.structureSer = structureSer;
            this.resolution = resolution;
        }
    }
}
