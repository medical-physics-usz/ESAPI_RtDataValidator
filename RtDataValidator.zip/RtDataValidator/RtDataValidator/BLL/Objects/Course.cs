﻿using System;
using System.Collections.Generic;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Course object.
    /// </summary>
    class Course
    {
        private Patient patient;
        /// <summary>
        /// Patient.
        /// </summary>
        public Patient Patient
        {
            get
            {
                return patient;
            }
        }

        private Diagnosis diagnosis;
        /// <summary>
        /// Diagnosis.
        /// </summary>
        public Diagnosis Diagnosis
        {
            get
            {
                return diagnosis;
            }
        }

        private string courseId;
        /// <summary>
        /// Course id.
        /// </summary>
        public string CourseId
        {
            get
            {
                return courseId;
            }
        }

        private DateTime startDateTime;
        /// <summary>
        /// Start date time.
        /// </summary>
        public DateTime StartDateTime
        {
            get
            {
                return startDateTime;
            }
        }

        private DateTime completedDateTime;
        /// <summary>
        /// Completed date time.
        /// </summary>
        public DateTime CompletedDateTime
        {
            get
            {
                return completedDateTime;
            }
        }

        private string clinicalStatus;
        /// <summary>
        /// Clinical status.
        /// </summary>
        public string ClinicalStatus
        {
            get
            {
                return clinicalStatus;
            }
        }

        private string courseIntent;
        /// <summary>
        /// Intent.
        /// </summary>
        public string CourseIntent
        {
            get
            {
                return courseIntent;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Course(Patient patient, Diagnosis diagnosis, string courseId, DateTime startDateTime, DateTime completedDateTime, string clinicalStatus, string courseIntent, Plan plan)
        {
            this.patient = patient;
            this.diagnosis = diagnosis;
            this.courseId = courseId;
            this.startDateTime = startDateTime;
            this.completedDateTime = completedDateTime;
            this.clinicalStatus = clinicalStatus;
            this.courseIntent = courseIntent;
            this.plan = plan;
        }
    }

    /// <summary>
    /// Enum course intent.
    /// </summary>
    public enum CourseIntent
    {
        /// <summary>
        /// Unknown course intent.
        /// </summary>
        Unknown,
        /// <summary>
        /// Benign course intent.
        /// </summary>
        Benign,
        /// <summary>
        /// Curative course intent.
        /// </summary>
        Curative,
        /// <summary>
        /// Palliative course intent.
        /// </summary>
        Palliative,
        /// <summary>
        /// Palliative for symtom control course intent.
        /// </summary>
        PalliativeSC,
        /// <summary>
        /// Local ablation course intent.
        /// </summary>
        LoacalAblation

    }
}