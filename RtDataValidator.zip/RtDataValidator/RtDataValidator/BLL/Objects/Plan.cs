﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the plan object.
    /// </summary>
    class Plan
    {

        private string courseId;
        /// <summary>
        /// Course id.
        /// </summary>
        public string CourseId
        {
            get
            {
                return courseId;
            }
        }


        private long planSetupSer;
        /// <summary>
        /// Plan setup ser.
        /// </summary>
        public long PlanSetupSer
        {
            get
            {
                return planSetupSer;
            }
        }

        private string planSetupId;
        /// <summary>
        /// Plan setup id.
        /// </summary>
        public string PlanSetupId
        {
            get
            {
                return planSetupId;
            }
        }


        /// <summary>
        /// Plan Name.
        /// </summary>
        public string Name { get; set; }

        private string planIntent;
        /// <summary>
        /// Plan intent.
        /// </summary>
        public string PlanIntent
        {
            get
            {
                return planIntent;
            }
        }

        private int noFractions;
        /// <summary>
        /// Number of fractions.
        /// </summary>
        public int NoFractions
        {
            get
            {
                return noFractions;
            }
        }

        private double prescribedDose;
        /// <summary>
        /// Prescribed dose.
        /// </summary>
        public double PrescribedDose
        {
            get
            {
                return prescribedDose;
            }
        }

        private string treatmentOrientation;
        /// <summary>
        /// Treatment orientation.
        /// </summary>
        public string TreatmentOrientation
        {
            get
            {
                return treatmentOrientation;
            }
        }

        private string calcModelOptions;
        /// <summary>
        /// Calculation model options (xml).
        /// </summary>
        public string CalcModelOptions
        {
            get
            {
                return calcModelOptions;
            }
        }

        private string planSetupStatus;
        /// <summary>
        /// Plan setup status.
        /// </summary>
        public string PlanSetupStatus
        {
            get
            {
                return planSetupStatus;
            }
        }

        /// <summary>
        /// Plan setup status.
        /// Completed, CompletedEarly, Rejected and Retired are not editable.
        /// UnApproved, Reviewed, PlanningApproved, TreatmentApproved, UnPlannedTreatment and ExternallyApproved are examples of editable plans.
        /// </summary>
        public EditableStatus PlanSetupStatusEditable
        {
            get
            {
                if (planStatusOptionsNonEditable().Contains(planSetupStatus))
                {
                    return EditableStatus.NO;
                }
                else
                {
                    return EditableStatus.YES;
                }
            }
        }

        /// <summary>
        /// Non editable status options.
        /// Completed, CompletedEarly, Rejected and Retired.
        /// </summary>
        /// <remarks>  
        /// Values in noneditableplans.xml.
        /// </remarks>
        private List<string> planStatusOptionsNonEditable()
        {
            List<string> options = new List<string>();

            XmlFileHandler xr = new XmlFileHandler();

            options = xr.GetStringList(@"noneditableplans.xml", @"statusvalues/statusvalue");

            return options;
        }

        private DateTime creationDate;
        /// <summary>
        /// Creation date.
        /// </summary>
        public DateTime CreationDate
        {
            get
            {
                return creationDate;
            }
        }

        /// <summary>
        /// Total dose.
        /// </summary>
        public double TotalDose()
        {
            double totalDose = 0d;

            totalDose = Math.Round(noFractions * prescribedDose, 2, MidpointRounding.AwayFromZero);

            return totalDose;
        }

        /// <summary>
        /// Modulated plan type.
        /// </summary>
        /// <remarks>  
        /// Values in modulatedplans.xml.
        /// </remarks>
        public bool IsModulatedPlan
        {
            get
            {
                bool isModulatedPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();

                    XmlFileHandler xr = new XmlFileHandler();

                    isModulatedPlan = xr.HasValueInXmlList(planAbbreviation, @"modulatedplans.xml", @"plantypes/abbreviation");
                }

                return isModulatedPlan;
            }
        }

        /// <summary>
        /// Stereo plan type.
        /// </summary>
        /// <remarks>  
        /// Values in stereoplans.xml.
        /// </remarks>
        public bool IsStereoAllPlan
        {
            get
            {
                bool isStereoAllPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();

                    XmlFileHandler xr = new XmlFileHandler();

                    isStereoAllPlan = xr.HasValueInXmlList(planAbbreviation, @"stereoplans.xml", @"plantypes/abbreviation");
                }

                return isStereoAllPlan;
            }
        }

        /// <summary>
        /// Stereotactic excluding body stereotactic plan type.
        /// </summary>
        /// <remarks>  
        /// Values in stereonobodyplans.xml.
        /// </remarks>
        public bool IsStereoNoBodyPlan
        {
            get
            {
                bool isStereoNoBodyPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();

                    XmlFileHandler xr = new XmlFileHandler();

                    isStereoNoBodyPlan = xr.HasValueInXmlList(planAbbreviation, @"stereonobodyplans.xml", @"plantypes/abbreviation");
                }

                return isStereoNoBodyPlan;
            }
        }

        /// <summary>
        /// Stereo plan type.
        /// </summary>
        /// <remarks>  
        /// Value in adminsettings.xml.
        /// </remarks>
        public bool IsStereoPlan
        {
            get
            {
                bool isStereoPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();
                    string compValue = XmlFileHandler.GetSetting("stereoplan");

                    if (planAbbreviation.Equals(compValue))
                    {
                        isStereoPlan = true;
                    }
                }

                return isStereoPlan;
            }
        }

        /// <summary>
        /// Rapid arc plan type.
        /// </summary>
        /// <remarks>  
        /// Value in adminsettings.xml.
        /// </remarks>
        public bool IsRapidArcPlan
        {
            get
            {
                bool isRapidArcPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();
                    string compValue = XmlFileHandler.GetSetting("rapidarcplan");

                    if (planAbbreviation.Equals(compValue))
                    {
                        isRapidArcPlan = true;
                    }
                }

                return isRapidArcPlan;
            }
        }

        /// <summary>
        /// Stereotactic body radiotherapy plan type.
        /// </summary>
        /// <remarks>  
        /// Value in adminsettings.xml.
        /// </remarks>
        public bool IsSbrtPlan
        {
            get
            {
                bool isSbrtPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();
                    string compValue = XmlFileHandler.GetSetting("sbrtplan");

                    if (planAbbreviation.Equals(compValue))
                    {
                        isSbrtPlan = true;
                    }
                }

                return isSbrtPlan;
            }
        }

        /// <summary>
        /// Radiosurgery plan type.
        /// </summary>
        /// <remarks>  
        /// Value in adminsettings.xml.
        /// </remarks>
        public bool IsRadioSurgeryPlan
        {
            get
            {
                bool isRadioSurgeryPlan = false;

                // Get prefix.
                if (planSetupId.Length >= 2)
                {
                    string planAbbreviation = planSetupId.Substring(0, 2).Trim();
                    string compValue = XmlFileHandler.GetSetting("radsurgeryplan");

                    if (planAbbreviation.Equals(compValue))
                    {
                        isRadioSurgeryPlan = true;
                    }
                }

                return isRadioSurgeryPlan;
            }
        }


        /// <summary>
        /// Constructor with all parameters (implementation plan validation).
        /// </summary>
        public Plan(string courseId, long planSetupSer, string planSetupId, int noFractions, double prescribedDose, string planSetupStatus, string treatmentOrientation, string calcModelOptions, DateTime creationDate, string Name, string planIntent)
        {
            this.courseId = courseId;
            this.planSetupSer = planSetupSer;
            this.planSetupId = planSetupId;
            this.noFractions = noFractions;
            this.prescribedDose = prescribedDose;
            this.planSetupStatus = planSetupStatus;
            this.treatmentOrientation = treatmentOrientation;
            this.calcModelOptions = calcModelOptions;
            this.creationDate = creationDate;
            this.Name = Name;
            this.planIntent = planIntent;
        }

        /// <summary>
        /// Constructor with planSetupSer, planSetupId and planSetupStatus.
        /// </summary>
        public Plan(string courseId, long planSetupSer, string planSetupId, string planSetupStatus)
        {
            this.courseId = courseId;
            this.planSetupSer = planSetupSer;
            this.planSetupId = planSetupId;
            this.planSetupStatus = planSetupStatus;
        }
    }
}