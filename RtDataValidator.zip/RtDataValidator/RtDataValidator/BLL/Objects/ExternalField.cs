﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the external field object.
    /// </summary>
    class ExternalField
    {

        private string radiationId;
        /// <summary>
        /// Radiation Id.
        /// </summary>
        public string RadiationId
        {
            get
            {
                return radiationId;
            }
        }

        private string radiationName;
        /// <summary>
        /// Radiation name.
        /// </summary>
        public string RadiationName
        {
            get
            {
                return radiationName;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        private Machine machine;
        /// <summary>
        /// Machine.
        /// </summary>
        public Machine Machine
        {
            get
            {
                return machine;
            }
        }

        private int setupFieldFlag;
        /// <summary>
        /// Set up field flag.
        /// </summary>
        public int SetupFieldFlag
        {
            get
            {
                return setupFieldFlag;
            }
        }

        private double isoCenterPositionX;
        /// <summary>
        /// Iso center position X.
        /// </summary>
        public double IsoCenterPositionX
        {
            get
            {
                return isoCenterPositionX;
            }
        }

        private double isoCenterPositionY;
        /// <summary>
        /// Iso center position Y.
        /// </summary>
        public double IsoCenterPositionY
        {
            get
            {
                return isoCenterPositionY;
            }
        }

        private double isoCenterPositionZ;
        /// <summary>
        /// Iso center position Z.
        /// </summary>
        public double IsoCenterPositionZ
        {
            get
            {
                return isoCenterPositionZ;
            }
        }

        private double patientSupportAngle;
        /// <summary>
        /// Patient support angle.
        /// </summary>
        public double PatientSupportAngle
        {
            get
            {
                return patientSupportAngle;
            }
        }

        private double gantryRtn;
        /// <summary>
        /// Gantry rotation.
        /// </summary>
        public double GantryRtn
        {
            get
            {
                return gantryRtn;
            }
        }

        private double collX1;
        /// <summary>
        /// Collimator X1.
        /// </summary>
        public double CollX1
        {
            get
            {
                return collX1;
            }
        }

        private double collX2;
        /// <summary>
        /// Collimator X2.
        /// </summary>
        public double CollX2
        {
            get
            {
                return collX2;
            }
        }

        private double collY1;
        /// <summary>
        /// Collimator Y1.
        /// </summary>
        public double CollY1
        {
            get
            {
                return collY1;
            }
        }

        private double collY2;
        /// <summary>
        /// Collimator Y2.
        /// </summary>
        public double CollY2
        {
            get
            {
                return collY2;
            }
        }

        private double collRtn;
        /// <summary>
        /// Collimator rotation.
        /// </summary>
        public double CollRtn
        {
            get
            {
                return collRtn;
            }
        }
        
        private double energy;
        /// <summary>
        /// Energy.
        /// </summary>
        public double Energy
        {
            get
            {
                return energy;
            }
        }

        private string radiationType;
        /// <summary>
        /// Radiation type.
        /// </summary>
        public string RadiationType
        {
            get
            {
                return radiationType;
            }
        }

        private int doseRate;
        /// <summary>
        /// Dose rate.
        /// </summary>
        public int DoseRate
        {
            get
            {
                return doseRate;
            }
        }

        private double monitorUnits;
        /// <summary>
        /// Monitor units.
        /// </summary>
        public double MonitorUnits
        {
            get
            {
                return monitorUnits;
            }
        }

        private string techniqueId;
        /// <summary>
        /// Technique id.
        /// </summary>
        public string TechniqueId
        {
            get
            {
                return techniqueId;
            }
        }

        /// <summary>
        /// Add on type.
        /// </summary>
        public string AddOnType { get; set; }

        private double ssd;
        /// <summary>
        /// Ssd.
        /// </summary>
        public double Ssd
        {
            get
            {
                return ssd;
            }
        }

        private double couchLat;
        /// <summary>
        /// couchLat, .
        /// </summary>
        public double CouchLat
        {
            get
            {
                return couchLat;
            }
        }

        private double couchLatDelta;
        /// <summary>
        /// CouchLatDelta, .
        /// </summary>
        public double CouchLatDelta
        {
            get
            {
                return couchLatDelta;
            }
        }

        private double couchLng;
        /// <summary>
        /// CouchLng, .
        /// </summary>
        public double CouchLng
        {
            get
            {
                return couchLng;
            }
        }

        private double couchLngDelta;
        /// <summary>
        /// couchLngDelta, .
        /// </summary>
        public double CouchLngDelta
        {
            get
            {
                return couchLngDelta;
            }
        }

        private double couchVrt;
        /// <summary>
        /// couchVrt, .
        /// </summary>
        public double CouchVrt
        {
            get
            {
                return couchVrt;
            }
        }

        private double couchVrtDelta;
        /// <summary>
        /// couchVrtDelta, .
        /// </summary>
        public double CouchVrtDelta
        {
            get
            {
                return couchVrtDelta;
            }
        }

        private bool gating;
        /// <summary>
        /// gating, .
        /// </summary>
        public bool Gating
        {
            get
            {
                return gating;
            }
        }

        private string gantryRtnDirection;
        /// <summary>
        /// Gantry rotation direction (CC, CW or NONE).
        /// </summary>
        public string GantryRtnDirection
        {
            get
            {
                return gantryRtnDirection;
            }
        }





        /// <summary>
        /// Constructor geometric information.
        /// </summary>
        public ExternalField(string radiationId, string radiationName, int setupFieldFlag, double isoCenterPositionX, double isoCenterPositionY, double isoCenterPositionZ, double patientSupportAngle, double ssd, double gantryRtn, double collX1, double collX2, double collY1, double collY2, double collRtn, string techniqueId, Plan plan, Machine machine, double couchLat, double couchLatDelta, double couchLng, double couchLngDelta, double couchVrt, double couchVrtDelta, bool gating, string gantryRtnDirection)
        {
            this.radiationId = radiationId;
            this.radiationName = radiationName;       
            this.setupFieldFlag = setupFieldFlag;
            this.isoCenterPositionX = isoCenterPositionX;
            this.isoCenterPositionY = isoCenterPositionY;
            this.isoCenterPositionZ = isoCenterPositionZ;
            this.patientSupportAngle = patientSupportAngle;
            this.ssd = ssd;
            this.gantryRtn = gantryRtn;
            this.collX1 = collX1;
            this.collX2 = collX2;
            this.collY1 = collY1;
            this.collY2 = collY2;
            this.collRtn = collRtn;
            this.techniqueId = techniqueId;
            this.plan = plan;
            this.machine = machine;
            this.couchLat = couchLat;
            this.couchLatDelta = couchLatDelta;
            this.couchLng = couchLng;
            this.couchLngDelta = couchLngDelta;
            this.couchVrt = couchVrt;
            this.couchVrtDelta = couchVrtDelta;
            this.gating = gating;
            this.gantryRtnDirection = gantryRtnDirection;
        }

        /// <summary>
        /// Constructor dosimetry treatment fields.
        /// </summary>
        public ExternalField(string radiationId, double energy, string radiationType, int doseRate, double monitorUnits, string techniqueId, string addOnType, double ssd, Plan plan)
        {
            this.radiationId = radiationId;       
            this.energy = energy;
            this.radiationType = radiationType;
            this.doseRate = doseRate;
            this.monitorUnits = monitorUnits;
            this.techniqueId = techniqueId;
            this.AddOnType = addOnType;
            this.ssd = ssd;
            this.plan = plan;
        }
    }
}