﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the oncologist object.
    /// </summary>
    public class Oncologist
    {

        private int oncologistSer;
        /// <summary>
        /// Oncologist serial number.
        /// </summary>
        public int OncologistSer
        {
            get
            {
                return oncologistSer;
            }
        }

        private string doctorId;
        /// <summary>
        /// Doctor id.
        /// </summary>
        public string DoctorId
        {
            get
            {
                return doctorId;
            }
        }

        private string aliasName;
        /// <summary>
        /// Alias name.
        /// </summary>
        public string AliasName
        {
            get
            {
                return aliasName;
            }
        }

        /// <summary>
        /// Constructor with oncologist serial number.
        /// </summary>
        public Oncologist(int oncologistSer)
        {
            this.oncologistSer = oncologistSer;
        }

        /// <summary>
        /// Constructor with oncologist details.
        /// </summary>
        public Oncologist(string doctorId, string aliasName)
        {
            this.doctorId = doctorId;
            this.aliasName = aliasName;
        }
    }
}
