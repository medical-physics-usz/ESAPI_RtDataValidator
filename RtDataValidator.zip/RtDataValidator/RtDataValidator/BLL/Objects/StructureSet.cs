﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the structure set object.
    /// </summary>
    class StructureSet
    {

        private string structureSetId;
        /// <summary>
        /// Structure set id.
        /// </summary>
        public string StructureSetId
        {
            get
            {
                return structureSetId;
            }
        }

        public string PhysicalMaterialTable { get; private set; }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        public string ImageId { get; private set; }


        /// <summary>
        /// Constructor.
        /// </summary>
        public StructureSet(string structureSetId, string physicalMaterialTable, Plan plan, string imageId)
        {
            this.structureSetId = structureSetId;
            this.PhysicalMaterialTable = physicalMaterialTable;
            this.plan = plan;
            this.ImageId = imageId;
        }
    }
}