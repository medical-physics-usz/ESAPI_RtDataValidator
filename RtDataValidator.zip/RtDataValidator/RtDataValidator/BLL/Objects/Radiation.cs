﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the treatment record.
    /// </summary>
    class Radiation
    {

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        private string machineId;
        /// <summary>
        /// Course id.
        /// Only course id used, therefore no course object.
        /// </summary>
        public string MachineId
        {
            get
            {
                return machineId;
            }
        }

        private string courseStatus;
        /// <summary>
        /// Course clinical status.
        /// </summary>
        public string CourseStatus
        {
            get
            {
                return courseStatus;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Radiation(Plan plan, string machineId, string courseStatus)
        {
            this.plan = plan;
            this.machineId = machineId;
            this.courseStatus = courseStatus;
        }
    }
}
