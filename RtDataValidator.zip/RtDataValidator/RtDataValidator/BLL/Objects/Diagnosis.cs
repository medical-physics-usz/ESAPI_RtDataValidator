﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the diagnosis object.
    /// </summary>
    class Diagnosis
    {
        private string diagnosisCode;
        /// <summary>
        /// Diagnosis code.
        /// </summary>
        public string DiagnosisCode
        {
            get
            {
                return diagnosisCode;
            }
        }

        /// <summary>
        /// Get diagnosis table.
        /// </summary>
        public DiagnosisTable GetDiagnosisTable()
        {
            DiagnosisTable diagntbl = new DiagnosisTable();

            diagntbl = DiagnosisTable.UNKNOWN;

            if (diagnosisTableName.Contains("ICD-9"))
            {
                diagntbl = DiagnosisTable.ICD9;
            }
            if (diagnosisTableName.Contains("ICD-10"))
            {
                diagntbl = DiagnosisTable.ICD10;
            }

            return diagntbl;
        }

        private string diagnosisTableName;
        /// <summary>
        /// Diagnosis table name.
        /// </summary>
        public string DiagnosisTableName
        {
            get
            {
                return diagnosisTableName;
            }
        }

        private DateTime dateStamp = DateTime.MaxValue;
        /// <summary>
        /// Date time stamp entry.
        /// </summary>
        public DateTime DateStamp
        {
            get
            {
                return dateStamp;
            }
        }

        private string description;
        /// <summary>
        /// Description
        /// </summary>
        public string Description
        {
            get
            {
                return description;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Diagnosis(string diagnosisCode, string diagnosisTableName, DateTime dateStamp, string description)
        {
            this.diagnosisCode = diagnosisCode;
            this.diagnosisTableName = diagnosisTableName;
            this.dateStamp = dateStamp;
            this.description = description;
        }
    }

    /// <summary>
    /// Enum diagnosis table.
    /// </summary>
    public enum DiagnosisTable
    {
        /// <summary>
        /// Unknown diagnosis table.
        /// </summary>
        UNKNOWN,
        /// <summary>
        /// ICD-9 diagnosis table.
        /// </summary>
        ICD9,
        /// <summary>
        /// ICD-10 diagnosis table.
        /// </summary>
        ICD10
    }
}
