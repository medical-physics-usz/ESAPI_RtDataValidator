﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the image slice.
    /// </summary>
    class ImageSlice
    {

        private string seriesId;
        /// <summary>
        /// Series id.
        /// </summary>
        public string SeriesId
        {
            get
            {
                return seriesId;
            }
        }

        private string imageId;
        /// <summary>
        /// Image id.
        /// </summary>
        public string ImageId
        {
            get
            {
                return imageId;
            }
        }

        private string sliceModality;
        /// <summary>
        /// Slice modality.
        /// </summary>
        public string SliceModality
        {
            get
            {
                return sliceModality;
            }
        }

        private double thickness;
        /// <summary>
        /// Slice thickness.
        /// </summary>
        public double SliceThickness
        {
            get
            {
                return thickness;
            }
        }

        private int sliceNumber;
        /// <summary>
        /// Slice number.
        /// </summary>
        public int SliceNumber
        {
            get
            {
                return sliceNumber;
            }
        }

        private double position;
        /// <summary>
        /// Slice position in mm.
        /// </summary>
        public double Position
        {
            get
            {
                return position;
            }
        }

        private Plan plan;
        /// <summary>
        /// Plan.
        /// </summary>
        public Plan Plan
        {
            get
            {
                return plan;
            }
        }

        private string structureSetId;
        /// <summary>
        /// Structure set ID
        /// </summary>
        public string StructureSetId
        {
            get
            {
                return structureSetId;
            }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public ImageSlice(string seriesId, string imageId, string sliceModality, double thickness, int sliceNumber, double position, Plan plan, string structureSetId)
        {
            this.seriesId = seriesId;
            this.imageId = imageId;
            this.sliceModality = sliceModality;
            this.thickness = thickness;
            this.sliceNumber = sliceNumber;
            this.position = position;
            this.plan = plan;
            this.structureSetId = structureSetId;
        }
    }
}
