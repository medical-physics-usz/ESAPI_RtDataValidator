﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the geometric external field validator.
    /// </summary>
    class ExternalFieldGeometryValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            ExternalFieldGeometryQuery qry = new ExternalFieldGeometryQuery();

            // All fields.
            List<ExternalField> externalfields = qry.GetExternalFields(patient);

            // Empty data set.
            if (externalfields.Count == 0)
            {
                TestObjectOutput too = new TestObjectOutput();
                tobjects.Add(too.EmptyTestObject(RtGroup.FIELD));
            }

            // Get collision table values (load once).
            CollisionTableHandler cth = new CollisionTableHandler();
            List<CollisionElement> collisionElements = cth.CollisionElementsInTable();

            foreach (ExternalField externalfield in externalfields)
            {
                tobjects.Add(RadiationIdValidator(externalfield));
                //tobjects.Add( FieldNameValidator( externalfield ) );   //160912, MM: not yet ready for implementation

                // Treatment fields.
                if (externalfield.SetupFieldFlag == 0)
                {
                    tobjects.Add(FieldSizeMinimalValidator(externalfield));
                    if ((externalfield.Machine.MachineId == "Edge2018") || (externalfield.Machine.MachineId == "TrueBeam1001"))
                    {
                        tobjects.Add(FieldSizeMaximumYaxisValidator_TB1_Edge(externalfield));
                    } else // TB2 and USZF
                    {
                        tobjects.Add(FieldSizeMaximumYaxisValidator_TB2_USZF(externalfield));
                    }
                    // Collimator verification if RA plan.
                    if (externalfield.Plan.IsModulatedPlan)
                    {
                        tobjects.Add(FieldSizeMaximumXaxisModulationValidator(externalfield));
                        tobjects.Add(CollimatorRotationValidator(externalfield));
                        
                        
                    }

                    // SSD if electron plan
                    if (externalfield.Plan.PlanSetupId.Length >= 2){
                        if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("EL"))
                        {
                            tobjects.Add(FieldSSDValidator(externalfield));
                        }
                    }
                   
                }

                // Collision detection if support angle is not zero.
                // Fields with control points  are checked as well in the control point section.
                if ((externalfield.PatientSupportAngle != 0) && (!externalfield.TechniqueId.Contains("ARC")))
                {
                    tobjects.Add(GantryCollisionValidator(externalfield, collisionElements));
                }


                tobjects.AddRange(BreastCouchKickValidator(externalfield));
            }




            tobjects.AddRange(GantryRotationValidator(externalfields));
            tobjects.AddRange(RadiationIdOrderValidatorPerPlan(externalfields));
            tobjects.AddRange(IsoCenterPositionsValidator(externalfields));
            tobjects.AddRange(NumberOfPatSupportAnglesValidator(externalfields));
            tobjects.AddRange(RadiationMachinePerPlanEqualValidator(externalfields));
            tobjects.AddRange(DeltaCouchShiftValidator(externalfields));
            tobjects.AddRange(GatingValidator(externalfields));
            


            return tobjects;
        }

        /// <summary>
        /// Validate radiation id.
        /// </summary>
        internal TestObject RadiationIdValidator(ExternalField externalfield)
        {

            bool isValid = false;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;

            string comment = "Unknown";

            if ((externalfield.RadiationId.Length == 2) && (externalfield.SetupFieldFlag == 0))
            {

                // A1.
                if ((Char.IsUpper(externalfield.RadiationId, 0)) && (Char.IsLetter(externalfield.RadiationId, 0)) && (Char.IsNumber(externalfield.RadiationId, 1)))
                {
                    isValid = true;
                }
            }

            if ((externalfield.RadiationId.Length == 3) && (externalfield.SetupFieldFlag == 0))
            {

                // AA1.
                if ((Char.IsUpper(externalfield.RadiationId, 0)) && (Char.IsLetter(externalfield.RadiationId, 0)) && (Char.IsUpper(externalfield.RadiationId, 1)) && (Char.IsLetter(externalfield.RadiationId, 1)) && (Char.IsNumber(externalfield.RadiationId, 2)))
                {
                    isValid = true;
                }

                // A10.
                if ((Char.IsUpper(externalfield.RadiationId, 0)) && (Char.IsLetter(externalfield.RadiationId, 0)) && (Char.IsNumber(externalfield.RadiationId, 1)) && (Char.IsNumber(externalfield.RadiationId, 2)))
                {
                    isValid = true;
                }
            }

            if ((externalfield.RadiationId.Length == 4) && (externalfield.SetupFieldFlag == 0))
            {

                // AA10.
                if ((Char.IsUpper(externalfield.RadiationId, 0)) && (Char.IsLetter(externalfield.RadiationId, 0)) && (Char.IsUpper(externalfield.RadiationId, 1)) && (Char.IsLetter(externalfield.RadiationId, 1)) && (Char.IsNumber(externalfield.RadiationId, 2)) && (Char.IsNumber(externalfield.RadiationId, 3)))
                {
                    isValid = true;
                }
            }

            if (externalfield.SetupFieldFlag == 1)
            {

                // AA10.
                if (Regex.IsMatch(externalfield.RadiationId, @"^[\.A-Za-z0-9 _°-]+$"))
                {
                    isValid = true;
                }
            }

            // Setup field invalid.
            if ((!isValid) && (externalfield.SetupFieldFlag == 1))
            {
                status = CheckResult.FAILED;
                comment = "Setup field ID '" + externalfield.RadiationId + "' for plan " + externalfield.Plan.PlanSetupId + ") invalid (expected 'A-Z,a-z,0-9, ,_,°,-,.' (e.g. Setup 0°)!";
            }

            // Treatment field invalid.
            if ((!isValid) && (externalfield.SetupFieldFlag == 0))
            {
                status = CheckResult.FAILED;
                comment = "Field ID '" + externalfield.RadiationId + "' for plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected '{CapitalLetter(s)}{Number(s)}' (e.g. A1, D2, AA1)!";
            }

            // Setup field valid.
            if ((isValid) && (externalfield.SetupFieldFlag == 1))
            {
                status = CheckResult.PASSED;
                comment = "Setup field ID '" + externalfield.RadiationId + "' for plan '" + externalfield.Plan.PlanSetupId + "' valid.";
            }

            // Treatment field valid.
            if ((isValid) && (externalfield.SetupFieldFlag == 0))
            {
                status = CheckResult.PASSED;
                comment = "Field ID '" + externalfield.RadiationId + "' for plan '" + externalfield.Plan.PlanSetupId + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate radiation id order per individual plan.
        /// </summary>
        internal List<TestObject> RadiationIdOrderValidatorPerPlan(List<ExternalField> externalfields)
        {

            List<TestObject> tobjects = new List<TestObject>();

            // Treatment fields.
            externalfields = externalfields.Where(e => e.SetupFieldFlag == 0).ToList();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {

                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer).ToList();

                // Check if there are less fields than 26 (alphabet).
                if (externalfieldsGrouped.Count > 0)
                {

                    bool isValid = false;

                    List<string> prefixes = new List<string>();

                    StringBuilder sbCompare = new StringBuilder();
                    StringBuilder sbOutput = new StringBuilder();

                    // Check fields and get the first letter.
                    foreach (ExternalField externalfield in externalfieldsGrouped)
                    {
                        if (externalfield.RadiationId.Length == 2)
                        {

                            if ((Char.IsLetter(externalfield.RadiationId, 0)) && (Char.IsNumber(externalfield.RadiationId, 1)))
                            {
                                string prefix = externalfield.RadiationId.Substring(0, 1).ToUpper().Trim();
                                sbCompare.Append(prefix);

                                sbOutput.Append(externalfield.RadiationId + " (" + prefix + "); ");
                            }
                            else
                            {
                                sbOutput.Append(externalfield.RadiationId + "; ");
                            }
                        }
                    }

                    // Compare the string with prefixes against the alphabet.
                    string compareString = "";
                    compareString = String.Concat(sbCompare.ToString().OrderBy(c => c));

                    string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

                    if (alphabet.Contains(compareString.Trim()))
                    {
                        isValid = true;
                    }

                    ExternalField ef1 = externalfieldsGrouped.First();

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.FIELD;
                    EditableStatus editable = ef1.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + ef1.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + ef1.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + ef1.Plan.PlanSetupId + " (" + ef1.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + ef1.Plan.CourseId;
                    string comment = "Unknown";

                    // Valid if compare string is in alphabet string.
                    if (isValid)
                    {
                        status = CheckResult.PASSED;
                        comment = "Field order for fields in plan '" + ef1.Plan.PlanSetupId + "' valid (expected A,B,C,...). Currently: " + sbOutput.ToString() + ".";
                        comment = comment.Replace(@"; .", @".");
                    }

                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Field order for fields in plan '" + ef1.Plan.PlanSetupId + "' invalid (expected A,B,C,...). Currently: " + sbOutput.ToString() + "!";
                        comment = comment.Replace(@"; !", @"!");
                    }

                    // Manual review if more than 26 letters.
                    if (externalfieldsGrouped.Count > 26)
                    {
                        status = CheckResult.MANREV;
                        comment = "Field order for " + externalfields.Count.ToString() + " fields cannot be checked (> 26 fields). Check manually.";
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Validate iso center positions per plan.
        /// The positions must be equal (at least for the trilogy accelerator).
        /// </summary>
        internal List<TestObject> IsoCenterPositionsValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ExternalField> externalfieldsGrouped = externalfields.Where(p => p.Plan.PlanSetupSer == planSetupSer).ToList();

                if (externalfieldsGrouped.Count > 0)
                {
                    // Get first element.
                    ExternalField efIsoFirst = externalfieldsGrouped.First();

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.PLAN;
                    EditableStatus editable = efIsoFirst.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + efIsoFirst.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + efIsoFirst.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + efIsoFirst.Plan.PlanSetupId + " (" + efIsoFirst.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + efIsoFirst.Plan.CourseId;
                    string comment = "Unknown";

                    List<string> radiationids = new List<string>();
                    List<string> coordinates = new List<string>();

                    // Info string in cm.
                    string isoInfo = "";
                    foreach (ExternalField ef in externalfieldsGrouped)
                    {
                        isoInfo =
                        (ef.IsoCenterPositionX / 10).ToString() + ";" +
                    (ef.IsoCenterPositionY / 10).ToString() + ";" +
                    (ef.IsoCenterPositionZ / 10).ToString();

                        radiationids.Add(ef.RadiationId);
                        coordinates.Add(isoInfo);
                    }

                    string isoFirst = coordinates.First();

                    bool hasEqualCoordinates = coordinates.All(c => c == isoFirst);

                    if (hasEqualCoordinates)
                    {

                        status = CheckResult.PASSED;
                        comment = "Field iso center positions are equal (expected single isocenter). Coordinates all fields (X,Y,Z): " + isoInfo + ".";
                    }
                    else
                    {
                        StringBuilder sb = new StringBuilder();

                        for (int i = 0; i < radiationids.Count; i++)
                        {
                            string radiationid = radiationids.ElementAt(i);
                            string coordinate = coordinates.ElementAt(i);

                            sb.Append("Field " + radiationid + "(" + coordinate + ")#");
                        }

                        status = CheckResult.FAILED;
                        comment = "Field iso center positions are not equal (expected single isocenter)! Coordinates for all fields (X;Y;Z):" + sb.ToString() + ".";

                        comment = comment.Remove(comment.LastIndexOf("#"), 1);
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);
                    tobjects.Add(to);
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Validate number of patient support angles per plan.
        /// If stereotactic treatment excluding SBRT then at least 3 angles.
        /// </summary>
        internal List<TestObject> NumberOfPatSupportAnglesValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get external fields stereo excluding sbrt.
            externalfields = externalfields.Where(e => e.Plan.IsStereoNoBodyPlan).ToList();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer).ToList();

                int count = externalfieldsGrouped.Select(x => x.PatientSupportAngle).Distinct().Count();

                ExternalField externalfield = new ExternalField("", "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", new Plan("", 0, "", ""), new Machine("", ""), 0,0,0,0,0,0,false,"");

                if (externalfieldsGrouped.Count > 0)
                {
                    externalfield = externalfieldsGrouped.ElementAt(0);

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.PLAN;
                    EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                    string comment = "Unknown";

                    if (count < 3)
                    {
                        status = CheckResult.FAILED;
                        comment = "Number of support angles = '" + count.ToString() + "' for plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected >= 3 angles for ST/SR plans)!";
                    }
                    else
                    {
                        status = CheckResult.PASSED;
                        comment = "Number of support angles = '" + count.ToString() + "' for plan '" + externalfield.Plan.PlanSetupId + "' valid (expected >= 3 angles for ST/SR plans).";
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                    tobjects.Add(to);
                }
            }

            return tobjects;
        }


        /// <summary>
        /// Validate the couch kicks for 5 fields 3D boost breast
        /// Left should have 90, Right should have 270
        /// </summary>
        internal List<TestObject> BreastCouchKickValidator(ExternalField externalfield)
        {

            bool is3dBreast = false;
            bool isKickCorrect = false;

            if (externalfield.Plan.PlanSetupId.StartsWith("3Dbr"))
            {
                is3dBreast = true;
            }

            // Check kicks
            if (externalfield.Plan.PlanSetupId.StartsWith("3Dbrl"))
            {
                // this should have 90
                if (externalfield.PatientSupportAngle >= 10 || externalfield.PatientSupportAngle <= 350)
                {
                    if (externalfield.PatientSupportAngle >= 89 && externalfield.PatientSupportAngle <= 91)
                    {
                        isKickCorrect = true;
                    }
                }
            }

            if (externalfield.Plan.PlanSetupId.StartsWith("3Dbrr"))
            {
                // this should have 270
                if (externalfield.PatientSupportAngle >= 10 || externalfield.PatientSupportAngle <= 350)
                {
                    if (externalfield.PatientSupportAngle >= 269 && externalfield.PatientSupportAngle <= 271)
                    {
                        isKickCorrect = true;
                    }
                }
            }

            // correct if couck kicks is 0
            if (externalfield.PatientSupportAngle <= 10 || externalfield.PatientSupportAngle >= 350)
            {
                isKickCorrect = true;
            }



            // Return test object
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string comment = "Unknown";

            List<TestObject> tobjects = new List<TestObject>();

            if (is3dBreast && !externalfield.RadiationId.Contains("Setup"))
            {
                if (isKickCorrect)
                {
                    status = CheckResult.PASSED;
                    comment = "Couch kick " + externalfield.PatientSupportAngle.ToString() +  "° for field '" + externalfield.RadiationId + "' of  3D breast plan '" + externalfield.Plan.PlanSetupId + "' is valid (expected 0° for 3 fields and 270° for Breast-right or 90° for Breast-left)!";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "Couch kick " + externalfield.PatientSupportAngle.ToString() + "° for field '" + externalfield.RadiationId + "' of  3D breast plan '" + externalfield.Plan.PlanSetupId + "' is invalid (expected 0° for 3 fields and 270° for Breast-right or 90° for Breast-left)!";
                }

                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                tobjects.Add(to);


            }

            return tobjects;
        }


        /// <summary>
        /// Validate radiation gantry collision with a support angle.
        /// </summary>
        internal TestObject GantryCollisionValidator(ExternalField externalfield, List<CollisionElement> collisionElements)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            string fieldInfo = "support angle '" + externalfield.PatientSupportAngle.ToString() + "°' and gantry rotation '" + externalfield.GantryRtn.ToString() + "°'";

            CollisionTableHandler cth = new CollisionTableHandler();

            // Collision.
            if (cth.HasElementInCollisionTable(collisionElements, externalfield.PatientSupportAngle, externalfield.GantryRtn))
            {
                status = CheckResult.FAILED;
                comment = "Field collision test (STATIC fields) for '" + externalfield.RadiationId + "' and plan " + externalfield.Plan.PlanSetupId + " and " + fieldInfo + " invalid (element in collision table; enter new values in table)!";
            }
            // No collision.
            else
            {
                status = CheckResult.PASSED;
                comment = "Field collision test for (STATIC fields) '" + externalfield.RadiationId + "' and plan " + externalfield.Plan.PlanSetupId + " and " + fieldInfo + " valid (element not in collision table; enter new values in table).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

     

        /// <summary>
        /// Validate minimal field sizes.
        /// Field size must be larger than 1 cm.
        /// </summary>
        internal TestObject FieldSizeMinimalValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            //// Absolute values (not negative).
            //double collX1 = Math.Abs( externalfield.CollX1 );
            //double collX2 = Math.Abs( externalfield.CollX2 );
            //double collY1 = Math.Abs( externalfield.CollY1 );
            //double collY2 = Math.Abs( externalfield.CollY2 );

            //double collX = collX1 + collX2;
            //double collY = collY1 + collY2;
            //
            // 161007, MM: use of absolute values incorrect, can have negative values for any of them,
            //             and calculation using simple subtraction X2 - X1, Y2 - Y1 of values returns correct X and Y jaw openings

            double collX = externalfield.CollX2 - externalfield.CollX1;
            double collY = externalfield.CollY2 - externalfield.CollY1;

            // Field size X < 1 cm.
            if (collX < 1)
            {
                status = CheckResult.FAILED;
                comment = "Minimal field size X jaws '" + collX.ToString("0.##") + "cm' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected >= 1cm)!";
            }

            // Field size Y < 1 cm.
            if (collY < 1)
            {
                status = CheckResult.FAILED;
                comment = "Minimal field size Y jaws '" + collY.ToString("0.##") + "cm' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected >= 1cm)!";
            }

            // Field size X and Y >= 1 cm.
            if ((collX >= 1) && (collY >= 1))
            {
                status = CheckResult.PASSED;
                comment = "Minimal field size X jaws '" + collX.ToString("0.##") + "cm' / Y jaws '" + collY.ToString("0.##") + "cm' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected >= 1cm).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Validate maximal field size X axis for modulated plans.
        /// </summary>
        internal TestObject FieldSizeMaximumXaxisModulationValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            //// Absolute values (not negative).
            //double collX1 = Math.Abs(externalfield.CollX1);
            //double collX2 = Math.Abs(externalfield.CollX2);

            //double collX = collX1 + collX2;
            //
            // 161007, MM: use of absolute values incorrect, can have negative values for any of them,
            //             and calculation using simple subtraction X2 - X1, Y2 - Y1 of values returns correct X and Y jaw openings

            double collX = externalfield.CollX2 - externalfield.CollX1;

            // Field size X < 15 cm.
            if ((collX < 15) && (externalfield.Plan.IsModulatedPlan))
            {
                status = CheckResult.PASSED;
                comment = "Maximal field size X jaws '" + collX.ToString("0.##") + "cm' (X1 = " + externalfield.CollX1.ToString() + ", X2 = " + externalfield.CollX2 + ") for modulated field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected < 15cm).";
            }

            // Field size X >= 15 cm.
            if ((collX >= 15) && (externalfield.Plan.IsModulatedPlan))
            {
                status = CheckResult.FAILED;
                comment = "Maximal field size X jaws '" + collX.ToString("0.##") + "cm' for modulated field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected < 15cm)!";
            }

            // No modulated plan.
            if (!externalfield.Plan.IsModulatedPlan)
            {
                status = CheckResult.NOCHECK;
                comment = "Machine ID'" + externalfield.Machine.MachineId + "NO CHECK: Maximal field size X jaws '" + collX.ToString("0.##") + "cm' ' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' is not validated (only for modulated fields).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Validate maximal field size Y axis for Truebeam and Edge.
        /// </summary>
        internal TestObject FieldSizeMaximumYaxisValidator_TB1_Edge(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            //// Absolute values (not negative).
            //double collX1 = Math.Abs(externalfield.CollX1);
            //double collX2 = Math.Abs(externalfield.CollX2);

            //double collX = collX1 + collX2;
            //
            // 161007, MM: use of absolute values incorrect, can have negative values for any of them,

            //             and calculation using simple subtraction X2 - X1, Y2 - Y1 of values returns correct X and Y jaw openings

            //double collX = externalfield.CollX2 - externalfield.CollX1;

            // Field size Y1 <= 10.9 cm.
            if ((Math.Abs(externalfield.CollY1) <= 10.9) && (Math.Abs(externalfield.CollY2) <= 10.9))
            {
                status = CheckResult.PASSED;
                comment = "Maximal position Y jaws cm (Y1 = " + externalfield.CollY1.ToString() + ", Y2 = " + externalfield.CollY2.ToString() + ") for  field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected <= 10.9cm).";
            }

            // Field size Y1 > 10.9 cm.
            if ((Math.Abs(externalfield.CollY1) > 10.9) || (Math.Abs(externalfield.CollY2) > 10.9))
            {
                status = CheckResult.FAILED;
                comment = "Maximal position Y jaws cm (Y1 = " + externalfield.CollY1.ToString() + ", Y2 = " + externalfield.CollY2.ToString() + ") for  field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected <= 10.9cm).";
            }
            
            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Validate maximal field size Y axis for Truebeam2 and TrueBeam_USZF.
        /// </summary>
        internal TestObject FieldSizeMaximumYaxisValidator_TB2_USZF(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            //// Absolute values (not negative).
            //double collX1 = Math.Abs(externalfield.CollX1);
            //double collX2 = Math.Abs(externalfield.CollX2);

            //double collX = collX1 + collX2;
            //
            // 161007, MM: use of absolute values incorrect, can have negative values for any of them,

            //             and calculation using simple subtraction X2 - X1, Y2 - Y1 of values returns correct X and Y jaw openings

            //double collX = externalfield.CollX2 - externalfield.CollX1;

            // Field size Y1 <= 19.9 cm.
            if ((Math.Abs(externalfield.CollY1) <= 19.9) && (Math.Abs(externalfield.CollY2) <= 19.9))
            {
                status = CheckResult.PASSED;
                comment = "Maximal position Y jaws cm (Y1 = " + externalfield.CollY1.ToString() + ", Y2 = " + externalfield.CollY2.ToString() + ") for  field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected <= 19.9cm).";
            }

            // Field size Y1 > 19.9 cm.
            if ((Math.Abs(externalfield.CollY1) > 19.9) || (Math.Abs(externalfield.CollY2) > 19.9))
            {
                status = CheckResult.FAILED;
                comment = "Maximal position Y jaws cm (Y1 = " + externalfield.CollY1.ToString() + ", Y2 = " + externalfield.CollY2.ToString() + ") for  field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected <= 19.9cm).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Validate collimator rotation for rapid arc plans.
        /// Rotation for RA plans 3 degrees.
        /// </summary>
        internal TestObject CollimatorRotationValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            bool isNameRapidStereo = false;

            if (externalfield.Plan.PlanSetupId.Length >= 2)
            {
                if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("RS")) { isNameRapidStereo = true; }
            }

            // RA, ST, SB and SR plan. + manually added RS
            if (externalfield.Plan.IsRapidArcPlan || externalfield.Plan.IsStereoAllPlan || isNameRapidStereo)
            {
                // Rotation >= 3 or < 357 degrees.
                if ((externalfield.CollRtn >= 3) || (externalfield.CollRtn <= 357))
                {
                    status = CheckResult.PASSED;
                    comment = "Collimator rotation '" + externalfield.CollRtn.ToString("0.##") + "°' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected collimator rotation RA plan >=3°).";
                }

                // Rotation < 3 or >= 357 degrees.
                if ((externalfield.CollRtn < 3) || (externalfield.CollRtn > 357))
                {
                    status = CheckResult.FAILED;
                    comment = "Collimator rotation '" + externalfield.CollRtn.ToString("0.##") + "°' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected collimator rotation RA plan >=3°)!";
                }
            }

            // All other plans.
            else
            {
                status = CheckResult.NOCHECK;
                comment = "NO CHECK: Collimator rotation '" + externalfield.CollRtn.ToString("0.##") + "°' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' not validated (expected RA plan)!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Validate if all fields have the same machine per plan.
        /// </summary>
        internal List<TestObject> RadiationMachinePerPlanEqualValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                int counter = 0;

                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer).ToList();

                counter = externalfieldsGrouped.Select(e => e.Machine.MachineId).Where(e => !e.Equals("")).Distinct().Count();

                if (externalfieldsGrouped.Count > 0)
                {

                    ExternalField externalfield = externalfieldsGrouped.First();

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.FIELD;
                    EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                    string comment = "Unknown";

                    // Valid if all the same, so one value.
                    if (counter == 1)
                    {

                        status = CheckResult.PASSED;
                        comment = "Machine entries all fields of plan '" + externalfield.Plan.PlanSetupId + "' equal (expected all fiels have same machine).";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Machine entries all fields of plan '" + externalfield.Plan.PlanSetupId + "' not equal (expected all fiels have same machine)!";
                    }
                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Validate field name (set by planner)
        /// -> criteria per 160531: treatment site, underscore, gantry start angle, (optional: patient support angle separated by slash)
        /// -> implementation: - treatment site must match treatment site of plan
        ///                    - underscore after treatment site
        ///                    - a valid number between 0 and 360 after underscore (gantry start angle) (!!! not tested against gantry start angle in field !!!)
        ///                    - optionally additional text after gantry start angle
        ///                    - no weird characters
        /// </summary>
        internal TestObject FieldNameValidator(ExternalField myExternalField)
        {
            // initialise output
            CheckResult myStatus = CheckResult.UNKNOWN;
            RtGroup myRtGroup = RtGroup.FIELD;
            EditableStatus myEditable = myExternalField.Plan.PlanSetupStatusEditable;

            // set information fields for test output
            string myRtInformation0 = RtGroup.COURSE.ToString() + ": " + myExternalField.Plan.CourseId;
            string myRtInformation1 = RtGroup.PLAN.ToString() + ": " + myExternalField.Plan.PlanSetupId;
            //string myRtInformation1 = RtGroup.PLAN.ToString() + ": " + myExternalField.Plan.PlanSetupId + " (" + myExternalField.Plan.PlanSetupStatus + ")";
            string myRtInformation2 = RtGroup.COURSE.ToString() + ": " + myExternalField.Plan.CourseId + ", " + RtGroup.FIELD.ToString() + ": " + myExternalField.RadiationId;
            string myComment = "Unknown";

            // do not check field name for setup fields
            if (myExternalField.SetupFieldFlag == 1)
            {
                myStatus = CheckResult.PASSED;
                myComment = "Field description for setup fields not required to correspond to specific pattern.";
            } // if ( myExternalField.SetupFieldFlag )
            else
            {
                // extract treatment site from PlanSetupId (get sequence of characters between two underscores in regex group 1)
                // (do not test for weird characters in PlanSetupId, assume this test performed separately;
                //  also, do not test for more than one match by calling Regex.Matches() )
                Match myMatchPlanSetupIdTreatmentSite = Regex.Match(myExternalField.Plan.PlanSetupId, @"^[^_]+_([^_]+)_[^_]+$");
                if (myMatchPlanSetupIdTreatmentSite.Equals(Match.Empty))
                {
                    // could not match pattern for treatment site in PlanSetupId
                    myStatus = CheckResult.FAILED;
                    myComment = "Checking field name: plan '" + myExternalField.Plan.PlanSetupId + "' does not conform to naming convention! Field name could not be validated!";
                } // if ( myMatchPlanSetupIdTreatmentSite.Equals( Match.Empty ) )
                else
                {
                    // store treatment site string
                    string myTreatmentSite = myMatchPlanSetupIdTreatmentSite.Groups[1].ToString();

                    // make sure that field name has no weird characters in it
                    if (Regex.IsMatch(myExternalField.RadiationName, @"^[\.A-Za-z0-9 _°-]+$"))
                    {
                        // check whether field name starts with treatment site and continues with an underscore and a number
                        Match myMatchFieldName = Regex.Match(myExternalField.RadiationName, @"^" + myTreatmentSite + @"_[0-9.]+");
                        if (myMatchFieldName.Equals(Match.Empty))
                        {
                            // field name does not match expected pattern
                            myStatus = CheckResult.FAILED;
                            myComment = "Field name '" + myExternalField.RadiationName + "' does not follow the naming convention (expected '{TreatmentSite}_{GantryStartAngle}' plus optional patient support angle separated by forward slash)!";
                        } // if ( myMatchFieldName.Equals( Match.Empty ) )
                        else
                        {
                            // SUCCESS! field name corresponds to naming convention
                            myStatus = CheckResult.PASSED;
                            myComment = "Field name '" + myExternalField.RadiationName + "' valid (expected '{TreatmentSite}_{GantryStartAngle}' plus optional patient support angle separated by forward slash)!";
                        } // else if ( myMatchFieldName.Equals( Match.Empty ) )
                    } // if ( Regex.IsMatch( myExternalField.RadiationName, @"^[\.A-Za-z0-9 _°-]+$" ) )
                    else
                    {
                        myStatus = CheckResult.FAILED;
                        myComment = "Field name '" + myExternalField.RadiationName + "' contains characters other than letters, numbers, spaces, _, °, -!";
                    } // else if ( Regex.IsMatch( myExternalField.RadiationName, @"^[\.A-Za-z0-9 _°-]+$" ) )
                } // else if ( myMatchPlanSetupIdTreatmentSite.Equals( Match.Empty ) )
            } // else if ( myExternalField.SetupFieldFlag == 1 )

            // prepare return value of test
            TestObject to = new TestObject(myStatus, myRtGroup, myEditable, myRtInformation0, myRtInformation1, myRtInformation2, myComment, Printable.NO);
            return to;

        } // internal List<TestObject> FieldNameValidator(ExternalField myExternalField)




        /// <summary>
        /// Validate the SSD for electron plans
        /// </summary>
        internal TestObject FieldSSDValidator(ExternalField myExternalField)
        {
            // initialise output
            CheckResult myStatus = CheckResult.UNKNOWN;
            RtGroup myRtGroup = RtGroup.FIELD;
            EditableStatus myEditable = myExternalField.Plan.PlanSetupStatusEditable;

            // set information fields for test output
            string myRtInformation0 = RtGroup.COURSE.ToString() + ": " + myExternalField.Plan.CourseId;
            string myRtInformation1 = RtGroup.PLAN.ToString() + ": " + myExternalField.Plan.PlanSetupId;
//            string myRtInformation1 = RtGroup.PLAN.ToString() + ": " + myExternalField.Plan.PlanSetupId + " (" + myExternalField.Plan.PlanSetupStatus + ")";
            string myRtInformation2 = RtGroup.COURSE.ToString() + ": " + myExternalField.Plan.CourseId + ", " + RtGroup.FIELD.ToString() + ": " + myExternalField.RadiationId;
            string myComment = "Unknown";

            double ShouldValueSSD = 100;
            double AcceptedRangeSSD = 0.001;

            if (myExternalField.Plan.PlanSetupStatus.Equals("Unapproved"))
            {
                myStatus = CheckResult.MANREV;
                myComment = "SSD for field '" + myExternalField.RadiationId + "' requires a manual check. The automatic check will be performed after plan review/approval (expected SSD = 100 cm for all electron plans, even in case of bolus)";

            } else
            {
                if (myExternalField.Ssd < ShouldValueSSD * (1 + AcceptedRangeSSD) && myExternalField.Ssd > ShouldValueSSD * (1 - AcceptedRangeSSD))
                {
                    myStatus = CheckResult.PASSED;
                    myComment = "Field '" + myExternalField.RadiationId + "' has SSD = " + myExternalField.Ssd + " (expected SSD = 100 cm [+-0.1%] for all electron plans, even in case of bolus)";
                } else
                {
                    myStatus = CheckResult.FAILED;
                    myComment = "Field '" + myExternalField.RadiationId + "' has SSD = " + myExternalField.Ssd + " (expected SSD = 100 cm [+-0.1%] for all electron plans, even in case of bolus)";

                }
            }


            TestObject to = new TestObject(myStatus, myRtGroup, myEditable, myRtInformation0, myRtInformation1, myRtInformation2, myComment, Printable.YES);
            return to;

        } 


        /// <summary>
        /// Validate the delta couch shifts
        /// </summary>
        internal List<TestObject> DeltaCouchShiftValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer).ToList();

                ExternalField externalfield = externalfieldsGrouped.First();

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.FIELD;
                EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//                string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
                string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                string comment = "Unknown";

                // Valid if there are couch shifts
                if (Math.Abs(externalfield.CouchLatDelta) + Math.Abs(externalfield.CouchLngDelta) + Math.Abs(externalfield.CouchVrtDelta) > 0.1) 
                {
                    status = CheckResult.PASSED;
                    comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has delta couch shifts calculated ( " + externalfield.CouchLatDelta.ToString() + " cm, " + externalfield.CouchLngDelta.ToString() + " cm, " + externalfield.CouchVrtDelta.ToString() + " cm)  (expected couch shifts calculated)";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has no delta couch shifts calculated ( " + externalfield.CouchLatDelta.ToString() + " cm, " + externalfield.CouchLngDelta.ToString() + " cm, " + externalfield.CouchVrtDelta.ToString() + " cm) (expected couch shifts calculated)";
                }
                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                tobjects.Add(to);
            }

            return tobjects;

        }



        /// <summary>
        /// Validate the gating of the plan
        /// </summary>
        internal List<TestObject> GatingValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer).ToList();

                ExternalField externalfield = externalfieldsGrouped.First();

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.FIELD;
                EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//                string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
                string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                string comment = "Unknown";

                bool requiresGating = false;

                if (externalfield.Plan.PlanSetupId.Length >= 5)
                {
                    if (externalfield.Plan.PlanSetupId.StartsWith("SBlur")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SBlul")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SBlun")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("ECbrl")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("3Dbrl")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("RIbrl")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("RAbrl")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("IMbrl")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SBliv")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SRpro")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SRliv")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SRlur")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SRlul")) { requiresGating = true; }
                    if (externalfield.Plan.PlanSetupId.StartsWith("SRlun")) { requiresGating = true; }

                }

                if (requiresGating)
                {
                    if (externalfield.Gating)
                    {
                        status = CheckResult.PASSED;
                        comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has gating ON. (expected ON for plans SB/SRlun, SB/SRliv, SRpro, XXbrl, otherwise OFF)";
                    } else
                    {
                        status = CheckResult.FAILED;
                        comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has gating OFF. (expected ON for plans SB/SRlun, SB/SRliv, SRpro, XXbrl, otherwise OFF)";
                    }
                } else
                {
                    if (externalfield.Gating)
                    {
                        status = CheckResult.FAILED;
                        comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has gating ON. (expected ON for plans SB/SRlun, SB/SRliv, SRpro, XXbrl, otherwise OFF)";
                    }
                    else
                    {
                        status = CheckResult.PASSED;
                        comment = "The plan '" + externalfield.Plan.PlanSetupId + "' has gating OFF. (expected ON for plans SB/SRlun, SB/SRliv, SRpro, XXbrl, otherwise OFF)";
                    }
                }

                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                tobjects.Add(to);
            }

            return tobjects;

        }


        /// <summary>
        /// Validate rotation gantry
        /// </summary>
        internal List<TestObject> GantryRotationValidator(List<ExternalField> externalfields)
        {

            List<TestObject> tobjects = new List<TestObject>();

            List<long> planSetupSers = externalfields.Select(p => p.Plan.PlanSetupSer).Where(p => !p.Equals("")).Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ExternalField> externalfieldsGrouped = externalfields.Where(e => e.Plan.PlanSetupSer == planSetupSer & e.GantryRtnDirection != "NONE" ).ToList();  // take only the VMAT fields (exclude static and setup)

                int NFields = externalfieldsGrouped.Count;

                // do the check only if there are exactly two fields
                if (NFields == 2)
                {
                    ExternalField externalfield1 = externalfieldsGrouped[0];
                    ExternalField externalfield2 = externalfieldsGrouped[1];

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.FIELD;
                    EditableStatus editable = externalfield1.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield1.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield1.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + externalfield1.Plan.PlanSetupId + " (" + externalfield1.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield1.Plan.CourseId;
                    string comment = "Unknown";

                    if (externalfield1.GantryRtnDirection == externalfield2.GantryRtnDirection)
                    {
                        status = CheckResult.FAILED;
                        comment = "The plan '" + externalfield1.Plan.PlanSetupId + "' has field " + externalfield1.RadiationId + " and field " + externalfield2.RadiationId + " with the same rotation direction " + externalfield1.GantryRtnDirection + " and " + externalfield2.GantryRtnDirection + ". (for plans with two fields expected one field CCW and one CW)";
                    } else
                    {
                        status = CheckResult.PASSED;
                        comment = "The plan '" + externalfield1.Plan.PlanSetupId + "' has field " + externalfield1.RadiationId + " and field " + externalfield2.RadiationId + " with different rotation direction " + externalfield1.GantryRtnDirection + " and " + externalfield2.GantryRtnDirection + ". (for plans with two fields expected one field CCW and one CW)";

                    }
                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);
                    tobjects.Add(to);
     
                }

                

            }

            return tobjects;

        }

    } // class ExternalFieldGeometryValidator : Validator
} // namespace RtDataValidator.BLL