﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the dosimetric external field validator.
    /// </summary>
    class ExternalFieldDosimetryValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            ExternalFieldDosimetryQuery qry = new ExternalFieldDosimetryQuery();

            List<ExternalField> externalfields = qry.GetExternalFields(patient);

            foreach (ExternalField externalfield in externalfields)
            {
                tobjects.Add(DoseRateValidator(externalfield));

                tobjects.Add(TechniqueMonitorUnitsValidator(externalfield));

                tobjects.Add(BeamQualityStereoTreatmentValidator(externalfield));
                

                if (externalfield.AddOnType.Contains("EDW"))
                { 
                    tobjects.Add(WedgeMonitorUnitsValidator(externalfield));
                }   
                // Manual review items.
                if (externalfield.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES))
                {
                    tobjects.Add(EnergyManReviewValidator(externalfield));
                    tobjects.Add(MonitorUnitsManReviewValidator(externalfield));
                }
            }

            tobjects.AddRange(TechniquePrescribedDoseValidator(externalfields));
            tobjects.AddRange(MonitorUnitTotalManReviewValidator(externalfields));
            tobjects.AddRange(EnergyConsistencyValidator(externalfields));
            //tobjects.AddRange(SsdElectronFieldsValidator(externalfields)); // re-implmented in ExternalFieldGeometry

            return tobjects;
        }

        /// <summary>
        /// Validate energy manual review.
        /// </summary>
        internal TestObject EnergyManReviewValidator(ExternalField externalfield)
        {
            string energy = "N/A";

            // Energy in db factor 1000. 
            if (externalfield.Energy > 1000)
            {
                energy = (externalfield.Energy / 1000).ToString();
            }

            CheckResult status = CheckResult.MANREV;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
           // string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Energy '" + energy + " M(e)V' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "'.";

            // Photons.
            if (externalfield.RadiationType.Equals("X"))
            {
                comment = "Photon energy (X) '" + energy + " MV' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "'.";
            }

            // Electrons.
            if (externalfield.RadiationType.Equals("E"))
            {
                comment = "Electron energy (E)'" + energy + " MeV' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "'.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate monitor units manual review.
        /// </summary>
        internal TestObject MonitorUnitsManReviewValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.MANREV;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "MU '" + externalfield.MonitorUnits.ToString("0.##") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "'.";

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate dose rate.
        /// Different dose rates are used depending on energy and type beam.
        /// </summary>
        internal TestObject DoseRateValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "Unknown";

            string energy = "N/A";

            // Energy in db factor 1000. 
            if (externalfield.Energy > 1000)
            {
                energy = (externalfield.Energy / 1000).ToString();
            }

            // Photons (600 default; X FFF 6 1400, 10 2400).
            if (externalfield.RadiationType.Equals("X"))
            {
                status = CheckResult.FAILED;
                comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for field '" + externalfield.RadiationId + "' and photon energy '" + energy + " MV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected 600 default; FFF 6 MV 1400; FFF 10 MV 2400; 300 for IMRT or hybrid IMRT+VMAT)!";

                // Default 600 dose rate.
                if ((externalfield.DoseRate == 600) && !externalfield.AddOnType.Equals("FFF"))
                {
                    status = CheckResult.PASSED;
                    comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for '" + externalfield.RadiationId + "' and photon energy '" + energy + " MV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected 600 default; FFF 6 MV 1400; FFF 10 MV 2400).";
                }

                // FFF: 6 MV and 1400 dose rate.
                if ((externalfield.DoseRate == 1400) && externalfield.AddOnType.Equals("FFF") && (externalfield.Energy == 6000))
                {
                    status = CheckResult.PASSED;
                    comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for '" + externalfield.RadiationId + "' and photon energy '" + energy + " MV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected 600 default; FFF 6 MV 1400; FFF 10 MV 2400).";
                }

                // FFF: 10 MV and 2400 dose rate.
                if ((externalfield.DoseRate == 2400) && externalfield.AddOnType.Equals("FFF") && (externalfield.Energy == 10000))
                {
                    status = CheckResult.PASSED;
                    comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for '" + externalfield.RadiationId + "' and photon energy '" + energy + " MV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected 600 default; FFF 6 MV 1400; FFF 10 MV 2400).";
                }

                // Hybrid IMRT + VMAT plans for breast
                if (externalfield.Plan.PlanSetupId.Length >= 5)
                {
                    if ((externalfield.Plan.PlanSetupId.Substring(0, 5).Equals("RIbrr") || externalfield.Plan.PlanSetupId.Substring(0, 5).Equals("IMbrr") ) && (externalfield.DoseRate < 301))
                    {
                        status = CheckResult.PASSED;
                        comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for '" + externalfield.RadiationId + "' and photon energy '" + energy + " MV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected <=300 for IMRT or hybrid IMRT+VMAT breast right).";

                    }
                }
            }

            // Electrons (1000 default).
            if (externalfield.RadiationType.Equals("E"))
            {
                if (externalfield.DoseRate == 1000)
                {
                    status = CheckResult.PASSED;
                    comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for field '" + externalfield.RadiationId + "' and electron energy '" + energy + " MeV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected 1000 for e-fiels).";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "Dose rate '" + externalfield.DoseRate.ToString() + "' for field '" + externalfield.RadiationId + "' and electron energy '" + energy + " MeV' and type '" + externalfield.AddOnType + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected 1000 for e-fiels)!";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }


        /// <summary>
        /// Validate beam quality
        /// </summary>
        internal TestObject BeamQualityStereoTreatmentValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "unknown";

            bool temp_isFFF = externalfield.AddOnType.Equals("FFF");

            bool isNameStereo = false;
            if (externalfield.Plan.PlanSetupId.Length >= 2)
            {
                //if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("RS")) { isNameStereo = true; } // RS calculated with FF
                if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("SB")) { isNameStereo = true; }
                if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("SR")) { isNameStereo = true; }
                if (externalfield.Plan.PlanSetupId.Substring(0, 2).Equals("ST")) { isNameStereo = true; }
            }

            // if (externalfield.TechniqueId.Contains("SRS") || externalfield.TechniqueId.Contains("SBRT") || externalfield.TechniqueId.Contains("SBRT"))  // old criteria
            if (isNameStereo)
            {
                // stereo plan
                if (temp_isFFF)
                {
                    status = CheckResult.PASSED;
                    comment = "This is a stereo plan (SBRT, SRS or SRT), technique = " + externalfield.TechniqueId + " and it is calculated with an FFF beam";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "This is a stereo plan (SBRT, SRS or SRT), technique = " + externalfield.TechniqueId + ". Expected: FFF beam";
                }

            }
            else
            {
                // non stereo plan
                if (temp_isFFF)
                {
                    status = CheckResult.MANREV;
                    comment = "This is not a stereo plan (SBRT, SRS or SRT), technique = " + externalfield.TechniqueId + " and it is planned with FFF (Expected 6X or 10X, acceptable FFF for fields up to 10x10cm2)";
                } else
                {
                    status = CheckResult.PASSED;
                    comment = "This is not a stereo plan (SBRT, SRS or SRT), technique = " + externalfield.TechniqueId + " and it is planned with flattening filter inserted  (Expected 6X or 10X, acceptable FFF for fields up to 10x10cm2)";
                }
            }

            if (externalfield.TechniqueId.Contains("STATIC"))
            {
                if (temp_isFFF)
                {
                    status = CheckResult.FAILED;
                    comment = "This is a static field, technique = " + externalfield.TechniqueId + " and it is planned with FFF (Expected 6X or 10X)";
                }
                else
                {
                    status = CheckResult.PASSED;
                    comment = "This is a static field, technique = " + externalfield.TechniqueId + " and it is planned with flattening filter inserted (Expected 6X or 10X)";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }


        /// <summary>
        /// Validate technique and their monitor units per field.
        /// SRS ARC and SRS TOTAL must be used if more than 999 MU are used.
        /// </summary>
        internal TestObject TechniqueMonitorUnitsValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "unknown";

            // <= 999 MU then technique selection is free.
            if (externalfield.MonitorUnits < 999)
            {
                status = CheckResult.PASSED;
                comment = "Technique '" + externalfield.TechniqueId + "' and MU '" + externalfield.MonitorUnits.ToString("0.#") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected > 999 MU for technique SRS ARC or SRS TOTAL).";

            }
            else
            {
                // SRS ARC or SRS STATIC and > 999 MU.           
                if (externalfield.TechniqueId.Contains("SRS "))
                {
                    status = CheckResult.PASSED;
                    comment = "Technique '" + externalfield.TechniqueId + "' and MU '" + externalfield.MonitorUnits.ToString("0.#") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected > 999 MU for technique SRS ARC or SRS TOTAL).";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "Technique '" + externalfield.TechniqueId + "' and MU '" + externalfield.MonitorUnits.ToString("0.#") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected > 999 MU for technique SRS ARC or SRS TOTAL)!";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
        internal TestObject WedgeMonitorUnitsValidator(ExternalField externalfield)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.FIELD;
            EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
            string comment = "unknown";

            // <21 MU not allowed for Wedge.
            if (externalfield.MonitorUnits < 21)
            {
                status = CheckResult.FAILED;
                comment = "'Addon'" + externalfield.AddOnType +  "'with MU '" + externalfield.MonitorUnits.ToString("0.#") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected > 999 MU for technique SRS ARC or SRS TOTAL).";

            }
            else
            {
                status = CheckResult.PASSED;
                comment = "'Addon'" + externalfield.AddOnType + "'with MU '" + externalfield.MonitorUnits.ToString("0.#") + "' for field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected > 999 MU for technique SRS ARC or SRS TOTAL).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate technique and their monitor units per field.
        /// If dose is > 5 Gy then use SRS ARC or SRS STATIC.
        /// </summary>
        internal List<TestObject> TechniquePrescribedDoseValidator(List<ExternalField> externalfields)
        {

            List<TestObject> tobjects = new List<TestObject>();

            // Get unique plans.
            List<string> planSetupIds = externalfields.Where(e => e.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES)).Select(p => p.Plan.PlanSetupId).Where(p => !p.Equals("")).Distinct().ToList();

            // Iterate over plans and get total mus per plan.
            foreach (string planSetupId in planSetupIds)
            {
                List<ExternalField> fieldsPerPlan = externalfields.Where(p => p.Plan.PlanSetupId.Equals(planSetupId)).ToList();

                List<string> techniqueIds = new List<string>();

                foreach (ExternalField externalfield in fieldsPerPlan)
                {
                    techniqueIds.Add(externalfield.TechniqueId);
                }

                techniqueIds = techniqueIds.Distinct().ToList();

                // All fields should have same technique (one element).
                string techniqueId = "Unknown";
                if (techniqueIds.Count == 1)
                {
                    techniqueId = techniqueIds.ElementAt(0);
                }

                if (fieldsPerPlan.Count > 0)
                {

                    ExternalField ef = fieldsPerPlan.First();

                    CheckResult status = CheckResult.UNKNOWN;
                    RtGroup rtGroup = RtGroup.REFP;
                    EditableStatus editable = ef.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + ef.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + ef.Plan.PlanSetupId + " (" + ef.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId + "; " + RtGroup.FIELD + ": " + ef.RadiationId;
                    string comment = "Unknown";

                    // Required SRS field only for SBRT, SRS, SRT, Dose > 5.5 Gy
                    bool requiresSRSField = false;

                    if (ef.Plan.PlanSetupId.StartsWith("SB")) { requiresSRSField = true; }
                    if (ef.Plan.PlanSetupId.StartsWith("SR")) { requiresSRSField = true; }
                    if (ef.Plan.PlanSetupId.StartsWith("ST")) { requiresSRSField = true; }
                    if (ef.Plan.PrescribedDose >= 5.5) { requiresSRSField = true; }

                    // Dose larger than zero.
                    // if dose is <= 5.5 Gy then do not use SRS ARC or SRS STATIC.
                    if (!requiresSRSField)
                    {
                        if (techniqueId.Contains("SRS "))
                        {
                            status = CheckResult.FAILED;
                            comment = "Technique '" + ef.TechniqueId + "' and prescribed dose '" + ef.Plan.PrescribedDose.ToString("0.##") + "' for field '" + ef.RadiationId + "' and plan '" + ef.Plan.PlanSetupId + "' invalid (expected SRS ARC or SRS STATIC for SBRT, SRS, SRT or dose >= 5.5 Gy)!";
                        }
                        else
                        {
                            status = CheckResult.PASSED;
                            comment = "Technique '" + ef.TechniqueId + "' and prescribed dose '" + ef.Plan.PrescribedDose.ToString("0.##") + "' for field '" + ef.RadiationId + "' and plan '" + ef.Plan.PlanSetupId + "' valid (expected SRS ARC or SRS STATIC for SBRT, SRS, SRT or dose >= 5.5 Gy)!";
                        }
                    }

                    // if dose is >= 5.5 Gy then use SRS ARC or SRS STATIC.
                    if (requiresSRSField)
                    {
                        if (techniqueId.Contains("SRS "))
                        {
                            status = CheckResult.PASSED;
                            comment = "Technique '" + ef.TechniqueId + "' and prescribed dose '" + ef.Plan.PrescribedDose.ToString("0.##") + "' for field '" + ef.RadiationId + "' and plan '" + ef.Plan.PlanSetupId + "' valid (expected SRS ARC or SRS STATIC for SBRT, SRS, SRT or dose >= 5.5 Gy)!";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Technique '" + ef.TechniqueId + "' and prescribed dose '" + ef.Plan.PrescribedDose.ToString("0.##") + "' for field '" + ef.RadiationId + "' and plan '" + ef.Plan.PlanSetupId + "' invalid (expected SRS ARC or SRS STATIC for SBRT, SRS, SRT or dose >= 5.5 Gy)!";
                        }
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }
            return tobjects;
        }

        /// <summary>
        /// Validate total monitor units per plan.
        /// </summary>
        internal List<TestObject> MonitorUnitTotalManReviewValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get unique plans.
            List<string> planSetupIds = externalfields.Where(e => e.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES)).Select(p => p.Plan.PlanSetupId).Where(p => !p.Equals("")).Distinct().ToList();

            // Iterate over plans and get total mus per plan.
            foreach (string planSetupId in planSetupIds)
            {
                List<ExternalField> fieldsPerPlan = externalfields.Where(p => p.Plan.PlanSetupId.Equals(planSetupId)).ToList();

                double totalMu = 0;
                List<string> techniqueIds = new List<string>();

                foreach (ExternalField externalfield in fieldsPerPlan)
                {
                    totalMu = totalMu + externalfield.MonitorUnits;
                    techniqueIds.Add(externalfield.TechniqueId);
                }

                techniqueIds = techniqueIds.Distinct().ToList();

                // All fields should have same technique (one element).
                string techniqueId = "Unknown";
                if (techniqueIds.Count == 1)
                {
                    techniqueId = techniqueIds.ElementAt(0);
                }

                if (fieldsPerPlan.Count > 0)
                {

                    ExternalField ef = fieldsPerPlan.First();

                    CheckResult status = CheckResult.MANREV;
                    RtGroup rtGroup = RtGroup.REFP;
                    EditableStatus editable = ef.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + ef.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + ef.Plan.PlanSetupId + " (" + ef.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId;
                    string comment = "Unknown";

                    if (totalMu > 2000)
                    {
                        status = CheckResult.MANREV;
                        comment = "Total MU !!!'" + totalMu.ToString("0.##") + "'!!! and technique '" + techniqueId + "' for plan '" + ef.Plan.PlanSetupId + "' (warning: > 2000 MU).";
                    }
                    else
                    {
                        status = CheckResult.MANREV;
                        comment = "Total MU '" + totalMu.ToString("0.##") + "' and technique '" + techniqueId + "' for plan '" + ef.Plan.PlanSetupId + "'.";
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }
            return tobjects;
        }

        /// <summary>
        /// Validate having all fields with the same beam energy
        /// </summary>
        internal List<TestObject> EnergyConsistencyValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get unique plans.
            List<string> planSetupIds = externalfields.Where(e => e.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES)).Select(p => p.Plan.PlanSetupId).Where(p => !p.Equals("")).Distinct().ToList();

            // Iterate over plans 
            foreach (string planSetupId in planSetupIds)
            {
                List<ExternalField> fieldsPerPlan = externalfields.Where(p => p.Plan.PlanSetupId.Equals(planSetupId)).ToList();

                // iterate over the fields and check that they have the same energy

                double energy_firstBeam = 0;
                string radiationType_firstBeam = "";
                string addOnType_firstBeam = "";

                bool consistencyCheck = true;

                // find the data for the first treatment beam
                foreach (ExternalField externalfield in fieldsPerPlan)
                {
                    // take only the ones with MUs (treatment fields)
                    if (externalfield.MonitorUnits > 0)
                    {
                        energy_firstBeam = externalfield.Energy;
                        radiationType_firstBeam = externalfield.RadiationType;
                        addOnType_firstBeam = externalfield.AddOnType;
                        break;
                    }
                }

                // compare the data to the remaining teatment beams
                foreach (ExternalField externalfield in fieldsPerPlan)
                {
                    // take only the ones with MUs (treatment fields)
                    if (externalfield.MonitorUnits > 0)
                    {
                        if (Math.Abs(energy_firstBeam - externalfield.Energy)>0.1)
                        {
                            consistencyCheck = false;
                        }

                        if (!radiationType_firstBeam.Equals(externalfield.RadiationType))
                        {
                            consistencyCheck = false;
                        }

                        if (!addOnType_firstBeam.Equals(externalfield.AddOnType))
                        {
                            consistencyCheck = false;
                        }


                    }
                }




                // produce output only if there are treatment fiels
                if (energy_firstBeam > 0)
                {
                    ExternalField ef = fieldsPerPlan.First();

                    CheckResult status = CheckResult.MANREV;
                    RtGroup rtGroup = RtGroup.REFP;
                    EditableStatus editable = ef.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + ef.Plan.PlanSetupId;
                    //                    string rtInformation1 = RtGroup.PLAN + ": " + ef.Plan.PlanSetupId + " (" + ef.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + ef.Plan.CourseId;
                    string comment = "Unknown";

                    if (consistencyCheck)
                    {
                        status = CheckResult.PASSED;
                        comment = "Energy consistency of fields is correct (expexted same energy for VMAT and Stereo plans, free energy choice for 3D and IMRT)";
                    }
                    else if (ef.Plan.PlanSetupId.StartsWith("RA") || ef.Plan.PlanSetupId.StartsWith("RS") || ef.Plan.PlanSetupId.StartsWith("SB") || ef.Plan.PlanSetupId.StartsWith("ST") || ef.Plan.PlanSetupId.StartsWith("SR"))
                    {
                        status = CheckResult.FAILED;
                        comment = "Energy of the fiels for the plan '"  + ef.Plan.PlanSetupId + "' is inconsistent (expexted same energy for VMAT and Stereo plans, free energy choice for 3D and IMRT) ";
                    } 
                    else if (ef.Plan.PlanSetupId.StartsWith("3D") || ef.Plan.PlanSetupId.StartsWith("IM") || ef.Plan.PlanSetupId.StartsWith("RI"))
                    {
                        status = CheckResult.PASSED;
                        comment = "Energy consistency of fields is correct (expexted same energy for VMAT and Stereo plans, free energy choice for 3D and IMRT and hybrid VMAT+IMRT)";
                    } 
                    else
                    {
                        status = CheckResult.MANREV;
                        comment = "Energy consistency of the fiels for the plan '" + ef.Plan.PlanSetupId + "' requires manual review (expexted same energy for VMAT and Stereo plans, free energy choice for 3D and IMRT)";
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }

            }
            return tobjects;
        }

        



        /// <summary>
        /// Validate ssd for electron fields.
        /// --> re-implemented by RDB in ExternalFieldGeometry, not used here
        /// </summary>
        internal List<TestObject> SsdElectronFieldsValidator(List<ExternalField> externalfields)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get electron fields.
            List<ExternalField> fieldsElectrons = externalfields.Where(e => e.RadiationType.Equals("E")).ToList();

            if (fieldsElectrons.Count > 0)
            {

                // Iterate over electron fields.          
                foreach (ExternalField externalfield in fieldsElectrons)
                {

                    RtGroup rtGroup = RtGroup.REFP;
                    EditableStatus editable = externalfield.Plan.PlanSetupStatusEditable;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + externalfield.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN + ": " + externalfield.Plan.PlanSetupId + " (" + externalfield.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + externalfield.Plan.CourseId + "; " + RtGroup.FIELD + ": " + externalfield.RadiationId;
                    CheckResult status = CheckResult.UNKNOWN;
                    string comment = "Unknown";

                    double ssd = Math.Round(externalfield.Ssd, 0);

                    // Ssd must be 100 cm.
                    if (ssd != 100)
                    {
                        status = CheckResult.FAILED;
                        comment = "Ssd '" + externalfield.Ssd.ToString() + " cm' for electron field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' invalid (expected e-fields ssd 100 cm)!";
                    }
                    else
                    {
                        status = CheckResult.PASSED;
                        comment = "Ssd '" + externalfield.Ssd.ToString() + " cm' for electron field '" + externalfield.RadiationId + "' and plan '" + externalfield.Plan.PlanSetupId + "' valid (expected e-fields ssd 100 cm).";
                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }
            return tobjects;
        }
    }
}