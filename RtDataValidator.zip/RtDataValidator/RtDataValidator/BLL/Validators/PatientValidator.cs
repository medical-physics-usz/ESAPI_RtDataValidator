﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the patient validator.
    /// </summary>
    internal class PatientValidator : Validator
    {
        /// <summary>
        /// Get validated patient output.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Verify patient id.
            tobjects.Add(PatientIdValidator(patient));

            // Verify rt-number.
            //tobjects.Add(PatientId2Validator(patient));

            // Verify date of birth.
            tobjects.Add(PatientDateOfBirthValidator(patient));

            // Verify sex.
            tobjects.Add(PatientSexValidator(patient));

            // Verify first name.
            tobjects.Add(FirstNameValidator(patient));

            // Verify last name.
            tobjects.Add(LastNameValidator(patient));

            // Verify mobile phone number.
            //tobjects.Add(PatientMobilePhoneValidator(patient));

            // Verify mobile phone number.
           // tobjects.Add(PatientInsuranceValidator(patient));

            // Verify primary oncologist.
            tobjects.Add(PrimaryOncologistValidator(patient));

            // Verify death date.
            if (patient.DeathDate != DateTime.MaxValue)
            {
                tobjects.Add(PatientDeathDateValidator(patient));
            }

            return tobjects;
        }

        /// <summary>
        /// Validate patient id.
        /// </summary>
        internal TestObject PatientIdValidator(Patient patient)
        {
            bool isValid = true;
            int counter = 0;

            if (!Regex.IsMatch(patient.PatientId, @"^[0-9]+$"))
            {
                counter = counter + 1;
            }

            if (patient.PatientId.Length != 8)
            {
                counter = counter + 1;
            }

            if (counter > 0)
            {
                isValid = false;
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (!isValid)
            {
                status = CheckResult.FAILED;
                comment = "Patient ID: '" + patient.PatientId + "' invalid (expected 8 digits)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Patient ID: '" + patient.PatientId + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate patient id2.
        /// </summary>
        internal TestObject PatientId2Validator(Patient patient)
        {
            bool isValid = true;
            bool isNoIdValue = false;
            int counter = 0;

            if ((patient.PatientId2.Length == 13) && ((patient.PatientId2.StartsWith("NOID_")) || (patient.PatientId2.StartsWith("PALL_"))))
            {
                isNoIdValue = true;
            }

            if (!Regex.IsMatch(patient.PatientId2, @"^[0-9]+$"))
            {
                counter = counter + 1;
            }

            if (patient.PatientId2.Length != 5)
            {
                counter = counter + 1;
            }

            if ((counter > 0) && (!isNoIdValue))
            {
                isValid = false;
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (!isValid)
            {
                status = CheckResult.FAILED;
                comment = "RT number: '" + patient.PatientId2 + "' invalid (expected 5 digits or 'NOID_{SAP-Number}')!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "RT number: '" + patient.PatientId2 + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate first name.
        /// </summary>
        internal TestObject FirstNameValidator(Patient patient)
        {

            bool isValid = true;
            int counter = 0;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (patient.FirstName.Length > 0)
            {

                if (!Regex.IsMatch(patient.FirstName.Substring(0, 1), @"^[A-Z']+$"))
                {
                    counter = counter + 1;
                }

                if (patient.FirstName.Contains("  "))
                {
                    counter = counter + 1;
                }

                if (counter > 0)
                {
                    isValid = false;
                }

                if (!isValid)
                {
                    status = CheckResult.FAILED;
                    comment = "First name: '" + patient.FirstName + "' invalid (expected a name starting with A-Z or ' & no double spaces)!";
                }
                else
                {
                    status = CheckResult.PASSED;
                    comment = "First name: '" + patient.FirstName + "' valid.";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate last name.
        /// </summary>
        internal TestObject LastNameValidator(Patient patient)
        {

            bool isValid = true;
            int counter = 0;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (patient.LastName.Length > 0)
            {

                if (!Regex.IsMatch(patient.LastName.Substring(0, 1), @"^[A-Z']+$"))
                {
                    counter = counter + 1;
                }

                if (patient.LastName.Contains("  "))
                {
                    counter = counter + 1;
                }

                if (counter > 0)
                {
                    isValid = false;
                }

                if (!isValid)
                {
                    status = CheckResult.FAILED;
                    comment = "Last name: '" + patient.LastName + "' invalid (expected a name starting with A-Z or ' & no double spaces)!";
                }
                else
                {
                    status = CheckResult.PASSED;
                    comment = "Last name: '" + patient.LastName + "' valid.";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate date of birth.
        /// </summary>
        internal TestObject PatientDateOfBirthValidator(Patient patient)
        {
            DateTime past = new DateTime(1900, 1, 1);

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if ((patient.DateOfBirth >= DateTime.Now) || (patient.DateOfBirth <= past))
            {
                status = CheckResult.FAILED;
                comment = "Date of birth: '" + patient.DateOfBirth.ToShortDateString() + "' invalid (expected between 1.1.1900 and < today)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Date of birth: '" + patient.DateOfBirth.ToShortDateString() + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate patient sex.
        /// </summary>
        private TestObject PatientSexValidator(Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if ((patient.PatientSex.Equals(PatientSex.Other)) || (patient.PatientSex.Equals(PatientSex.Unknown)))
            {
                status = CheckResult.FAILED;
                comment = "Patient sex: '" + patient.PatientSex.ToString() + "' invalid (expected female or male)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Patient sex: '" + patient.PatientSex.ToString() + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate mobile phone number.
        /// </summary>
        internal TestObject PatientMobilePhoneValidator(Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if ((!Regex.IsMatch(patient.MobilePhone, @"^[0-9]+$")) && (!patient.MobilePhone.Equals("")))
            {
                status = CheckResult.FAILED;
                comment = "Mobile phone number: '" + patient.MobilePhone + "' invalid (expected only numbers)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Mobile phone number: '" + patient.MobilePhone + "' valid or empty.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate insurance.
        /// </summary>
        internal TestObject PatientInsuranceValidator(Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if ((!patient.Insurance.Equals("Allgemein")) && (!patient.Insurance.Equals("HalbPrivat")) && (!patient.Insurance.Equals("Privat")))
            {
                status = CheckResult.FAILED;
                comment = "Insurance status: '" + patient.Insurance + "' invalid (expected 'Allgemein', 'HalbPrivat' or 'Privat')!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Insurance status: '" + patient.Insurance + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate death date.
        /// </summary>
        internal TestObject PatientDeathDateValidator(Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            DateTime past = new DateTime(1900, 1, 1);

            if (((patient.DateOfBirth == patient.DeathDate) || ((patient.DeathDate > DateTime.Now)) && (patient.DeathDate != DateTime.MaxValue)))
            {
                status = CheckResult.FAILED;
                comment = "Death date: '" + patient.DeathDate.ToShortDateString() + "' invalid (expected > date of birth and < today)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Death date validated. No errors.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate primary oncologist.
        /// </summary>
        internal TestObject PrimaryOncologistValidator(Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (patient.PrimaryOncologist.OncologistSer == 0)
            {
                status = CheckResult.FAILED;
                comment = "No primary radiation oncologist is attached!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Primary radiation oncologist is attached.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
    }
}