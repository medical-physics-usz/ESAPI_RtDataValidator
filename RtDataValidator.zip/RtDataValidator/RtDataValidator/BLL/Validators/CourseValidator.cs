﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the course validator.
    /// </summary>
    class CourseValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            CourseQuery qry = new CourseQuery();

            List<Course> courses = qry.GetCourses(patient);

            // Empty data set.
            if (courses.Count == 0)
            {
                TestObjectOutput too = new TestObjectOutput();
                tobjects.Add(too.EmptyTestObject(RtGroup.COURSE));
            }
            else
            {

                foreach (Course course in courses)
                {
                    tobjects.Add(CourseIdValidator(course));
                    tobjects.Add(CompletedDateTimeValidator(course));
                    tobjects.Add(DiagnosisCodeTableAttachedValidator(course));
                    tobjects.Add(DiagnosisCodeMetastasesValidator(course));
                    tobjects.Add(CourseIntentValidator(course));
                    //tobjects.Add(CourseIntentDiagnosisCodeValidator(course));   // removed from June 2021. None of the ICD codes will be benign.
                    tobjects.Add(CourseDiagnosisDoubleValidator(course, courses));

                    // Death date validation (only visible if patient is not alive).
                    if ((course.Patient.DeathDate != DateTime.MaxValue) && (course.CompletedDateTime != DateTime.MaxValue))
                    {
                        tobjects.Add(CourseCompletedDeathDateValidator(course));
                        tobjects.Add(CourseActiveDeathDateValidator(course));
                    }

                    // Completed cases (only visible if validation type set to completed).
                    if (type.Equals(ValidationType.CompletedCases))
                    {
                        tobjects.Add(CourseCompletedValidator(course));
                    }

                    // Plan editable status (under courses due to diagnosis code and intent).
                    if (course.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES))
                    {
                        tobjects.Add(CoursePlanManualReviewValidator(course));
                    }
                }

                if (courses.Count > 0)
                {
                    tobjects.AddRange(CourseOrderValidator(courses));
                   // tobjects.Add(CoursesPatientStatusValidator(courses));
                    tobjects.AddRange(MultipleCoursesActiveValidator(courses));
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Validate course id.
        /// </summary>
        internal TestObject CourseIdValidator(Course course)
        {

            string sitevalue = "";
            bool isValidPrefix = false;
            string regexstring = @"^[A-Za-z0-9-\. _ÄÖÜäöü]+$";
            string regexstringdisplay = @"A-Za-z0-9-. _ÄÖÜäöü";

            if (course.CourseId.Length >= 6)
            {

                Char sub1 = course.CourseId[1];
                Char sub2 = course.CourseId[2];

                // Numbers 0-9.
                if ((Char.IsNumber(course.CourseId, 0)) && (sub1 == '_') && (Regex.IsMatch(course.CourseId, regexstring)))
                {
                    sitevalue = course.CourseId.Substring(2, 3).Trim();
                    isValidPrefix = true;
                }

                // Numbers >=10.
                if ((Char.IsNumber(course.CourseId, 0)) && (Char.IsNumber(course.CourseId, 1)) && (sub2 == '_') && (Regex.IsMatch(course.CourseId, regexstring)))
                {
                    sitevalue = course.CourseId.Substring(3, 3).Trim();
                    isValidPrefix = true;
                }
            } 
            else
            {
                // for very short course names (eg. 1_AVM) check only that it starts with a number and that it contains a "_"

                if (course.CourseId.StartsWith("1") || course.CourseId.StartsWith("2") || course.CourseId.StartsWith("3") || course.CourseId.StartsWith("4") || course.CourseId.StartsWith("5") || course.CourseId.StartsWith("6") || course.CourseId.StartsWith("7") || course.CourseId.StartsWith("8") || course.CourseId.StartsWith("9"))
                {
                    if (course.CourseId.Contains("_"))
                    {
                        isValidPrefix = true;
                    }
                }
            }




            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if (!isValidPrefix)
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' invalid (expected: '{IncrementalNumber}{_}{Site}'. Allowed chars: '" + regexstringdisplay + "')!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate time span start vs. completed date time.
        /// Plans older than 100 days are indicated as invalid.
        /// </summary>
        internal TestObject CompletedDateTimeValidator(Course course)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;

            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            int dayDiff = (course.CompletedDateTime - course.StartDateTime).Days;

            if ((dayDiff > 100) && (course.ClinicalStatus.Equals("COMPLETED")))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' completed date time: '" + course.CompletedDateTime.ToShortDateString() + "' possibly invalid (expected duration < 100 days)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' completed date time valid or course still active.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate diagnosis code table.
        /// Department changed to ICD-10 at 01.01.2014.
        /// </summary>
        internal TestObject DiagnosisCodeTableAttachedValidator(Course course)
        {
            bool isValid = true;

            DateTime changeDate = new DateTime(2014, 1, 1);

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;

            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if ((!course.Diagnosis.DiagnosisCode.Equals("")) && (!course.Diagnosis.GetDiagnosisTable().Equals(DiagnosisTable.ICD9)) && (course.StartDateTime < changeDate))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' and ICD-9 code '" + course.Diagnosis.DiagnosisCode + "' invalid (ICD-9 Code expected < 2014)!; Description code: " + course.Diagnosis.Description + ".";
                isValid = false;
            }

            if ((!course.Diagnosis.DiagnosisCode.Equals("")) && (!course.Diagnosis.GetDiagnosisTable().Equals(DiagnosisTable.ICD10)) && (course.StartDateTime >= changeDate))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' and ICD-10 code for '" + course.Diagnosis.DiagnosisCode + "' invalid (ICD-10 Code expected >= 2014)!; Description code: " + course.Diagnosis.Description + ".";
                isValid = false;
            }

            if (course.Diagnosis.DiagnosisCode.Equals(""))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' has no diagnosis code attached!";
                isValid = false;
            }

            if (isValid)
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' and diagnosis table '" + course.Diagnosis.DiagnosisTableName + "' for '" + course.Diagnosis.DiagnosisCode + "' valid (ICD-9 < 2014; ICD-10 >= 2014).; Description code: " + course.Diagnosis.Description + ".";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Diagnosis code metastases validation.
        /// Department changed to ICD-10 at 01.01.2014.
        /// </summary>
        internal TestObject DiagnosisCodeMetastasesValidator(Course course)
        {
            DateTime changeDate = new DateTime(2014, 1, 1);

            bool isValid = true;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            //string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if ((!course.Diagnosis.DiagnosisCode.Contains("C7")) && (course.CourseId.ToUpper().Contains("MET")) && (course.StartDateTime >= changeDate) && (!course.CourseId.ToUpper().Contains("ENDOMETR")) && (!course.CourseId.ToUpper().Contains("PARAMETR")))
            {
                status = CheckResult.FAILED;
                comment = "ICD metastases validation for course '" + course.CourseId + "' and ICD code '" + course.Diagnosis.DiagnosisCode + "' invalid (expected metastases code)!; Description code: " + course.Diagnosis.Description + ".";
                isValid = false;
            }

            if (course.Diagnosis.DiagnosisCode.Equals(""))
            {
                status = CheckResult.NOCHECK;
                comment = "NO CHECK: ICD metastases validation for course '" + course.CourseId + "' not checked. There is no code available (expected metastases code)!";
                isValid = false;
            }

            if (isValid)
            {
                status = CheckResult.PASSED;
                comment = "ICD metastases validation for course '" + course.CourseId + "' ICD code '" + course.Diagnosis.DiagnosisCode + "' valid (expected metastases code).; Description code: " + course.Diagnosis.Description + ".";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Course intent validation.
        /// </summary>
        internal TestObject CourseIntentValidator(Course course)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            //string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            // Valid options for the course intent since March 2021: benign, curative, local ablation, palliative for symptom control
            bool IsIntentValid = false;
            if (course.CourseIntent.Equals("Palliative for symptom control")) { IsIntentValid = true; }
            if (course.CourseIntent.Equals("Curative")) { IsIntentValid = true; }
            if (course.CourseIntent.Equals("Local ablation")) { IsIntentValid = true; }

            if (!IsIntentValid)
            {
                status = CheckResult.FAILED;
                comment = "Course intent '" + course.CourseIntent + "' for course " + course.CourseId + "' invalid or not attached (expected curative, local ablation or palliative for symptom control)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course intent '" + course.CourseIntent + "' for course '" + course.CourseId + "' valid (expected curative, local ablation or palliative for symptom control).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Course intent and attached diagnosis code validation.
        /// Date changed to ICD-10 in 2014.
        /// </summary>
        internal TestObject CourseIntentDiagnosisCodeValidator(Course course)
        {

            DateTime changeDate = new DateTime(2014, 1, 1);
            bool isValid = true;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
            //string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if ((course.CourseIntent.Equals(CourseIntent.Benign.ToString())) && (course.Diagnosis.DiagnosisCode.ToUpper().StartsWith("C")) && (course.StartDateTime >= changeDate))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' benign course intent '" + course.CourseIntent + "' for malign code " + course.Diagnosis.DiagnosisCode + "' invalid (expected benign intent and code)!";
                isValid = false;
            }

            if (((course.CourseIntent.Equals(CourseIntent.Curative.ToString())) || (course.CourseIntent.Equals(CourseIntent.Palliative.ToString()))) && (!course.Diagnosis.DiagnosisCode.ToUpper().StartsWith("C")) && (course.StartDateTime >= changeDate))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' curative/palliative course intent '" + course.CourseIntent + "' for code '" + course.Diagnosis.DiagnosisCode + "' invalid (expected curative/palliative intent and malign code)!";
                isValid = false;
            }

            if (isValid)
            {
                status = CheckResult.PASSED;
                rtGroup = RtGroup.COURSE;
                comment = "Course '" + course.CourseId + "' course intent '" + course.CourseIntent + "' for code " + course.Diagnosis.DiagnosisCode + "' is matching (validation start courses > 2014).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate if course has a double diagnosis.
        /// </summary>
        private TestObject CourseDiagnosisDoubleValidator(Course course, List<Course> courses)
        {
            List<Course> sortedcourses = courses.OrderBy(c => c.CourseId).ToList();

            int comparator = 0;

            // Iterate over the courses.
            foreach (Course course2 in sortedcourses)
            {
                if ((course.CourseId.Equals(course2.CourseId)) && (!course.Diagnosis.DiagnosisCode.Equals(course2.Diagnosis.DiagnosisCode)))
                {
                    comparator = comparator + 1;
                }
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if (comparator > 0)
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId.ToString() + "' has >= 2 diagnosis codes attached!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId.ToString() + "' has a single diagnosis code attached.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate course order (e.g. 1_ in 2009, 2_ in 2010).
        /// </summary>
        internal List<TestObject> CourseOrderValidator(List<Course> courses)
        {
            List<TestObject> tobjects = new List<TestObject>();

            List<Course> sortedcourses = courses.OrderBy(c => c.StartDateTime).ToList();

            List<int> numberlist = new List<int>();

            foreach (Course course in sortedcourses)
            {
                // Get course number and date and add them to separate lists.
                if (course.CourseId.Length >= 3)
                {
                    Char sub1 = course.CourseId[1];
                    Char sub2 = course.CourseId[2];

                    if ((Char.IsNumber(course.CourseId, 0)) && (sub1 == '_'))
                    {
                        int i;
                        if (int.TryParse(course.CourseId.Substring(0, 1), out i))
                        {
                            numberlist.Add(i);
                        }
                    }

                    if ((Char.IsNumber(course.CourseId, 0)) && (Char.IsNumber(course.CourseId, 1)) && (sub2 == '_'))
                    {
                        int j;
                        if (int.TryParse(course.CourseId.Substring(0, 2), out j))
                        {
                            numberlist.Add(j);
                        }
                    }
                }
            }

            // Compare if first number larger than second number.
            int comparator = 0;
            int k = 0;
            for (int i = 0; i < numberlist.Count; i++)
            {
                if (numberlist.ElementAt(i) >= numberlist.ElementAt(k))
                {
                    comparator = comparator++;
                }
                if (k < numberlist.Count)
                {
                    k++;
                }
            }

            // Set result object for each plan.
            List<string> planInfos = new List<string>();

            // Get all plan information.
            foreach (Course course in courses)
            {
                if (!course.Plan.PlanSetupId.Equals(""))
                {
                    planInfos.Add(RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId);
                }
            }

            // Get unique values.
            planInfos = planInfos.Distinct().ToList();

            // Group fields by planSetupId and validate each plan.
            foreach (string planInfo in planInfos)
            {
                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.COURSE;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = "ALL";
                string rtInformation1 = planInfo;
                string rtInformation2 = "COURSE: ALL";
                string comment = "Unknown";

                if (comparator > 0)
                {
                    status = CheckResult.FAILED;
                    comment = "Course order invalid (expected start date course 1_ < date course 2_, ...)!";
                }
                else
                {
                    status = CheckResult.PASSED;
                    comment = "Course order valid.";
                }

                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                tobjects.Add(to);
            }
            return tobjects;
        }

        /// <summary>
        /// Validate course completed date vs. deathdate.
        /// </summary>
        private TestObject CourseCompletedDeathDateValidator(Course course)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if ((course.Patient.DeathDate != DateTime.MaxValue) && (course.CompletedDateTime != DateTime.MaxValue) && (course.CompletedDateTime.Date > course.Patient.DeathDate.Date))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' completed date '" + course.CompletedDateTime.ToShortDateString() + "' > death date '" + course.Patient.DeathDate.ToShortDateString() + "' (invalid)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' completed date '" + course.CompletedDateTime.ToShortDateString() + "' <= death date '" + course.Patient.DeathDate.ToShortDateString() + "' (valid).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate course active status vs. deathdate.
        /// </summary>
        private TestObject CourseActiveDeathDateValidator(Course course)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if ((course.Patient.DeathDate != DateTime.MaxValue) && (course.ClinicalStatus.Equals("ACTIVE")))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' is active but patient is not alive anymore (" + course.Patient.DeathDate.ToShortDateString() + ")!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' active vs. death date validation passed.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate course active status.
        /// </summary>
        private TestObject CourseCompletedValidator(Course course)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.COURSE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Unknown";

            if (course.ClinicalStatus.Equals("ACTIVE"))
            {
                status = CheckResult.FAILED;
                comment = "Course '" + course.CourseId + "' is still active (completed check validation selected)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Course '" + course.CourseId + "' completed check validation passed (completed check validation selected).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate if more than one clinical courses are active.
        /// </summary>
        internal List<TestObject> MultipleCoursesActiveValidator(List<Course> courses)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get courses which are active.
            courses = courses.Where(c => c.ClinicalStatus.Equals("ACTIVE")).Distinct().ToList();

            string courseIdList = String.Join(", ", courses.Select(c => c.CourseId).Where(c => !c.Equals("")).Distinct().ToList());

            // Display result if more than one course is active.
            if (courses.Select(c => c.CourseId).Distinct().Count() > 1)
            {

                foreach (Course course in courses)
                {

                    CheckResult status = CheckResult.FAILED;
                    RtGroup rtGroup = RtGroup.COURSE;
                    EditableStatus editable = EditableStatus.YES;
                    string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//                    string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
                    string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
                    string comment = "Multiple clinical courses are active. Close all not active clinical courses. Courses active: " + courseIdList + ".";

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

                    tobjects.Add(to);
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Validate courses and patient status.
        /// </summary>
        internal TestObject CoursesPatientStatusValidator(List<Course> courses)
        {
            int counter = 0;

            Course course = new Course(new Patient("", "", "", "", DateTime.MaxValue, PatientSex.Unknown, "", "", DateTime.MaxValue, new Oncologist(12), ""), new Diagnosis("", "ICD-10", DateTime.MaxValue, ""), "", DateTime.Now, DateTime.Now, "", "", new Plan("", 0, "", ""));

            if (courses.Count > 0)
            {
                course = courses.First();
            }

            List<string> courseIds = courses.Where(c => c.CourseId.Length >= 2).Select(c => c.CourseId.Substring(0, 2).Trim()).Where(c => !c.Equals("")).Distinct().ToList();

            int numCourses = courseIds.Distinct().ToList().Count;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = "COURSE: ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = "";
            string comment = "Unknown";

            if (course.Patient.PatientStatus.Equals("None (NA)"))
            {
                status = CheckResult.FAILED;
                comment = "Patient status '" + course.Patient.PatientStatus + "' invalid (expected 'New Patient (NP)' or 'Previous Patient (NOP)')!";
                counter = counter + 1;
            }

            if ((course.Patient.PatientStatus.Equals("New Patient (NP)")) && (numCourses > 1))
            {
                status = CheckResult.FAILED;
                comment = "Patient status '" + course.Patient.PatientStatus + "' invalid (expected 'Previous Patient (NOP)' for > 1 courses)!";
                counter = counter + 1;
            }

            if ((course.Patient.PatientStatus.Equals("Previous Patient (NOP)")) && (numCourses == 1))
            {
                status = CheckResult.FAILED;
                comment = "Patient status '" + course.Patient.PatientStatus + "' invalid (expected 'New Patient (NP)' for 1 course)!";
                counter = counter + 1;
            }

            if (counter == 0)
            {
                status = CheckResult.PASSED;
                comment = "Patient status '" + course.Patient.PatientStatus + "' valid (expected 'New Patient (NP)' for 1 course or 'Previous Patient (NOP)') for > 1 courses.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate course and plan manually with the treatment site, intent and ICD code.
        /// </summary>
        /// <remarks>
        /// Placed unter course due to course diagnosis code and intent.
        /// </remarks>
        internal TestObject CoursePlanManualReviewValidator(Course course)
        {
            string planAbbreviation = "";
            string siteAbbreviation = "";

            // Example shortest version: 3D_BRA is of minimal length 6.
            if (course.Plan.PlanSetupId.Length >= 6)
            {
                planAbbreviation = course.Plan.PlanSetupId.Substring(0, 2);
                siteAbbreviation = course.Plan.PlanSetupId.Substring(3, 3);
            }

            string siteDescription = TreatmentSite.GetTreatmentSiteFromPlanId(course.Plan.PlanSetupId);

            string planDescription = PlanType.GetPlanTypeFromPlanId(course.Plan.PlanSetupId);

            CheckResult status = CheckResult.MANREV;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = course.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + course.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + course.Plan.PlanSetupId + " (" + course.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + course.CourseId;
            string comment = "Plan '" + course.Plan.PlanSetupId + "' of type '" + planDescription + "' will irridiate '" + siteDescription + "' with intent '" + course.CourseIntent + "' and ICD code '" + course.Diagnosis.DiagnosisCode + "' (" + course.Diagnosis.Description + ").";

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
    }
}