﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the control point collision validator.
    /// </summary>
    class ControlPointCollisionValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();
       
            ControlPointCollisionQuery qry = new ControlPointCollisionQuery();

            List<ControlPoint> controlpoints = qry.GetControlPoints(patient);

            tobjects.AddRange(GantryCollisionValidator(controlpoints));
            
            return tobjects;
        }

        /// <summary>
        /// Validate radiation gantry collision with a support angle for each controlpoint.
        /// </summary>
        internal List<TestObject> GantryCollisionValidator(List<ControlPoint> controlpoints)
        {
           
            // Get collision table values.
            CollisionTableHandler cth = new CollisionTableHandler();
            List<CollisionElement> collisionElements = cth.CollisionElementsInTable();

            List<TestObject> tobjects = new List<TestObject>();

            // Get unique plan ids.
            List<long> planSetupSers = controlpoints.Select(c => c.Plan.PlanSetupSer).Where(c => !c.Equals("")).Distinct().ToList();

            // Iterate over plans.
            foreach (long planSetupSer in planSetupSers)
            {
                List<ControlPoint> controlpointsPerPlan = controlpoints.Where(c => c.Plan.PlanSetupSer == planSetupSer).ToList();                   

                    StringBuilder sb = new StringBuilder();

                    // Get unique radiation fields for plan.
                    List<string> radiationIds = controlpointsPerPlan.Select(c => c.RadiationId).Where(c => !c.Equals("")).Distinct().ToList();

                    // Get control points from every radiation field.
                    foreach (string radiationId in radiationIds)
                    {
                        
                        int counter = 0;

                        List<ControlPoint> controlpointsPerField = controlpointsPerPlan.Where(c => c.RadiationId.Equals(radiationId)).ToList();

                       // Get radiation fields from every plan.
                        if (controlpointsPerField.Count > 0)
                        {
                            // Get first element for setting the labels.
                            ControlPoint cpField1 = controlpointsPerField.First();

                            CheckResult status = CheckResult.UNKNOWN;
                            RtGroup rtGroup = RtGroup.FIELD;
                           
                            EditableStatus editable = cpField1.Plan.PlanSetupStatusEditable;
                            string rtInformation0 = RtGroup.COURSE + ": " + cpField1.Plan.CourseId;
                            string rtInformation1 = RtGroup.PLAN + ": " + cpField1.Plan.PlanSetupId;
                            string rtInformation2 = RtGroup.FIELD + ": " + radiationId;
                            string comment = "Unknown";
                           
                        // Iterate over all control point per field.
                        foreach (ControlPoint cpField in controlpointsPerField)
                        {
                            
                            CollisionTableHandler cthField = new CollisionTableHandler();

                            // Collision counter for each control point.
                            if (cthField.HasElementInCollisionTable(collisionElements, cpField.PatientSupportAngle, cpField.GantryRtn))
                            {
                                counter = counter + 1;
                                // Add diplay information.
                                sb.Append("Couch: '" + cpField.PatientSupportAngle.ToString("0.##") + "°', Gantry '" + cpField.GantryRtn.ToString("0.##") + "°'; ");
                            }
                        }

                        // Collisions.
                        if (counter > 0)
                        {
                            status = CheckResult.FAILED;
                            comment = "Field collision test control points (dynamic ARC fields and support angle not 0°) for '" + cpField1.RadiationId + "' and plan '" + cpField1.Plan.PlanSetupId + "' with gantry start '" + cpField1.GantryRtnExField.ToString("0.##") + "°' and stop angle '" + cpField1.StopAngleExField.ToString("0.##") + "°' invalid (expected: all control points not in collision table; enter new values in table). Problematic control points: " + sb.ToString() + "!";

                            counter = counter + 1;
                        }
                        // No collisions.
                        else
                        {
                            status = CheckResult.PASSED;
                            comment = "Field collision control points test (dynamic ARC fields and support angle not 0°) for '" + cpField1.RadiationId + "' and plan '" + cpField1.Plan.PlanSetupId + "' with start angle '" + cpField1.GantryRtnExField.ToString("0.##") + "°' and stop angle '" + cpField1.StopAngleExField.ToString("0.##") + "°' valid (expected: all control points not in collision table; enter new values in table).";
                        }

                        comment = comment.Remove(comment.LastIndexOf("; "), 1);

                        TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                        tobjects.Add(to);
                    }
                }
            }
            return tobjects;
        }      
    }
}