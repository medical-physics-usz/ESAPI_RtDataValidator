﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the image series validator.
    /// </summary>
    class ImageSeriesValidator : Validator
    {

        /// <summary>
        /// Start the validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            ImageSeriesQuery qry1 = new ImageSeriesQuery();

            // Image sets without plans.
            List<ImageSeries> imageseries = qry1.GetImageSeries(patient);

            // Empty data set.
            if (imageseries.Count == 0)
            {
                TestObjectOutput too = new TestObjectOutput();
                tobjects.Add(too.EmptyTestObject(RtGroup.IMAGE));
            }

            foreach (ImageSeries imageserie in imageseries)
            {
                tobjects.Add(SeriesIdValidator(imageserie));
                tobjects.Add(ImageIdValidator(imageserie));
            }

            // Image sets with plans.
            ImageSeriesPlanQuery qry2 = new ImageSeriesPlanQuery();
            List<ImageSeries> imageseriesplans = qry2.GetImageSeries(patient);

            foreach (ImageSeries imageserie in imageseriesplans)
            {
                tobjects.Add(CtPlanPatientOrientationValidator(imageserie));

                // Editable plans.
                if (imageserie.Plan.PlanSetupStatusEditable.Equals(EditableStatus.YES))
                {
                    tobjects.Add(CtPlanCreationDateValidator(imageserie));
                }

                tobjects.Add(UserOriginValidator(imageserie));
            }

            return tobjects;
        }

        /// <summary>
        /// Series id validation.
        /// </summary>
        internal TestObject SeriesIdValidator(ImageSeries imageserie)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.IMAGE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "2-" + RtGroup.IMAGE.ToString();
            string rtInformation2 = "IMG SERIES: " + imageserie.SeriesId + "; IMG ID: " + imageserie.ImageId;
            string comment = "Unknown";

            bool isValidPrefix = true;

            // Validate date format.
            bool isValidDateFormat = GenOperations.IsValidDateFormatAfterUnderscore(imageserie.SeriesId);

            DateTime dateId = DateTime.MaxValue;

            // Verify date in label vs. creation date.
            bool isEqualDate = false;

            // Get date if valid format.
            if (isValidDateFormat)
            {
                dateId = GenOperations.DateAfterUnderscore(imageserie.ImageId);

                if ((dateId.Date.Equals(imageserie.CreationDate.Date)) && (!dateId.Date.Equals(DateTime.MaxValue)))
                {
                    isEqualDate = true;
                }
            }

            // Pet series id.
            if ((!imageserie.SeriesId.StartsWith("PET_")) && (imageserie.SeriesModality.Equals("PT")))
            {
                status = CheckResult.FAILED;
                comment = "Series ID '" + imageserie.SeriesId + "' invalid (expected starting with 'PET_{YY-MM-DD}' for PET series)!";

                isValidPrefix = false;
            }

            // Diagnostic, petct, 4dct, cbct and ct series id.
            if ((!imageserie.SeriesId.StartsWith("4DCT_")) && (!imageserie.SeriesId.StartsWith("PETCT_")) && (!imageserie.SeriesId.StartsWith("CBCT_")) && (!imageserie.SeriesId.StartsWith("CT_")) && (!imageserie.SeriesId.StartsWith("sCT_")) && (!imageserie.SeriesId.StartsWith("DiagCT_")) && (imageserie.SeriesModality.Equals("CT")))
            {
                status = CheckResult.FAILED;
                comment = "Series ID '" + imageserie.SeriesId + "' invalid (expected starting with '4DCT_{YY-MM-DD}', 'PETCT_{YY-MM-DD}', 'CT_{YY-MM-DD}' & 'DiagCT_{YY-MM-DD}' for CT series)!";

                isValidPrefix = false;
            }

            // mr series id.
            if ((!imageserie.SeriesId.StartsWith("MR_")) && (imageserie.SeriesModality.Equals("MR")))
            {
                status = CheckResult.FAILED;
                comment = "Series ID '" + imageserie.SeriesId + "' invalid (expected starting with 'MR_{YY-MM-DD}' for MR series)!";

                isValidPrefix = false;
            }

            // No valid date format.
            if (isValidPrefix && !isValidDateFormat)
            {
                status = CheckResult.FAILED;
                comment = "Series ID '" + imageserie.SeriesId + "' has an invalid date format (expected 'YY-MM-DD')!";
            }

            // No equal date creation and label date.
            if (isValidPrefix && !isEqualDate && isValidDateFormat)
            {
                status = CheckResult.FAILED;
                comment = "Series ID '" + imageserie.SeriesId + "'  date label '" + dateId.ToString("dd.MM.yyyy") + "' does not match creation date '" + imageserie.CreationDate.ToString("dd.MM.yyyy") + "' (expected creation date equals label date)!";
            }

            // Valid.
            if (isValidPrefix && isEqualDate)
            {
                status = CheckResult.PASSED;
                comment = "Series ID '" + imageserie.SeriesId + "' valid (expected {imaging prefix}_{YY-MM-DD}. Creation date equals label date).";
            }  

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Image id validation.
        /// </summary>
        internal TestObject ImageIdValidator(ImageSeries imageserie)
        {
            bool isValidPrefix = true;

            // Validate date format.
            bool isValidDateFormat = GenOperations.IsValidDateFormatAfterUnderscore(imageserie.ImageId);

            DateTime dateId = DateTime.MaxValue;

            // Verify date in label vs. creation date.
            bool isEqualDate = false;

            // Get date if valid format.
            if (isValidDateFormat)
            {
                dateId = GenOperations.DateAfterUnderscore(imageserie.ImageId);

                if ((dateId.Date.Equals(imageserie.CreationDate.Date)) && (!dateId.Date.Equals(DateTime.MaxValue)))
                {
                    isEqualDate = true;
                }
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.IMAGE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "2-" + RtGroup.IMAGE.ToString();
            string rtInformation2 = "IMG SERIES: " + imageserie.SeriesId + "; IMG ID: " + imageserie.ImageId;
            string comment = "Unknown";

            // Pet image id.
            if ((!imageserie.ImageId.StartsWith("PET_")) && (imageserie.SeriesModality.Equals("PT")))
            {
                status = CheckResult.FAILED;
                comment = "Image ID '" + imageserie.ImageId + "' invalid (expected 'PET_{YY-MM-DD}' for PET series)!";

                isValidPrefix = false;
            }

            // 4dct, ct, petct cbct, and diagnostic ct image id.
            if ((!imageserie.ImageId.StartsWith("4DCT_")) && (!imageserie.ImageId.StartsWith("PETCT_")) && (!imageserie.ImageId.StartsWith("CT_")) && (!imageserie.ImageId.StartsWith("sCT_")) && (!imageserie.ImageId.StartsWith("CBCT_")) && (!imageserie.ImageId.StartsWith("DiagCT_")) && (imageserie.SeriesModality.Equals("CT")))
            {
                status = CheckResult.FAILED;
                comment = "Image ID '" + imageserie.ImageId + "' invalid (expected '4DCT_{YY-MM-DD}', 'DiagCT_{YY-MM-DD}', 'PETCT_{YY-MM-DD}' & 'CT_{YY-MM-DD}' for CT series)!";

                isValidPrefix = false;
            }

            // Mr image id.
            if ((!imageserie.ImageId.StartsWith("MR_")) && (imageserie.SeriesModality.Equals("MR")))
            {
                status = CheckResult.FAILED;
                comment = "Image ID '" + imageserie.ImageId + "' invalid (expected 'MR_{YY-MM-DD}' for MR series)!";

                isValidPrefix = false;
            }

            // No valid date format.
            if (isValidPrefix && !isValidDateFormat)
            {
                status = CheckResult.FAILED;
                comment = "Image ID '" + imageserie.SeriesId + "' has an invalid date format (expected 'YY-MM-DD')!";
            }

            // No equal date creation and label date.
            if (isValidPrefix && !isEqualDate && isValidDateFormat)
            {
                status = CheckResult.FAILED;
                comment = "Image ID '" + imageserie.SeriesId + "'  date label '" + dateId.ToString("dd.MM.yyyy") + "' does not match creation date '" + imageserie.CreationDate.ToString("dd.MM.yyyy") + "' (expected creation date equals label date)!";
            }

            // Valid.
            if (isValidPrefix && isEqualDate)
            {
                status = CheckResult.PASSED;
                comment = "Image ID '" + imageserie.ImageId + "' valid (expected {imaging prefix}_{YY-MM-DD}. Creation date equals label date).";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Ct patient orientation and plan treatment orientation equality validation.
        /// Orientation must be equal.
        /// </summary>
        internal TestObject CtPlanPatientOrientationValidator(ImageSeries imageserie)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.IMAGE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + imageserie.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId + " (" + imageserie.Plan.PlanSetupStatus + ")";
            string rtInformation2 = "IMAGE: " + imageserie.ImageId;
            string comment = "Unknown";

            double totalDays = (imageserie.Plan.CreationDate - imageserie.CreationDate).TotalDays;

            if (imageserie.PatientOrientation.Equals(imageserie.Plan.TreatmentOrientation))
            {
                status = CheckResult.PASSED;
                comment = "Patient orientation image set '" + imageserie.ImageId + "' (" + imageserie.PatientOrientation + ") and plan '" + imageserie.Plan.PlanSetupId + "' (" + imageserie.Plan.TreatmentOrientation + ") are equal (expected equality image and treatment orientation).";
            }
            else
            {
                status = CheckResult.FAILED;
                comment = "Patient orientation image set '" + imageserie.ImageId + "' (" + imageserie.PatientOrientation + ") and plan '" + imageserie.Plan.PlanSetupId + "' (" + imageserie.Plan.TreatmentOrientation + ") are not equal (expected equality image and treatment orientation)!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Ct vs plan creation date validation.
        /// CT cannot be older than defined amount of days.
        /// </summary>
        internal TestObject CtPlanCreationDateValidator(ImageSeries imageserie)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.IMAGE;
            EditableStatus editable = imageserie.Plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + imageserie.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId + " (" + imageserie.Plan.PlanSetupStatus + ")";
            string rtInformation2 = "IMAGE: " + imageserie.ImageId;
            string comment = "Unknown";

            double totalDays = (DateTime.Now - imageserie.CreationDate).TotalDays;
            
            // ST plan 1 weeks = 7 days.
            if ((totalDays <= 7) && (imageserie.Plan.IsStereoNoBodyPlan))
            {
                status = CheckResult.PASSED;
                comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' within range (expected SR plans <= 7 days; plans are checked against current date).";
            }
            if ((totalDays > 7) && (imageserie.Plan.IsStereoNoBodyPlan))
            {
                status = CheckResult.FAILED;
                comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' out of range (expected SR plans <= 7 days; plans are checked against current date)!";
            }

            // SB plan 2 weeks = 14 days.
            if ((totalDays <= 14) && (imageserie.Plan.IsSbrtPlan))
            {
                status = CheckResult.PASSED;
                comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' within range (expected SB plans <= 14 days; plans are checked against current date).";
            }
            if ((totalDays > 14) && (imageserie.Plan.IsSbrtPlan))
            {
                status = CheckResult.FAILED;
                comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' out of range (expected SB plans <= 14 days; plans are checked against current date)!";
            }

            // 3 weeks = 21 days for all other plans.
            if ((!imageserie.Plan.IsRadioSurgeryPlan) && (!imageserie.Plan.IsSbrtPlan))
            {
                if (totalDays <= 21)
                {
                    status = CheckResult.PASSED;
                    comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' within range (expected plans <= 21 days; plans are checked against current date).";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "Date difference '" + ((int)totalDays).ToString() + " days' for image set '" + imageserie.ImageId + "' (" + imageserie.CreationDate.ToString("dd.MM.yyyy") + ") and plan '" + imageserie.Plan.PlanSetupId + "' within range (expected plans <= 21 days; plans are checked against current date)!";
                }
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }
        /// <summary>
        /// Ct patient orientation and plan treatment orientation equality validation.
        /// Orientation must be equal.
        /// </summary>
        internal TestObject UserOriginValidator(ImageSeries imageserie)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.IMAGE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + imageserie.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + imageserie.Plan.PlanSetupId + " (" + imageserie.Plan.PlanSetupStatus + ")";
            string rtInformation2 = "IMAGE: " + imageserie.ImageId;
            string comment = "Unknown";
            bool isBrachyPlan = false;

            if (imageserie.Plan.PlanSetupId.Length >= 2) 
            {
                if ((imageserie.Plan.PlanSetupId.Substring(0,2).Equals("ZY")) || (imageserie.Plan.PlanSetupId.Substring(0, 2).Equals("BR")))
                {
                    isBrachyPlan = true;
                }
            }

            if (imageserie.UserOrigin.Item1 == 0 && imageserie.UserOrigin.Item2 == 0 && imageserie.UserOrigin.Item3 == 0  && !isBrachyPlan)
            {
                status = CheckResult.FAILED;
                comment = "User Origin'" + imageserie.ImageId + "' (" + imageserie.PatientOrientation + ") and plan '" + imageserie.Plan.PlanSetupId + "' (" + imageserie.Plan.TreatmentOrientation + ") is not set";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "User Origin '" + imageserie.ImageId + "' (" + imageserie.PatientOrientation + ") and plan '" + imageserie.Plan.PlanSetupId + "' (" + imageserie.Plan.TreatmentOrientation + "' ) is set to x = " + Math.Round(imageserie.UserOrigin.Item1, 2) + " mm, y = " + Math.Round(imageserie.UserOrigin.Item2, 2) + " mm, z = " + Math.Round(imageserie.UserOrigin.Item3, 2) + " mm";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
    }
}