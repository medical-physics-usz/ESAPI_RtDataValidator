﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the general control point validator.
    /// </summary>
    class ControlPointGantrySpeedValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            ControlPointGantrySpeedQuery qry = new ControlPointGantrySpeedQuery();

            List<ControlPoint> controlpoints = qry.GetControlPoints(patient);

            tobjects.AddRange(GantrySpeedValidator(controlpoints));

            return tobjects;
        }

        /// <summary>
        /// Validate gantry speed.
        /// </summary>
        internal List<TestObject> GantrySpeedValidator(List<ControlPoint> controlpoints)
        {

            double minSpeed = 0;
            double maxSpeed = 0;

            List<TestObject> tobjects = new List<TestObject>();

            // Get plans.
            List<string> planSetupIds = controlpoints.Select(c => c.Plan.PlanSetupId).Where(c => !c.Equals("")).Distinct().ToList();
            List<string> planSetupNames = controlpoints.Select(c => c.PlanSetupName).Where(c => !c.Equals("")).Distinct().ToList();

            // Get courses.
            List<string> CoursesIds = controlpoints.Select(c => c.Plan.CourseId).Where(c => !c.Equals("")).Distinct().ToList();


            // Iterate over the courses.
            //foreach (string CoursesId in CoursesIds)
            //{

                // Iterate over plans.
                //foreach (string planSetupId in planSetupIds)
                foreach (string planSetupName in planSetupNames)
                {

                    // Get control points per plan.


                    List<ControlPoint> cpPerPlan = controlpoints.Where(c => c.PlanSetupName.Equals(planSetupName)).OrderBy(c => c.RadiationId).Distinct().ToList();

                    if (cpPerPlan.Count > 0)
                    {
                        // Get min value from xml.
                        MachineInfo mi = new MachineInfo();
                        minSpeed = mi.GetMinSpeedGantrySpeed(cpPerPlan.First().Machine);

                        // Get max speed from database.
                        OperatingLimitQuery qry = new OperatingLimitQuery();
                        maxSpeed = qry.GetOperatingLimit(cpPerPlan.First().Machine, "GantryRtn");
                    }

                    // Get field ids.
                    List<string> radiationIds = cpPerPlan.Select(c => c.RadiationId).Where(c => !c.Equals("")).Distinct().ToList();

                    // Iterate over fields.
                    foreach (string radiationId in radiationIds)
                    {
                        // Get filtered control points per field.
                        List<ControlPoint> cpPerField = cpPerPlan.Where(c => c.RadiationId.Equals(radiationId)).OrderBy(c => c.ControlPointIndex).Distinct().ToList();

                        if (cpPerField.Count > 0)
                        {

                        

                        ControlPoint cp = cpPerField.First();
                            CheckResult status = CheckResult.UNKNOWN;
                            RtGroup rtGroup = RtGroup.FIELD;
                            EditableStatus editable = cp.Plan.PlanSetupStatusEditable;
                            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + cp.Plan.CourseId;
                            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + cp.Plan.PlanSetupId;
                            string rtInformation2 = RtGroup.FIELD.ToString() + ": " + cp.RadiationId;
                            string comment = "Unknown";

                            GantrySpeedHandler gsh = new GantrySpeedHandler();

                            List<double> gantrySpeeds = gsh.GetGantrySpeeds(cpPerField, maxSpeed, cp.Plan.PlanSetupId, cp.Plan.CourseId);

                            bool isValid = gsh.HasValidGantrySpeeds(gantrySpeeds, minSpeed, maxSpeed);

                            string minValue = "";
                            string maxValue = "";
                            string mean = "";

                            float float_minValue = -1;
                            float float_maxValue = -1;
                            float float_mean = -1;


                            if (gantrySpeeds.Count > 0)
                            {
                                minValue = gantrySpeeds.OrderBy(g => g).First().ToString("0.###");
                                maxValue = gantrySpeeds.OrderBy(g => g).Last().ToString("0.###");
                                mean = gantrySpeeds.Average().ToString("0.###");

                                float_minValue = float.Parse(minValue);
                                float_maxValue = float.Parse(maxValue);
                                float_mean = float.Parse(mean);

                            }

                            if (isValid)
                            {
                                status = CheckResult.PASSED;
                                comment = "Gantry speed (min: " + minValue + @" deg/s; mean: " + mean + @" deg/s; max: " + maxValue + @"°/s) for plan '" + cp.Plan.PlanSetupId + "' and field '" + cp.RadiationId + "' and machine '" + cp.Machine.MachineId + @"' valid (expected > " + minSpeed.ToString("0.###") + @" and <= " + maxSpeed.ToString("0.###") + @"°/s).";
                            }
                            else
                            {
                                status = CheckResult.FAILED;
                                comment = "Gantry speed (min: " + minValue + @" deg/s; mean: " + mean + @" deg/s; max: " + maxValue + @"°/s) for plan '" + cp.Plan.PlanSetupId + "' and field '" + cp.RadiationId + "' and machine '" + cp.Machine.MachineId + @"' invalid (expected > " + minSpeed.ToString("0.###") + @" and <= " + maxSpeed.ToString("0.###") + @"°/s)!";
                            }

                            // Skip this test for static fields

                            if (Math.Abs(float_minValue) < 0.01 && Math.Abs(float_maxValue) < 0.01 && Math.Abs(float_mean) < 0.01)
                            {
                                status = CheckResult.NOCHECK;
                                comment = "Static field. Gantry speed not checked (min: " + minValue + @" deg/s; mean: " + mean + @" deg/s; max: " + maxValue + @"°/s) for plan '" + cp.Plan.PlanSetupId + "' and field '" + cp.RadiationId + "' and machine '" + cp.Machine.MachineId;

                            }


                            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                            tobjects.Add(to);
                        }
                    }
                }

            //}

            return tobjects;
        }
    }
}