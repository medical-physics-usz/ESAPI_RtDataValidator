﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the reference point validator.
    /// </summary>
    class RefPointValidator : Validator
    {

        /// <summary>
        /// Start the validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            RefPointQuery qry = new RefPointQuery();

            List<RefPoint> refpoints = qry.GetRefPoints(patient);

              // Empty data set.
            if (refpoints.Count == 0)
            {
                TestObjectOutput too = new TestObjectOutput();
                tobjects.Add(too.EmptyTestObject(RtGroup.REFP));
            }
            else
            {
                foreach (RefPoint refpoint in refpoints)
                {
                    tobjects.Add(RefPointIdValidator(refpoint));
                    tobjects.Add(RefPointLocationValidator(refpoint));
                    tobjects.Add(RefPointTypeValidator(refpoint));
                    // tobjects.Add(RefPointDoseValidator(refpoint));  // temporarely removed because bug (see e.g patient 01310500 plan EC_BREr_1a)
                }

                tobjects.AddRange(RefPointNumberValidator(refpoints));

            }
            return tobjects;
        }

        /// <summary>
        /// Ref point id validation.
        /// Format: Ends with underscore and number.
        /// </summary>
        internal TestObject RefPointIdValidator(RefPoint refpoint)
        {
        
            bool isValidNumber = false;

            bool hasExeptions = false;

            // All exceptions like calypso ref. points.
            int counter = 0;

            if (refpoint.RefPointId.StartsWith("APEX"))
            {
                counter = counter + 1;
            }
            if (refpoint.RefPointId.StartsWith("LEFT"))
            {
                counter = counter + 1;
            }
            if (refpoint.RefPointId.StartsWith("RIGHT"))
            {
                counter = counter + 1;
            }

            if (refpoint.RefPointId.ToUpper().Contains("_SUM"))
            {
                counter = counter + 1;
            }

            if (refpoint.RefPointId.ToUpper().Contains("FLAB"))
            {
                counter = counter + 1;
            }

            if (counter > 0)
            {
                hasExeptions = true;
            }

            // Get last 3 chars and validate.
            if (refpoint.RefPointId.Length >= 3)
            {
                string subString = refpoint.RefPointId.Substring(refpoint.RefPointId.Length - 3);

                Char sub0 = subString[0]; // Underscore.
                Char sub1 = subString[1]; // Underscore or number.
                Char sub2 = subString[2]; // Number.

                // Numbers 0-9.
                if ((Char.IsNumber(sub2)) && (sub1 == '_'))
                {
                    isValidNumber = true;
                }

                // Numbers >=10.
                if ((Char.IsNumber(sub1)) && (Char.IsNumber(sub2)) && (sub0 == '_'))
                {
                    isValidNumber = true;
                }
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.REFP;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId + " (" + refpoint.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId + "; " + RtGroup.REFP.ToString() + ": " + refpoint.RefPointId;
            string comment = "Unknown";

            bool isBrachyPlan = false;

            if (refpoint.Plan.PlanSetupId.Length >= 2)
            {
                if ((refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("ZY")) || (refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("BR")))
                {
                    isBrachyPlan = true;
                }
            }

            // Ref point does not end with underscore and number or is not in the exception list or is for a brahcy plan
            if ((isValidNumber) || (hasExeptions) || (isBrachyPlan))
            {
                status = CheckResult.PASSED;
                comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' valid (expected: ends with underscore and number; e.g. XXXXX_1).";
            }
            else
            {
                status = CheckResult.FAILED;
                comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' invalid (expected: ends with underscore and number; e.g. XXXXX_1)!";
            }
           
            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Ref point id validation.
        /// Format: Ends with underscore and number.
        /// </summary>
        internal TestObject RefPointLocationValidator(RefPoint refpoint)
        {

            bool hasExeptions = false;

            // All exceptions like calypso ref. points.
            int counter = 0;

            if (refpoint.RefPointId.StartsWith("APEX"))
            {
                counter = counter + 1;
            }
            if (refpoint.RefPointId.StartsWith("LEFT"))
            {
                counter = counter + 1;
            }
            if (refpoint.RefPointId.StartsWith("RIGHT"))
            {
                counter = counter + 1;
            }

            if (refpoint.RefPointId.ToUpper().Contains("_SUM"))
            {
                counter = counter + 1;
            }

            if (refpoint.RefPointId.ToUpper().Contains("FLAB"))
            {
                counter = counter + 1;
            }

            if (counter > 0)
            {
                hasExeptions = true;
            }

            

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.REFP;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId + " (" + refpoint.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId + "; " + RtGroup.REFP.ToString() + ": " + refpoint.RefPointId;
            string comment = "Unknown";

            bool isBrachyPlan = false;

            if (refpoint.Plan.PlanSetupId.Length >= 2)
            {
                if ((refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("ZY")) || (refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("BR")))
                {
                    isBrachyPlan = true;
                }
            }

            // Ref point has no location for modulated plans and location for 3D plans.
            if (!hasExeptions)
            {
                //    if (!refpoint.hasRefPointLocation && (refpoint.Plan.IsModulatedPlan))
                //    {
                //        status = CheckResult.PASSED;
                //        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' valid (No location for Modulated Plan).";
                //    }
                //    if (refpoint.hasRefPointLocation && (refpoint.Plan.IsModulatedPlan))
                //    {
                //        status = CheckResult.FAILED;
                //        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' not valid (location for Modulated Plan).";
                //    }
                //    if (!refpoint.hasRefPointLocation && (!refpoint.Plan.IsModulatedPlan))
                //    {
                //        status = CheckResult.FAILED;
                //        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' not valid (No location for 3D Plan).";
                //    }
                //    if (refpoint.hasRefPointLocation && (!refpoint.Plan.IsModulatedPlan))
                //    {
                //        status = CheckResult.PASSED;
                //        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' valid (Location for Modulated Plan).";
                //    }
                //}

                if (isBrachyPlan)
                {
                    // brachy can have location too
                    status = CheckResult.PASSED;
                    comment = "Ref. point '" + refpoint.RefPointId + "' for brachy plan '" + refpoint.Plan.PlanSetupId + "' valid (Both reference point with and without location are allowed for brachy plans).";
                } else
                {
                    // external beam plans cannot have location
                    if (!refpoint.hasRefPointLocation)
                    {
                        status = CheckResult.PASSED;
                        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' valid (No location).";
                    }
                    if (refpoint.hasRefPointLocation)
                    {
                        status = CheckResult.FAILED;
                        comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + "' not valid (Has location).";
                    }
                }

                
            }

                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Ref point type validation.
        /// It should be Target 
        /// </summary>
        internal TestObject RefPointTypeValidator(RefPoint refpoint)
        {

             CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.REFP;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId + " (" + refpoint.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId + "; " + RtGroup.REFP.ToString() + ": " + refpoint.RefPointId;
            string comment = "Unknown";

            // Checks if the reference point is target
            if (refpoint.RefPointType.Equals("Target"))
            {
                status = CheckResult.PASSED;
                comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has valid type " + refpoint.RefPointType + " (expected 'Target')";
            }
            else
            {
                status = CheckResult.FAILED;
                comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has invalid type " + refpoint.RefPointType + " (expected 'Target')";
            }


            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Ref point dose validation.
        /// It checks that the dose in the reference point and the dose in the plan are the same (total and per fraction). The plan dose is taken as reference
        /// </summary>
        internal TestObject RefPointDoseValidator(RefPoint refpoint)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.REFP;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId + " (" + refpoint.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId + "; " + RtGroup.REFP.ToString() + ": " + refpoint.RefPointId;
            string comment = "Unknown";

            // Plan doses
            double planDosePerFraction = refpoint.PlanPrescribedDose;
            int planNoFractions = refpoint.PlanNoFractions;
            double planDoseTotal = planDosePerFraction * planNoFractions;

            // Ref point doses
            long refPointTotalDoseLimit = refpoint.RefPointTotalDoseLimit;
            long refPointDailyDoseLimit = refpoint.RefPointDailyDoseLimit;
            long refPointSessionDoseLimit = refpoint.RefPointSessionDoseLimit;

            // Perform the checks.
            bool isTotalDoseEqual = false;
            bool isFractionDoseEqual = false;
            bool isSessionDoseEqual = false;
            double tollerance = 0.1;  // 0.1 Gy deviation allowed for rounding errors

            // (1) Total dose should be the same in plan and reference point
            if (Math.Abs(planDoseTotal - refPointTotalDoseLimit) < tollerance) 
            {
                isTotalDoseEqual = true;
            }

            // (2) Fraction dose should be the same in plan and reference point
            if (Math.Abs(planDosePerFraction - refPointSessionDoseLimit) < tollerance)
            {
                isFractionDoseEqual = true;
            }

            // (3) Fraction and session dose should be the same  (except for multiple fx per day)
            if (Math.Abs(refPointSessionDoseLimit - refPointDailyDoseLimit) < tollerance)
            {
                isSessionDoseEqual = true;
            }

            // Output for the checks
            if (isTotalDoseEqual & isFractionDoseEqual & isSessionDoseEqual)
            {

                status = CheckResult.PASSED;
                comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has the same total dose limit as the plan normalization: " + refPointTotalDoseLimit.ToString() + " Gy (ref point) vs. " + planDoseTotal + " Gy (plan)";

            } else
            {
                status = CheckResult.NOCHECK;
                comment = "Ref. point dose not checked";

                if (!isTotalDoseEqual)
                {
                    status = CheckResult.FAILED;
                    comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has different total dose limit than the plan: " + refPointTotalDoseLimit.ToString() + " Gy (ref point) vs. " + planDoseTotal + " Gy (plan)";
                }

                if (!isFractionDoseEqual)
                {
                    status = CheckResult.FAILED;
                    comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has different session dose limit than the plan: " + refPointSessionDoseLimit.ToString() + " Gy (ref point) vs. " + planDosePerFraction + " Gy (plan)";
                }

                if (!isSessionDoseEqual)
                {
                    status = CheckResult.FAILED;
                    comment = "Ref. point '" + refpoint.RefPointId + "' for plan '" + refpoint.Plan.PlanSetupId + " has different daily and session doses: " + refPointSessionDoseLimit.ToString() + " Gy (session) vs. " + refPointDailyDoseLimit + " Gy (daily). Note: only accepted if the patient is getting more than one fraction per day, every day.";
                }

            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }


        /// <summary>
        /// Ref point number validation.
        /// There should be only one
        /// </summary>
        internal List<TestObject> RefPointNumberValidator(List<RefPoint> refpoints)
        {

            List<TestObject> tobjects = new List<TestObject>();

            List<string> PlansCoursePlanId = new List<string>();

            // Create the list of all the plans sorted by course

            foreach (RefPoint refpoint in refpoints)
            {

                string tempCourse = refpoint.Plan.CourseId;
                string tempPlanId = refpoint.Plan.PlanSetupId;

                int tempIndex = PlansCoursePlanId.IndexOf(tempCourse + "_" + tempPlanId);

                if (tempIndex < 0)
                {
                    PlansCoursePlanId.Add(tempCourse + "_" + tempPlanId);
                }

            }

            // Count the reference points per plan

            List<int> NRefPointPerPlan = new List<int>();
            for (int i = 0; i < PlansCoursePlanId.Count; i++)
            {
                NRefPointPerPlan.Add(0);
            }

            foreach (RefPoint refpoint in refpoints)
            {

                string tempCourse = refpoint.Plan.CourseId;
                string tempPlanId = refpoint.Plan.PlanSetupId;

                int tempIndex = PlansCoursePlanId.IndexOf(tempCourse + "_" + tempPlanId);

                NRefPointPerPlan[tempIndex] = NRefPointPerPlan[tempIndex] + 1;
            }


            // Run the check


            foreach (RefPoint refpoint in refpoints)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.REFP;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + refpoint.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.COURSE.ToString() + ": " + refpoint.Plan.CourseId + "; " + RtGroup.REFP.ToString() + ": " + refpoint.RefPointId;
                string comment = "Unknown";
                bool isBrachyPlan = false;

                if (refpoint.Plan.PlanSetupId.Length >= 2)
                {
                    if ((refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("ZY")) || (refpoint.Plan.PlanSetupId.Substring(0, 2).Equals("BR")))
                    {
                        isBrachyPlan = true;
                    }
                }



                string tempCourse = refpoint.Plan.CourseId;
                string tempPlanId = refpoint.Plan.PlanSetupId;
                int tempIndex = PlansCoursePlanId.IndexOf(tempCourse + "_" + tempPlanId);

                int NRefPoints = NRefPointPerPlan[tempIndex];

                if (isBrachyPlan)
                {
                    // For brachy >= 6 reference points needed
                    if (NRefPoints >= 6)
                    {
                        status = CheckResult.PASSED;
                        comment = "Ref. point '" + refpoint.RefPointId + "' is one of the " + NRefPoints.ToString() + " points for the brachy plan '" + refpoint.Plan.PlanSetupId + " (expected >= 6 ref points per plan)";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Ref. point '" + refpoint.RefPointId + "' is one of the " + NRefPoints.ToString() + " points for the brachy plan '" + refpoint.Plan.PlanSetupId + " (expected >= 6 ref points per plan)";
                    }

                } else
                {
                    // For external beam only one reference point allowed
                    if (NRefPoints == 1)
                    {
                        status = CheckResult.PASSED;
                        comment = "Ref. point '" + refpoint.RefPointId + "' is the only reference point for the plan '" + refpoint.Plan.PlanSetupId + " (expected one ref point per plan)";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "The plan '" + refpoint.Plan.PlanSetupId + " has N = " + NRefPoints.ToString() + " reference points (expected one ref point per plan)";
                    }
                }

                

                TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES); 
                tobjects.Add(to);
            }

            return tobjects;

        }
    }
}