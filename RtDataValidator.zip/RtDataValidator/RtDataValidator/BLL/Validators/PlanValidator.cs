﻿using RtDataValidator.DAL;
using RtDataValidator.UIL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using RtDataValidator.DAL.Tools;


namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the plan validator.
    /// </summary>
    class PlanValidator : Validator
    {

        /// <summary>
        /// Start validator.
        /// </summary>
        public List<TestObject> GetValidationOutput( ValidationType type, Patient patient )
        {
            List<TestObject> tobjects = new List<TestObject>( );

            PlanQuery planqry = new PlanQuery( );

            List<Plan> plans = planqry.GetPlans( patient );

            // Empty data set.
            if ( plans.Count == 0 )
            {
                TestObjectOutput too = new TestObjectOutput( );
                tobjects.Add( too.EmptyTestObject( RtGroup.PLAN ) );
            }
            else
            {
                foreach ( Plan plan in plans )
                {
                    tobjects.Add( PlanIdValidator( plan ) );
                    tobjects.Add( PlanNameValidator(plan));
                    tobjects.Add( PrescribedDoseValidator( plan ) );
                    tobjects.Add( TotalDoseValidator( plan ) );
                    tobjects.Add( TreatmentOrientationValidator( plan ) );
                    tobjects.Add( CalculationModelNameValidator( plan ) );
                    if (!(plan.PlanSetupId.StartsWith("BR") || plan.PlanSetupId.StartsWith("ZY"))) tobjects.Add( CalculationGridSizeInCmValidator( plan ) );
                    //tobjects.Add( FieldNormalizationTypeValidator( plan ) );
                    tobjects.Add( PlanStatusValidator( plan ) );
                    tobjects.Add(PlanIntentValidator(plan));

                    // Execute if plan is editable.
                    if ( plan.PlanSetupStatusEditable.Equals( EditableStatus.YES ) )
                    {
                        tobjects.Add( FractionationManualReviewValidator( plan ) );

                        // One fraction or SR plan (and editable).
                        if ( ( plan.NoFractions == 1 ) || ( plan.IsRadioSurgeryPlan ) || (plan.PlanSetupId.StartsWith("BR")))
                        {
                            tobjects.Add( PlanRadiosurgerySingleFractionValidator( plan ) );
                        }
                    }
                }
            }
            return tobjects;
        }

        /// <summary>
        /// Validate plan id.
        /// Valid input: PlanabbreviationSiteabbreviationVolume_course (e.g. RApro1_1a)
        /// </summary>
        internal TestObject PlanIdValidator( Plan plan )
        {
            string planAbbreviation = Tools.PlanID_2_PlanAbbreviation(plan.PlanSetupId);
            string siteAbbreviation = Tools.PlanID_2_SiteAbbreviation(plan.PlanSetupId);
            string planVersion = Tools.PlanID_2_PlanVersion(plan.PlanSetupId);
            string planVolumes = Tools.PlanID_2_Volumes(plan.PlanSetupId);
            string connector1 = Tools.PlanID_2_Connector(plan.PlanSetupId);

            bool isValidLength = false;

            // Example shortest version: 3Dbra1_1a is of minimal length 9.
            if ( plan.PlanSetupId.Length >= 9 )
            {
                isValidLength = true;
            }

            XmlFileHandler xrPrefix = new XmlFileHandler( );

            // Validate prefix abbreviation.
            bool isValidPrefix = xrPrefix.HasValueInXmlList( planAbbreviation, @"plantypes.xml", @"plantypes/plantype/plankey" );

            XmlFileHandler xrSite = new XmlFileHandler( );

            // Validate site abbreviation.
            bool isValidSite = xrSite.HasValueInXmlList( siteAbbreviation, @"treatmentsites.xml", @"treatmentsites/treatmentsite/sitekey" );

            // Validate connector between prefix and site.
            bool isValidConnector = false;

            if ( connector1.Equals( "_" ) )
            {
                isValidConnector = true;
            }

            bool isValidEndBlock = false;

            // Reversed plan id
            // {letter small revision}{series number}{_}
            string reversed = new string( plan.PlanSetupId.ToCharArray( ).Reverse( ).ToArray( ) );
            if (plan.PlanSetupId.StartsWith("BR"))
            {
                if (Regex.IsMatch(reversed.Substring(1,3), @"^[a-z]{1}[a-z0-9]{1}[_0-9]{1}.*$") && (plan.PlanSetupId.EndsWith("A") || plan.PlanSetupId.EndsWith("B") || plan.PlanSetupId.EndsWith("C") || plan.PlanSetupId.EndsWith("D") || plan.PlanSetupId.EndsWith("E") || plan.PlanSetupId.EndsWith("F")))
                {
                    isValidEndBlock = true;
                }
            } else
            {
                if (Regex.IsMatch(reversed, @"^[a-z]{1}[a-z0-9]{1}[_0-9]{1}.*$"))
                {
                    isValidEndBlock = true;
                }
            }

            // Validate volumes
            bool isValidVolumes = false;

            if (planVolumes.StartsWith("1") || planVolumes.StartsWith("2") || planVolumes.StartsWith("3") || planVolumes.StartsWith("4") || planVolumes.StartsWith("5") || planVolumes.StartsWith("6") || planVolumes.StartsWith("7") || planVolumes.StartsWith("8") || planVolumes.StartsWith("9"))
            {
                if (planVolumes.EndsWith("1") || planVolumes.EndsWith("2") || planVolumes.EndsWith("3") || planVolumes.EndsWith("4") || planVolumes.EndsWith("5") || planVolumes.EndsWith("6") || planVolumes.EndsWith("7") || planVolumes.EndsWith("8") || planVolumes.EndsWith("9") || planVolumes.EndsWith("0"))
                {
                    isValidVolumes = true;
                }    
            }



            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            if ( ( !isValidPrefix ) || ( !isValidSite ) || ( !isValidConnector ) || ( !isValidEndBlock ) || (!isValidLength) || (!isValidVolumes))
            {
                status = CheckResult.FAILED;
                comment = "Plan ID '" + plan.PlanSetupId + "' invalid (expected '{PlanAbbreviation}{SiteAbbreviation}{Volumes}_{Series}{Version}' (e.g. 3Dpro1_1a (3D plan prostate), SRbra5-10_1a (SRS brain), or BRgyn1_1aA (brachy))!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Plan ID '" + plan.PlanSetupId + "' valid (expected '{PlanAbbreviation}{SiteAbbreviation}{Volumes}_{Series}{Version}' (e.g. 3Dpro1_1a (3D plan prostate), SRbra5-10_1a (SRS brain), or BRgyn1_1aA (brachy))!";
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate plan Name.
        /// Valid input: course_planabbreviation_siteabbreviation (e.g. 1_3Dpro1_1a (3D prostate plan).
        /// </summary>
        internal TestObject PlanNameValidator(Plan plan)
        {
            string prefixPlanName = "";
            string centerPlanName = "";


            // Example shortest version: 1_3Dpro1_1a is of minimal length 11.
            if (plan.PlanSetupId.Length >= 9 && plan.Name.Length >= 11)
            {
                prefixPlanName = plan.Name.Substring(0, 2);
                centerPlanName = plan.Name.Substring(2, 9);
            }

            // Check if PlanName starts with the course number
            bool PlanSetupName_CourseOk = false;
            if (prefixPlanName.Equals("1_") || prefixPlanName.Equals("2_") || prefixPlanName.Equals("3_") || prefixPlanName.Equals("4_") || prefixPlanName.Equals("5_") || prefixPlanName.Equals("6_") || prefixPlanName.Equals("7_") || prefixPlanName.Equals("8_") || prefixPlanName.Equals("9_"))
            {
                centerPlanName = plan.Name.Substring(2);
                PlanSetupName_CourseOk = true;
            }

            // re-do for pland of patients with more than >10 courses
            if (prefixPlanName.Equals("10") || prefixPlanName.Equals("11") || prefixPlanName.Equals("12") || prefixPlanName.Equals("13") || prefixPlanName.Equals("14") || prefixPlanName.Equals("15") || prefixPlanName.Equals("16") || prefixPlanName.Equals("17") || prefixPlanName.Equals("18") || prefixPlanName.Equals("19") || prefixPlanName.Equals("20"))
            {
                centerPlanName = plan.Name.Substring(3);
                PlanSetupName_CourseOk = true;
            }

            // Check if after the course there is the plan ID
            bool PlanSetupName_IdOk = false;
            if (centerPlanName.Equals(plan.PlanSetupId))
            {
                PlanSetupName_IdOk = true;
            }

            // Check if the course and the plan ID start with the same number
            bool isCourseNumberSameAsPlanNumber = false;
            string prefixCourse = "";
            if (plan.CourseId.Length >= 2)
            {
                prefixCourse = plan.CourseId.Substring(0, 2);
            }
            if (prefixCourse.Equals(prefixPlanName))
            {
                isCourseNumberSameAsPlanNumber = true;
            }



            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string comment = "Unknown";

            if ((!PlanSetupName_CourseOk) || (!PlanSetupName_IdOk) || (!isCourseNumberSameAsPlanNumber))
            {
                status = CheckResult.FAILED;
                comment = "Plan Name '" + plan.Name + "' invalid (expected '{Course}{_}{PlanID}' (e.g. 1_3Dpro1_1a (3D plan prostate), 4_RAlur5_1a (RA plan lung right))!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Plan Name '" + plan.Name + "' valid (expected '{Course}{_}{PlanID}' (e.g. 1_3Dpro1_1a (3D plan prostate), 4_RAlur5_1a (RA plan lung right))!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate prescribed dose.
        /// </summary>
        internal TestObject PrescribedDoseValidator( Plan plan )
        {
            bool hasError = false;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            if ( plan.PrescribedDose < 1 )
            {
                status = CheckResult.FAILED;
                comment = "Prescribed dose for plan '" + plan.PlanSetupId + "': '" + plan.PrescribedDose + " Gy' invalid (expected dose larger than 1 Gy)!";
                hasError = true;
            }

            if ( plan.PrescribedDose > 30 )
            {
                status = CheckResult.FAILED;
                comment = "Prescribed dose for plan '" + plan.PlanSetupId + "': '" + plan.PrescribedDose + " Gy' invalid (expected dose less than 30 Gy)!";
                hasError = true;
            }

            if ( !hasError )
            {
                status = CheckResult.PASSED;
                comment = "Prescribed dose for plan '" + plan.PlanSetupId + "': '" + plan.PrescribedDose + " Gy' valid (dose between 1 and 30 Gy).";
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate treatment orientation.
        /// Standard HFS, otherwise manual review.
        /// </summary>
        internal TestObject TreatmentOrientationValidator( Plan plan )
        {
            // Head first supine.
            string defaultHfs = "HFS";

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            if ( !plan.TreatmentOrientation.Equals( defaultHfs ) )
            {
                status = CheckResult.MANREV;
                comment = "Treatment orientation for plan '" + plan.PlanSetupId + "' has not default value 'HFS'!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Treatment orientation for plan '" + plan.PlanSetupId + "' has default value HFS.";
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate calculation model name.
        /// Data is saved in database as xml string.
        /// </summary>
        internal TestObject CalculationModelNameValidator( Plan plan )
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "";

            bool isBrachyPlan = false;

            if (plan.PlanSetupId.Length >= 2)
            {
                if ((plan.PlanSetupId.Substring(0, 2).Equals("ZY")) || (plan.PlanSetupId.Substring(0, 2).Equals("BR")))
                {
                    isBrachyPlan = true;
                }
            }

            string photonModelName = XmlFileHandler.GetSetting( "photonmodel" );
            string photonModelModulatedName = XmlFileHandler.GetSetting( "photonmodelmod" );
            string electronModelName = XmlFileHandler.GetSetting( "electronmodel" );

            bool isModulated = plan.IsModulatedPlan;

            PlanCalcModelOptionsExtractor pe = new PlanCalcModelOptionsExtractor( plan.CalcModelOptions );



            // work-around due to faulty implementation of XML processing
            uint CurrOccurrence = 0;
            while ( true )
            {
                string particleType = pe.ParticleType( CurrOccurrence );
                string calculationModelName = pe.CalculationModelName( CurrOccurrence );

                // if either string extracted from the CalcModelOptions is empty string, stop processing
                if ( particleType.Equals( "" ) || calculationModelName.Equals( "" ) )
                {
                    break;
                }



                // Not modulated photons.
                if ( ( !calculationModelName.Equals( photonModelName ) ) && ( particleType.Equals( "PHOTON" ) ) && ( !isModulated ) )
                {
                    status = CheckResult.FAILED;
                    if ( comment != "" )
                    {
                        comment += ";   ";
                    }
                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' invalid (expect model '" + photonModelName + "')!";
                }

                else if ( ( calculationModelName.Equals( photonModelName ) ) && ( particleType.Equals( "PHOTON" ) ) && ( !isModulated ) )
                {
                    if ( status != CheckResult.FAILED && status != CheckResult.MANREV )
                    {
                        status = CheckResult.PASSED;
                    }
                    if ( comment != "" )
                    {
                        comment += ";   ";
                    }
                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' valid (expect model '" + photonModelName + "').";
                }

                // Modulated photons. 
                else if ( ( !calculationModelName.Equals( photonModelModulatedName ) ) && ( particleType.Equals( "PHOTON" ) ) && ( isModulated ) )
                {
                    status = CheckResult.FAILED;
                    if ( comment != "" )
                    {
                        comment += ";   ";
                    }
                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' invalid (expect model '" + photonModelModulatedName + "').";
                }

                else if ( ( calculationModelName.Equals( photonModelModulatedName ) ) && ( particleType.Equals( "PHOTON" ) ) && ( isModulated ) )
                {
                    if ( status != CheckResult.FAILED && status != CheckResult.MANREV )
                    {
                        status = CheckResult.PASSED;
                    }
                    if ( comment != "" )
                    {
                        comment += ";   ";
                    }
                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' valid (expect model '" + photonModelModulatedName + "').";
                }

                // Electrons.
                   else if (particleType.Equals("ELECTRON"))
                        {
                            if (calculationModelName.Equals(electronModelName))
                            {
                                status = CheckResult.PASSED;
                                if (comment != "")
                                {
                                    comment += ";   ";
                                }
                                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' valid (expect model '" + electronModelName + "').";
                            }
                            else
                            {
                                status = CheckResult.FAILED;
                                if (comment != "")
                                {
                                    comment += ";   ";
                                }
                                comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' invalid (expect model '" + electronModelName + "')!";
                            }
                        }

                else
                {
                    if ( status != CheckResult.FAILED )
                    {
                        status = CheckResult.MANREV;
                    }
                    if ( comment != "" )
                    {
                        comment += ";   ";
                    }
                    comment += "Calculation model name for plan '" + plan.PlanSetupId + "' and particle type '" + particleType + "' and calculation model name '" + calculationModelName + "' did not conform to one of the expected patterns and must be reviewed!";
                }

                //// Empty value.
                //if ( calculationModelName.Equals( "" ) )
                //{
                //    status = CheckResult.NOCHECK;
                //    comment = "NO CHECK: Calculation model name for plan '" + plan.PlanSetupId + "' empty.";
                //}



                ++CurrOccurrence;
            }

            if (isBrachyPlan)
            {
                if (plan.CalcModelOptions.Contains("TG-43"))
                {
                    status = CheckResult.PASSED;
                    comment += "Calculation model  TG-43 for brachytherapy plan '" + plan.PlanSetupId + " is correct. (expected model 'TG-43')";
                    ++CurrOccurrence;

                } else if (plan.CalcModelOptions.Contains("Acuros"))
                {
                    status = CheckResult.FAILED;
                    comment += "Calculation model Acuros for brachytherapy plan '" + plan.PlanSetupId + " is not correct. (expected model 'TG-43')";
                    ++CurrOccurrence;
                } else
                {
                    status = CheckResult.MANREV;
                    comment += "Calculation model name for brachytherapy plan '" + plan.PlanSetupId + " failed to check. Please check manually in the report. (expect model 'TG-43')";
                    ++CurrOccurrence;
                }

            }

            // if no occurrences processed above, set to MANREV for missing entry
            if ( CurrOccurrence.Equals( 0 ) )
            {
                status = CheckResult.MANREV;
                comment = "Calculation model name for plan '" + plan.PlanSetupId + "' NOT SET and must be reviewed!";
            }



            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );
            return to;
        }

        /// <summary>
        /// Manual review plan setup status.
        /// </summary>
        internal TestObject PlanStatusManualReviewValidator( Plan plan )
        {

            CheckResult status = CheckResult.MANREV;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Plan status" + plan.PlanSetupStatus + " for plan '" + plan.PlanSetupId + "'.";

            // Plan is editable.
            if ( plan.PlanSetupStatusEditable.Equals( EditableStatus.YES ) )
            {
                status = CheckResult.NOCHECK;
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate calculation model name.
        /// Data is saved in database as xml string.
        /// </summary>
        internal TestObject CalculationGridSizeInCmValidator( Plan plan )
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            PlanCalcModelOptionsExtractor pe = new PlanCalcModelOptionsExtractor( plan.CalcModelOptions );

            bool isValid = true;

            double gridsize = -1;
            double gridsizeSRS = -1;


            if ( pe.CalculationGridSizeInCm() != null )
            {
                Double.TryParse( pe.CalculationGridSizeInCm(), out gridsize );
                Double.TryParse(pe.CalculationGridSizeInCmForSRS(), out gridsizeSRS);
            }


            // Workaround for Aria 16
            double gridsizeSRST = Math.Max(gridsize, gridsizeSRS);

            // SR plan (==0.1).
            if ( plan.IsRadioSurgeryPlan )
            {
                if ( (gridsizeSRST <= 0 ) || (gridsizeSRST > 0.1 ) )
                {
                    status = CheckResult.FAILED;
                    comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size '" + gridsizeSRST + "' invalid (expected value: <= 0.1cm for SR plans --> set 0.1cm to both grid sizes)!";

                    isValid = false;
                }
            }

            // ST plan (<= 0.15).
            if ( plan.IsStereoPlan )
            {
                if ((gridsizeSRST <= 0) || (gridsizeSRST > 0.1))
                {
                    status = CheckResult.FAILED;
                    comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size '" + gridsizeSRST + "' invalid (expected value: <= 0.1cm for ST plans --> set 0.1cm to both grid sizes)!";

                    isValid = false;
                }
            }

            // SB plan (>=0.1 and <= 0.25).
            if ( plan.IsSbrtPlan )
            {
                if ( ( gridsize <= 0 ) || ( gridsize > 0.25 ) )
                {
                    status = CheckResult.FAILED;
                    comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size '" + pe.CalculationGridSizeInCm() + "' invalid (expected value: >=0.1 and <= 0.25 for SB plans)!";
                    isValid = false;
                }
            }

            // Default (> 0 and <= 0.25).
            if ( !plan.IsRadioSurgeryPlan && !plan.IsSbrtPlan && !plan.IsStereoPlan )
            {
                if ( ( gridsize < 0 ) || ( gridsize > 0.25 ) )
                {
                    status = CheckResult.FAILED;
                    comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size: '" + pe.CalculationGridSizeInCm() + "' invalid (expected value <=0.25 for standard plans - justify exceptions!).";
                    isValid = false;
                }
            }

            if ( isValid )
            {
                status = CheckResult.PASSED;
                if (plan.IsRadioSurgeryPlan)
                {
                   //comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size: '" + pe.CalculationGridSizeInCmForSRS() + "' valid (expected value: 0.25 standard plans; >=0.1 and <= 0.25  SB plans; 0.1 SR plans; >=0.1 und <= 0.15 ST plans).";
                   comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size: '" + gridsizeSRST + "' valid (expected value: <=0.25 standard plans and SBRT; <=0.1 SR and ST plans).";

                }
                else
                {
                   comment = "Calculation grid size for plan '" + plan.PlanSetupId + "' and calculation grid size: '" + gridsize + "' valid (expected value: <=0.25 standard plans and SBRT; <=0.1 SR and ST plans).";
                }
               
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }


        /// <summary>
        /// Validate field normalization type.
        /// Data is saved in database as xml string.
        /// Update 27.11.2020: it is always "no field normalization" for Acuros, it does not provide relevant information. Removed from validator.
        /// </summary>
        internal TestObject FieldNormalizationTypeValidator( Plan plan )
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            PlanCalcModelOptionsExtractor pe = new PlanCalcModelOptionsExtractor( plan.CalcModelOptions );

            // Field normalization.
            if ( !pe.FieldNormalizationType( ).Equals( "100% to isocenter" ) ) // this applies only to AAA!
            {
                status = CheckResult.FAILED;
                comment = "Field normalization type for plan '" + plan.PlanSetupId + "' and field normalization type: '" + pe.FieldNormalizationType( ) + "' invalid (expected value: '100% to isocenter')!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Field normalization type for plan '" + plan.PlanSetupId + "' and field normalization type: '" + pe.FieldNormalizationType( ) + "' valid (expected value: '100% to isocenter').";
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate total dose.
        /// </summary>
        internal TestObject TotalDoseValidator( Plan plan )
        {
            bool hasError = false;

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            if ( plan.TotalDose( ) < 1 )
            {
                status = CheckResult.FAILED;
                comment = "Total dose for plan '" + plan.PlanSetupId + "': '" + plan.TotalDose( ) + " Gy (" + plan.PrescribedDose + " Gy * " + plan.NoFractions + " fractions') invalid (expected dose larger than 1 Gy)!";
                hasError = true;
            }

            if ( plan.TotalDose( ) > 100 )
            {
                status = CheckResult.FAILED;
                comment = "Total dose for plan '" + plan.PlanSetupId + "': '" + plan.TotalDose( ) + " Gy' ('" + plan.PrescribedDose + " Gy' * '" + plan.NoFractions + " fractions') invalid (expected dose less than 100 Gy)!";
                hasError = true;
            }

            if ( !hasError )
            {
                status = CheckResult.PASSED;
                comment = "Total dose for plan '" + plan.PlanSetupId + "': '" + plan.TotalDose( ) + " Gy' ('" + plan.PrescribedDose + " Gy' * '" + plan.NoFractions + " fractions') valid (dose between 1 and 100 Gy).";
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate manual fractionation.
        /// </summary>
        private TestObject FractionationManualReviewValidator( Plan plan )
        {

            CheckResult status = CheckResult.MANREV;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Fractionation for plan '" + plan.PlanSetupId + "': '" + plan.PrescribedDose + " Gy' * '" + plan.NoFractions + " fractions' = '" + plan.TotalDose( ) + " Gy'.";

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate radiosurgery single fraction.
        /// </summary>
        internal TestObject PlanRadiosurgerySingleFractionValidator( Plan plan )
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            // SR or BR plan.
            if ( plan.IsRadioSurgeryPlan || plan.PlanSetupId.StartsWith("BR") )
            {
                if ( plan.NoFractions == 1 )
                {
                    status = CheckResult.PASSED;
                    comment = "Single fraction validation for SR or BR plans '" + plan.PlanSetupId + "' valid (expected 'SR or BR}' for single fraction).";
                }
                else
                {
                    status = CheckResult.FAILED;
                    comment = "Single fraction validation for SR or BR plan '" + plan.PlanSetupId + "' possibly invalid (expected 'SR or BR' for single fraction).";
                }
            }

            // NO SR plan.
            if (!(plan.IsRadioSurgeryPlan || plan.PlanSetupId.StartsWith("BR")))
            {
                if ( plan.NoFractions == 1 )
                {
                    status = CheckResult.FAILED;
                    comment = "Radiosurgery single fraction validation for plan '" + plan.PlanSetupId + "' possibly invalid (expected 'SR' for single fraction)!";
                }

                else
                {
                    status = CheckResult.NOCHECK;
                    comment = "NO CHECK: Radiosurgery single fraction validation for plan '" + plan.PlanSetupId + "' not performed.";
                }
            }

            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate plan status.
        /// </summary>
        internal TestObject PlanStatusValidator( Plan plan )
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + plan.PlanSetupId + " (" + plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + plan.CourseId;
            string comment = "Unknown";

            // No editable plan.
            if ( editable.Equals( EditableStatus.NO ) )
            {
                status = CheckResult.NOCHECK;
                comment = "NO CHECK: Plan status '" + plan.PlanSetupStatus + "' for plan '" + plan.PlanSetupId + "' not checked (plan is completed or not approved).";
            }

            // Editable plan.
            if ( editable.Equals( EditableStatus.YES ) )
            {
                status = CheckResult.PASSED;
                comment = "Plan status '" + plan.PlanSetupStatus + "' for plan '" + plan.PlanSetupId + "' has approval status.";
            }

            // extra: save the plan status for the database
            string temp_PlanIdIN = FormOperations.PLANSETUPIDGLOBAL.Trim();
            string temp_CourseIdIN = FormOperations.COURSEIDGLOBAL.Trim();
            if (temp_PlanIdIN.Equals(plan.PlanSetupId) && temp_CourseIdIN.Equals(plan.CourseId))
            {
                FormOperations.PLANSETUPSTATUSGLOBAL = plan.PlanSetupStatus.ToString();
            }


            TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

            return to;
        }

        /// <summary>
        /// Validate plan intent.
        /// </summary>
        internal TestObject PlanIntentValidator(Plan plan)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PLAN;
            EditableStatus editable = plan.PlanSetupStatusEditable;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string comment = "Unknown";

            // checked variable
            bool isIntentGood = false;

            // perform check
            if (plan.PlanIntent.Equals("CURATIVE") || plan.PlanIntent.Equals("PALLIATIVE"))
            {
                isIntentGood = true;
            }

            // give output
            if (isIntentGood)
            {
                status = CheckResult.PASSED;
                comment = "Plan intent is '" + plan.PlanIntent + "' for plan '" + plan.PlanSetupId + "' is valid.";

            } else
            {
                status = CheckResult.FAILED;
                comment = "Plan intent is '" + plan.PlanIntent + "' for plan '" + plan.PlanSetupId + "' is not valid. (Expected 'Curative' or 'Palliative', otherwise plan cannot be opened at the linac for treatment)";
            }


            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
    }
}