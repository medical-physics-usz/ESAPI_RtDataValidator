﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the patient diagnosis validator.
    /// </summary>
    class PatientDiagnosisValidator : Validator
    {

        /// <summary>
        /// Get the validated patient diagnosis output.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            PatientDiagnosisQuery qry = new PatientDiagnosisQuery();

            List<Diagnosis> diagnosislist = qry.GetPatientDiagnoses(patient);

            // No diagnosis code attached.
            if (diagnosislist.Count == 0)
            {
                TestObject to = new TestObject(CheckResult.FAILED, RtGroup.PATIENT, EditableStatus.YES, "" ,RtGroup.PATIENT.ToString(), "", "No patient diagnosis codes are available!", Printable.NO);

                tobjects.Add(to);
            }
            else
            {
                tobjects.Add(PatientDiagnosisTableTenAvailableValidator(diagnosislist, patient));

                foreach (Diagnosis diagnosis in diagnosislist)
                {
                    tobjects.Add(PatientDiagnosisTableValidator(diagnosis, patient));
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Patient diagnosis table validator.
        /// </summary>
        internal TestObject PatientDiagnosisTableValidator(Diagnosis diagnosis, Patient patient)
        {
            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = RtGroup.ICD.ToString() + ": " + diagnosis.DiagnosisCode;
            string comment = "Unknown";

            bool isValid = true;

            DateTime changeDate = new DateTime(2014, 1, 1);

            if ((diagnosis.DateStamp >= changeDate) && (diagnosis.GetDiagnosisTable().Equals(DiagnosisTable.ICD9)))
            {
                status = CheckResult.FAILED;
                comment = "Patient diagnosis '" + diagnosis.DiagnosisCode + "' diagnosis code table ICD-9 for '" + diagnosis.DiagnosisCode + "' is invalid (ICD-9 Code expected < 2014)!; Description code: " + diagnosis.Description + ".";

                isValid = false;
            }

            if ((diagnosis.DateStamp < changeDate) && (diagnosis.GetDiagnosisTable().Equals(DiagnosisTable.ICD10)))
            {
                status = CheckResult.FAILED;
                comment = "Patient diagnosis '" + diagnosis.DiagnosisCode + "' diagnosis code table ICD-10 for '" + diagnosis.DiagnosisCode + "' invalid (ICD-10 code expected >= 2014)!; Description code: " + diagnosis.Description + ".";

                isValid = false;
            }

            if (isValid)
            {
                status = CheckResult.PASSED;
                comment = "Patient diagnosis '" + diagnosis.DiagnosisCode + "' with diagnosis code table " + diagnosis.DiagnosisTableName + "' valid.; Description code: " + diagnosis.Description + ".";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Patient diagnosis table ICD-10 codes available validator.
        /// </summary>
        internal TestObject PatientDiagnosisTableTenAvailableValidator(List<Diagnosis> diagnosislist, Patient patient)
        {

            int counter = 0;

            DateTime changeDate = new DateTime(2014, 1, 1);
            foreach (Diagnosis diagnosis in diagnosislist)
            {

                if (diagnosis.GetDiagnosisTable().Equals(DiagnosisTable.ICD10))
                {

                    counter++;
                }
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.PATIENT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": ALL";
            string rtInformation1 = "1-" + RtGroup.PATIENT.ToString();
            string rtInformation2 = RtGroup.ICD.ToString() + ": ALL";
            string comment = "Unknown";

            if (counter != 0)
            {
                status = CheckResult.PASSED;
                comment = "Diagnosis is available and valid (expected new patients: >=2014 ICD-10 code).";
            }
            else
            {
                status = CheckResult.FAILED;
                comment = "Diagnosis is not available or invalid (expected new patients: >=2014 ICD-10 code)!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }
    }
}