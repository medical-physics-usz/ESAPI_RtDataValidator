﻿using RtDataValidator.DAL;
using RtDataValidator.UIL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the structure validator.
    /// </summary>
    class StructureValidator : Validator
    {

        /// <summary>
        /// Start structure validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            StructureQuery qry = new StructureQuery();
            PlanQuery planqry = new PlanQuery();

            List<Plan> plans = planqry.GetPlans(patient);
            List<Structure> structures = qry.GetStructures(patient);


            tobjects.AddRange(StructureStatusValidator(structures));
            tobjects.AddRange(StructureTypeValidator(structures));
            tobjects.AddRange(StructureHUValidator(structures));
            tobjects.AddRange(StructureBolusValidator(structures));
            tobjects.AddRange(StructureResolutionValidator(structures));

            foreach (Plan plan in plans)
            {
                tobjects.AddRange(CouchValidator(structures, plan));
            }

            return tobjects;
        }

        /// <summary>
        /// Structure status validation.
        /// Ptv and gtv structures must be approved by an oncologist (also ctv for BR plans)
        /// </summary>
        internal List<TestObject> StructureStatusValidator(List<Structure> structures)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Get all target structures.
            List<Structure> ptvStructures = structures.Where(s => s.VolumeType.Equals("PTV") || s.VolumeType.Equals("CTV") || s.VolumeType.Equals("GTV")).OrderBy(s => s.StructureId).Distinct().ToList(); // 2 = GTV , 3 = CTV , 4 = PTV

            // Identify the UID for all PTVs in this patient (used as stamp for identifying a plan)
            int temp_PTVUID = 0;

            // Iterate over ptv structures.
            foreach (Structure structure in ptvStructures)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.STRUCT;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structure.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId;
                //                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId + " (" + structure.Plan.PlanSetupStatus + ")";
                string rtInformation2 = RtGroup.STRUCT.ToString() + ": " + structure.StructureId + " (" + structure.StructureStatus + ")";
                string comment = "Unknown";

                // Check if oncologist (old with query, not working)
                OncologistOutput oo = new OncologistOutput();
                bool isOncologist = oo.IsOncologistByUserName(structure.StatusUserName, OncologistOutput.ONCOLOGISTS);

                // Check if oncologist (new, hard coded, updated on 11.09.2020)
                bool isOncologist_HardCoded = false;
                string strOngologistName = "Unknown";

                bool isNamePH = false;
                if (structure.StructureId.Length >= 3)
                {
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("PH")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("Ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("EZ")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("VB")) { isNamePH = true; }
                    if (structure.StructureId.Substring(0, 2).Equals("VB")) { isNamePH = true; }
                }


                if (structure.StatusUserName.Equals("usz\\example")) { isOncologist_HardCoded = true; strOngologistName = "Dr. Example"; }


                // Start with a failed test
                status = CheckResult.FAILED;
                comment = "Test not performed" + structure.StatusUserName;

                if (!isNamePH)
                {
                    // Structure not approved
                    if (!structure.StructureStatus.Equals("APPROVED"))
                    {
                        status = CheckResult.FAILED;
                        comment = "Structure status '" + structure.StructureId + "' and type '" + structure.VolumeType + "' with status '" + structure.StructureStatus + "' and status edited by '" + structure.StatusUserName + "' (expected status 'APPROVED' by an oncologist and not by a staff member; Structures with 'VB_', '_Ph' and 'Help' are filtered out)!";
                    }

                    // Staff approval.
                    if ((structure.StructureStatus.Equals("APPROVED")) && (!isOncologist_HardCoded))
                    {
                        status = CheckResult.FAILED;
                        comment = "Structure status '" + structure.StructureId + "' and type '" + structure.VolumeType + "' with status '" + structure.StructureStatus + "' and status edited by staff '" + structure.StatusUserName + "' (expected status 'APPROVED' by an oncologist and not by a staff member; Structures with 'VB_', '_Ph' and 'Help' are filtered out).";
                    }

                    // Oncologist approval.
                    if (structure.StructureStatus.Equals("APPROVED") && isOncologist_HardCoded)
                    {
                        status = CheckResult.PASSED;
                        comment = "Structure status '" + structure.StructureId + "' and type '" + structure.VolumeType + "' with status '" + structure.StructureStatus + "' and status edited by oncologist '" + strOngologistName + "' (expected status 'APPROVED' by an oncologist and not by a staff member; Structures with 'VB_', '_Ph' and 'Help' are filtered out).";

                        // sum the UIDs of all the oncologists approved PTVs
                        temp_PTVUID = temp_PTVUID + Int32.Parse(structure.StructureSer);

                    }

                    TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);


                    // decide to add or not depending on brachy/normal plan
                    // Special checks for brachy plans
                    bool isPlanBrachy = false;
                    bool ignoreTargets = false;
                    if (structure.Plan.PlanSetupId.StartsWith("ZY")) { isPlanBrachy = true; ignoreTargets = true; }
                    if (structure.Plan.PlanSetupId.StartsWith("BR")) { isPlanBrachy = true; }

                    if (ignoreTargets)
                    {
                         // empty
                    }
                    else
                    {
                        if (isPlanBrachy)
                        {
                            tobjects.Add(to);
                        }
                        else // normal plans
                        {
                            if (!structure.VolumeType.Equals("CTV")) { tobjects.Add(to); }
                        }
                    }
                    
                }


            }

            // update the global PTVUID
            FormOperations.PTVUID = temp_PTVUID.ToString();

            //return the test objects
            return tobjects;
        }

        /// <summary>
        /// Structure type validation.
        /// PTV and GTV structures must be type PTV and GTV
        /// </summary>
        internal List<TestObject> StructureTypeValidator(List<Structure> structures)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Iterate over all the structures.
            foreach (Structure structure in structures)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.STRUCT;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structure.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.STRUCT.ToString() + ": " + structure.StructureId + " (" + structure.StructureStatus + ")";
                string comment = "Unknown";

                // Define the variables to check 
                bool isNamePTV = false;
                bool isNameGTV = false;
                bool isNamePH = false;


                bool isTypePTV = false;
                bool isTypeGTV = false;


                // Retrive their values
                if (structure.StructureId.Length >= 3)
                {
                    if (structure.StructureId.Substring(0, 3).Equals("PTV")) { isNamePTV = true; }
                    if (structure.StructureId.Substring(0, 3).Equals("GTV")) { isNameGTV = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("PH")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("Ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("EZ")) { isNamePH = true; }
                }

                if (structure.VolumeType.Equals("PTV")) { isTypePTV = true; }
                if (structure.VolumeType.Equals("GTV")) { isTypeGTV = true; }

                // Logical three to check the parameters
                if (!isNamePH)
                {

                    if (isNamePTV)
                    {
                        if (isTypePTV)
                        {
                            status = CheckResult.PASSED;
                            comment = "Structure '" + structure.StructureId + "' has type '" + structure.VolumeType + " and had UID " + structure.StructureSer + "' (expected type 'PTV'; Structures with 'VB_', '_Ph' or '_EZ' are filtered out).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has type '" + structure.VolumeType + " and had UID " + structure.StructureSer + "' (expected type 'PTV'; Structures with 'VB_', '_Ph' or '_EZ' are filtered out).";
                        }

                        // Add the check only for the PTV and GTV
                        TestObject to_PTV = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);
                        tobjects.Add(to_PTV);

                    }

                    if (isNameGTV)
                    {
                        if (isTypeGTV)
                        {
                            status = CheckResult.PASSED;
                            comment = "Structure '" + structure.StructureId + "' has type '" + structure.VolumeType + "' (expected type 'GTV'; Structures with 'VB_', '_Ph' or '_EZ' are filtered out).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has type '" + structure.VolumeType + "' (expected type 'GTV'; Structures with 'VB_', '_Ph' or '_EZ' are filtered out).";
                        }

                        // Add the check only for the PTV and GTV
                        TestObject to_GTV = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);
                        tobjects.Add(to_GTV);
                    }



                }

            }
            return tobjects;
        }

        /// <summary>
        /// Structure HU override
        /// Override allowed only for Couch and high density
        /// Green for --> Couch, encompass
        /// Man rev for --> HighDensity, Flab, Manual OR
        /// Red for --> Rest
        /// </summary>
        internal List<TestObject> StructureHUValidator(List<Structure> structures)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Iterate over all the structures.
            foreach (Structure structure in structures)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.STRUCT;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structure.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.STRUCT.ToString() + ": " + structure.StructureId + " (" + structure.StructureStatus + ")";
                string comment = "Unknown";

                // Define the variables to check 
                bool isNameCouchIn = false;
                bool isNameCouchSu = false;
                bool isNameEncompa = false;
                bool isNameHighDensity = false;
                bool isNameFlab = false;
                bool isNameOR = false;

                bool hasHUOverride = false;

                // Retrive their values
                if (structure.StructureId.Length >= 9)
                {
                    if (structure.StructureId.Substring(0, 9).Equals("CouchInte")) { isNameCouchIn = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("CouchSurf")) { isNameCouchSu = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("Encompass")) { isNameEncompa = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("HighDensi")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("High dens")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("High_dens")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("Highdensi")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("high dens")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("highdensi")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("High_Dens")) { isNameHighDensity = true; }
                    if (structure.StructureId.Substring(0, 9).Equals("highdensi")) { isNameHighDensity = true; }
                }

                if (structure.StructureId.Length >= 5)
                {
                    if (structure.StructureId.Substring(0, 3).Equals("FL_")) { isNameFlab = true; }
                    if (structure.StructureId.Substring(0, 5).Equals("Bolus")) { isNameFlab = true; }
                    if (structure.StructureId.Substring(0, 3).Equals("OR_")) { isNameOR = true; }
                }



                if (structure.AssignedHU.Length >= 1)
                {
                    hasHUOverride = true;
                }

                // Logical three to check the parameters

                if (isNameCouchIn || isNameCouchSu || isNameEncompa || isNameHighDensity || isNameFlab || isNameOR)
                {
                    if (isNameCouchIn)
                    {
                        if (structure.AssignedHU.Equals("-1000"))
                        {
                            status = CheckResult.PASSED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -1000 for CouchInterior).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -1000 for CouchInterior).";
                        }
                    }

                    if (isNameCouchSu)
                    {
                        if (structure.AssignedHU.Equals("-432"))
                        {
                            status = CheckResult.PASSED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -432 for CouchSurface).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -432 for CouchSurface).";
                        }
                    }

                    if (isNameEncompa)
                    {
                        if (structure.AssignedHU.Equals("-999"))
                        {
                            status = CheckResult.PASSED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -999 for Encompass and Encompass Base).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected -999 for Encompass and Encompass Base).";
                        }
                    }


                    if (isNameHighDensity)
                    {
                        if (structure.AssignedHU.Length >= 4)
                        {
                            if (structure.AssignedHU.Substring(0, 4).Equals("3566") || structure.AssignedHU.Substring(0, 4).Equals("3567"))
                            {
                                status = CheckResult.MANREV;
                                comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected 3567±1 for HighDensity_Ph).";
                            }
                            else
                            {
                                status = CheckResult.FAILED;
                                comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected 3567±1 for HighDensity_Ph).";
                            }
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected 3567±1 for HighDensity_Ph).";
                        }


                    }

                    if (isNameFlab)
                    {
                        if (structure.AssignedHU.Equals("0"))
                        {
                            status = CheckResult.MANREV;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected 0 for Flab/Bolus).";
                        }
                        else
                        {
                            status = CheckResult.FAILED;
                            comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (expected 0 for Flab/Bolus).";
                        }
                    }


                    if (isNameOR)
                    {

                        status = CheckResult.MANREV;
                        comment = "Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (manual review required).";

                    }


                }
                else
                {
                    if (hasHUOverride)
                    {
                        status = CheckResult.FAILED;
                        comment = "Density override!!! Structure '" + structure.StructureId + "' has assigned HU '" + structure.AssignedHU + "' (fail for all structures with override except the ones in the list: Couch, Encompass, HighDensity_PH, FL_(xx)mm, Bolus_xxx, OR_xxx).";
                    }
                    else
                    {
                        status = CheckResult.PASSED;
                    }

                }

                if (hasHUOverride) { TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES); tobjects.Add(to); }


            }
            return tobjects;
        }


        /// <summary>
        /// Checks that if flab was added, also density HU=0 was assigned
        /// </summary>
        internal List<TestObject> StructureBolusValidator(List<Structure> structures)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Iterate over all the structures.
            foreach (Structure structure in structures)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.STRUCT;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structure.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.STRUCT.ToString() + ": " + structure.StructureId + " (" + structure.StructureStatus + ")";
                string comment = "Unknown";

                // Define the variables to check .
                bool isBolus = false;
                bool isHuZero = false;

                // Retrive their values
                if (structure.StructureId.StartsWith("FL_"))
                {
                    isBolus = true;
                }

                if (structure.AssignedHU.Length >= 1)
                {
                    if (structure.AssignedHU.Equals("0"))
                    {
                        isHuZero = true;
                    }
                    
                }

                // Logical three to check the parameters

                if (isBolus)
                {
                    if (isHuZero)
                    {
                        status = CheckResult.PASSED;
                        comment = "Structure '" + structure.StructureId + "' was identified as a Bolus added in planning and has assigned HU '" + structure.AssignedHU + "' (expected 0 for FL_(xx)mm ).";
                    } else
                    {
                        status = CheckResult.FAILED;
                        comment = "Structure '" + structure.StructureId + "' was identified as a Bolus added in planning and has assigned HU '" + structure.AssignedHU + "' (expected 0 for FL_(xx)mm ).";
                    }
                }


                if (isBolus) { TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES); tobjects.Add(to); }


            }
            return tobjects;
        }

        /// <summary>
        /// Structure resolution validation.
        /// PTV ITV GTV must be high resolution for SBRT plans
        /// </summary>
        internal List<TestObject> StructureResolutionValidator(List<Structure> structures)
        {
            List<TestObject> tobjects = new List<TestObject>();

            // Iterate over all the structures.
            foreach (Structure structure in structures)
            {

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.STRUCT;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structure.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structure.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.STRUCT.ToString() + ": " + structure.StructureId + " (" + structure.StructureStatus + ")";
                string comment = "Unknown";

                bool isNamePH = false;
                if (structure.StructureId.Length >= 3)
                {
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("PH")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("Ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("ph")) { isNamePH = true; }
                    if (structure.StructureId.Substring(structure.StructureId.Length - 2, 2).Equals("EZ")) { isNamePH = true; }
                }

                // only for SBRT SRS SRT plans
                if (structure.Plan.PlanSetupId.StartsWith("S"))
                {
                    // exclude phyciss structures 
                    if (!isNamePH)
                    {
                        // only for target volumes
                        if (structure.VolumeType.Equals("PTV") || structure.VolumeType.Equals("GTV") || structure.VolumeType.Equals("ITV"))
                        {

                            string resolution = structure.Resolution;
                            string resolutionsub = "";
                            if (resolution.Length >=5)
                            {
                                resolutionsub = structure.Resolution.Substring(0, 4);
                            }

                            if (resolution.StartsWith("0."))
                            {
                                status = CheckResult.PASSED;
                                comment = "Structure '" + structure.StructureId + "' has resolution " + resolutionsub + " mm (expected <1mm for target structures in SBRT SRT SRS plan).";

                            }
                            else if (resolution.StartsWith("1.") || resolution.StartsWith("2."))
                            {
                                status = CheckResult.FAILED;
                                comment = "Structure '" + structure.StructureId + "' has resolution " + resolutionsub + " mm (expected <1mm for target structures in SBRT SRT SRS plan, please convert to high resolution).";

                                // exception for SBRT accept up to 1.4mm
                                if (structure.Plan.PlanSetupId.StartsWith("SB"))
                                {
                                    if (resolution.StartsWith("1.0") || resolution.StartsWith("1.1") || resolution.StartsWith("1.2") || resolution.StartsWith("1.3"))
                                    {
                                        status = CheckResult.MANREV;
                                        comment = "Structure '" + structure.StructureId + "' has resolution " + resolutionsub + " mm (explected <1mm, but tollerance <1.4mm for target structures in SBRT, please check that this is a high resolution segment).";
                                    }
                                }

                            }
                            else
                            {
                                status = CheckResult.MANREV;
                                comment = "Failed to retreive resolution for structure '" + structure.StructureId + "' please check manually that is high resolution (expected <1mm for target structures in SBRT SRT SRS plan).";
                            }

                            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);
                            tobjects.Add(to);

                        }
                    }
                    
                }

            }
            return tobjects;
        }

        internal List<TestObject> CouchValidator(List<Structure> structures, Plan plan)
        {
            List<TestObject> tobjects = new List<TestObject>();

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.STRUCT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
            string rtInformation2 = RtGroup.PLAN.ToString() + ": " + plan.PlanSetupId;
            string comment = "Unknown";

            // Check if couch exists
            bool isCouchInserted = false;
            bool doesPlanNeedCouch = true;

            // Iterate over all the structures.
            foreach (Structure temp_structure in structures)
            {

                // Search for the couch
                if (temp_structure.StructureId.Length >= 9 && temp_structure.Plan.PlanSetupId.Equals(plan.PlanSetupId) && temp_structure.Plan.CourseId.Equals(plan.CourseId))
                {
                    if (temp_structure.StructureId.Substring(0, 9).Equals("CouchInte")) { isCouchInserted = true; }
                    if (temp_structure.StructureId.Substring(0, 9).Equals("CouchSurf")) { isCouchInserted = true; }


                }
            }

            // Decide if the plan needs a couch
            // always true except for SRS + SRT and brachy
            doesPlanNeedCouch = true;

            if (plan.PlanSetupId.StartsWith("SR")) { doesPlanNeedCouch = false; }
            if (plan.PlanSetupId.StartsWith("ST")) { doesPlanNeedCouch = false; }
            if (plan.PlanSetupId.StartsWith("ZY")) { doesPlanNeedCouch = false; }
            if (plan.PlanSetupId.StartsWith("BR")) { doesPlanNeedCouch = false; }

            // some exceptions of plans that may be treated on single fractions in regions that are not brain
            if (plan.PlanSetupId.StartsWith("SRpro")) { doesPlanNeedCouch = true; }
            if (plan.PlanSetupId.StartsWith("SRliv")) { doesPlanNeedCouch = true; }

            // Logic for check
            if (doesPlanNeedCouch)
            {
                if (isCouchInserted)
                {
                    status = CheckResult.PASSED;
                    comment = "IGRT Couch inserted for plan '" + plan.PlanSetupId + "' is correct (expected couch for all plans except treatments with BrainLab mask and brachy).";

                } else
                {
                    status = CheckResult.FAILED;
                    comment = "IGRT Couch not inserted for plan '" + plan.PlanSetupId + "' is not correct (expected couch for all plans except treatments with BrainLab mask and brachy).";
                }
            } else {
                if (isCouchInserted)
                {
                    status = CheckResult.FAILED;
                    comment = "IGRT Couch inserted for plan '" + plan.PlanSetupId + "' is not correct (expected couch for all plans except treatments with BrainLab mask and brachy).";

                }
                else
                {
                    status = CheckResult.PASSED;
                    comment = "IGRT Couch not inserted for plan '" + plan.PlanSetupId + "' is correct (expected couch for all plans except treatments with BrainLab mask and brachy).";
                }
            }


            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES); 
            tobjects.Add(to);


            return tobjects;



        }
    }
}













// Code not used:

//string displayNameUser = structure.StatusUserName;
//if (isOncologist_HardCoded)
//{
//    displayNameUser = oo.GetOncologistByUserName(structure.StatusUserName, OncologistOutput.ONCOLOGISTS).AliasName;
//}

//// Check if staff.
//if (!isOncologist_HardCoded)
//{
//    StaffOutput so = new StaffOutput();

//    bool isStaff = so.IsStaffByUserName(structure.StatusUserName, StaffOutput.STAFF);

//    if (isStaff)
//    {
//        displayNameUser = so.GetStaffByUserName(structure.StatusUserName, StaffOutput.STAFF).AliasName;
//    }
//}

