﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the radiation validator.
    /// </summary>
    class RadiationValidator : Validator
    {

        /// <summary>
        /// Start the validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            RadiationQuery qry = new RadiationQuery();

            List<Radiation> radiations = qry.GetRadiationData(patient);

            foreach (Radiation radiation in radiations)
            {
                // Active cases (only visible if validation type set to completed).
                if (type.Equals(ValidationType.ActiveCases))
                {
                   tobjects.Add(MachineAppointmentResourceValidator(radiation, patient)); 
                }
            }

            return tobjects;
        }

        /// <summary>
        /// Machine in radiation object vs appointment resource validation.
        /// Only open start appointments and active plans are validated.
        /// </summary>
        private TestObject MachineAppointmentResourceValidator(Radiation radiation, Patient patient)
        {
            int counter = 0;
           
            string machineId = radiation.MachineId;

            AppointmentDbOutput ao = new AppointmentDbOutput();

            // Get open start appointments.
            List<Appointment> appointments = ao.GetAppointments(patient);

            List<string> appResources = new List<string>();

            // Verify if not completed appointment machine matches radiation machine.
            foreach (Appointment a in appointments)
            {
                if ((!a.Machine.MachineId.Equals(machineId)) && (!radiation.CourseStatus.Equals("COMPLETED")))
                {
                    counter = counter + 1;
                }

                appResources.Add(a.Machine.MachineId);
            }

            // Get resource information.
            string appResourceInfo = getResourceInfo(appResources);

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.MACHINE;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + radiation.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + radiation.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + radiation.Plan.PlanSetupId + " (" + radiation.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + radiation.Plan.CourseId + ";" + RtGroup.MACHINE + ": " + radiation.MachineId;
            string comment = "Unknown";

            // No appointments available, active plan.
            if ((appointments.Count ==0) && (!radiation.CourseStatus.Equals("COMPLETED")))
            {
                status = CheckResult.FAILED;
                comment = "Machine plan vs. appointment resource for machine '" + machineId + "' and plan '" + radiation.Plan.PlanSetupId + "' not possible (no appointments available)!";
            }

            // Difference, active plan vs. appointment.
            if ((counter > 0) && (!radiation.CourseStatus.Equals("COMPLETED")))
            {
                status = CheckResult.FAILED;
                comment = "Machine plan vs. appointment resource for machine '" + machineId + "' and plan '" + radiation.Plan.PlanSetupId + "' does not equal scheduled appointment resource '" + appResourceInfo + "')!";
            }

            // No difference, active plan vs. appointment.
            if ((counter == 0) && (!radiation.CourseStatus.Equals("COMPLETED")))
            {
                status = CheckResult.MANREV;
                comment = "Machine plan vs. appointment resource for machine '" + machineId + "' and plan '" + radiation.Plan.PlanSetupId + "' equals scheduled appointment resource '" + appResourceInfo + "').";
            }

            // Not checked because no active plan.
            if (radiation.CourseStatus.Equals("COMPLETED"))
            {
                status = CheckResult.NOCHECK;
                editable = EditableStatus.NO;
                comment = "NO CHECK: Machine plan vs. appointment resource for machine '" + machineId + "' and plan '" + radiation.Plan.PlanSetupId + "' not validated (no active courses)!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

            return to;
        }

        /// <summary>
        /// Get resource information string.
        /// </summary>
        private string getResourceInfo(List<string> appresources)
        {
           appresources = appresources.Distinct().OrderBy(s => s).ToList();

           StringBuilder sb = new StringBuilder();

           foreach (string s in appresources)
           {
               sb.Append(s).Append("; ");
           }

           string output = sb.ToString();

            // Remove last instance of '; '
           if ((appresources.Count > 0) && (output.Length > 2))
           {
               output = output.Remove(output.Length - 2);
           }
            
           return output;
        }
    }
}