﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RtDataValidator.DAL.Tools;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the image slice validator.
    /// </summary>
    class ImageSliceValidator : Validator
    {

        /// <summary>
        /// Start the validator.
        /// </summary>
        public List<TestObject> GetValidationOutput( ValidationType type, Patient patient )
        {
            List<TestObject> tobjects = new List<TestObject>( );

            ImageSlicesQuery qry = new ImageSlicesQuery( );

            List<ImageSlice> slices = qry.GetImageSlices( patient );

            // Empty data set.
            if ( slices.Count == 0 )
            {
                TestObjectOutput too = new TestObjectOutput( );
                tobjects.Add( too.EmptyTestObject( RtGroup.IMAGE ) );
            }
            else
            {
                // Not implemented anymore since 28.08.2015 (slice separator is used and not thickness).
                // tobjects.AddRange(SliceThicknessValidator(slices));
                tobjects.AddRange( SliceSeparationValidator( slices ) );
                tobjects.AddRange( SliceCounterValidator( slices ) );
            }
            return tobjects;
        }

        /// <summary>
        /// Slice thickness validation.
        /// 1 or 2 mm is valid.
        /// Not implemented anymore since 28.08.2015 (slice separator is used and not thickness).
        /// </summary>
        [Obsolete( "Not implemented anymore since 28.08.2015 (slice separator is used and not thickness)" )]
        internal List<TestObject> SliceThicknessValidator( List<ImageSlice> slices )
        {
            List<TestObject> tobjects = new List<TestObject>( );

            List<string> planSetupIds = slices.Select( p => p.Plan.PlanSetupId ).Where( p => !p.Equals( "" ) ).Distinct( ).ToList( );

            foreach ( string planSetupId in planSetupIds )
            {

                List<ImageSlice> slicesfiltered = slices.Where( s => s.Plan.PlanSetupId.Equals( planSetupId ) ).Distinct( ).OrderBy( s => s.SliceNumber ).ToList( );

                ImageSlice slice1 = new ImageSlice( "", "", "", 0, 0, 0, new Plan( "", 0, "", "" ),"" );

                double thicknessSlice1 = 0;

                if ( slicesfiltered.Count > 0 )
                {
                    slice1 = slicesfiltered.ElementAt( 0 );
                    thicknessSlice1 = slice1.SliceThickness;
                }

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.IMAGE;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + slice1.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + slice1.Plan.PlanSetupId;
//                string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + slice1.Plan.PlanSetupId + " (" + slice1.Plan.PlanSetupStatus + ")";
                string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + slice1.Plan.CourseId + "; IMG SERIES: " + slice1.SeriesId + "; IMG ID: " + slice1.ImageId;
                string comment = "Unknown";

                // Radiosurgery plan.
                if ( ( slice1.Plan.IsRadioSurgeryPlan ) && ( slice1.SliceModality.Equals( "CT" ) ) )
                {
                    if ( ( slice1.SliceThickness == 0.75 ) || ( slice1.SliceThickness == 1 ) )
                    {
                        status = CheckResult.PASSED;
                        comment = "Slice thickness '" + slice1.SliceThickness.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' valid (expected slice thickness 0.75 or 1mm for SR plans).";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice thickness '" + slice1.SliceThickness.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' invalid (expected slice thickness 0.75 or 1mm for SR plans)!";
                    }
                }

                // All other plans (no SR plans).
                if ( ( !slice1.Plan.IsRadioSurgeryPlan ) && ( slice1.SliceModality.Equals( "CT" ) ) )
                {
                    if ( slice1.SliceThickness == 2 )
                    {
                        status = CheckResult.PASSED;
                        comment = "Slice thickness '" + slice1.SliceThickness.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' valid (expected slice thickness 2mm for none SR plans).";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice thickness '" + slice1.SliceThickness.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' invalid (expected slice thickness 2mm for none SR plans)!";
                    }
                }

                // No CT modality.
                if ( !slice1.SliceModality.Equals( "CT" ) )
                {
                    status = CheckResult.NOCHECK;
                    comment = "NO CHECK: Slice thickness '" + slice1.SliceThickness.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can only be validated for CT data sets.";
                }

                TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO );

                tobjects.Add( to );
            }
            return tobjects;
        }

        /// <summary>
        /// Slice separation validation.
        /// 1 or 2 mm is valid.
        /// </summary>
        internal List<TestObject> SliceSeparationValidator( List<ImageSlice> slices )
        {
            List<TestObject> tobjects = new List<TestObject>( );

            // Get unique plans.
            List<string> planSetupIds = slices.Select( p => p.Plan.PlanSetupId ).Where( p => !p.Equals( "" ) ).Distinct( ).ToList( );

            // Iterate over plans and validate slice separation between slices per plan .
            foreach ( string planSetupId in planSetupIds )
            {
                // Slices per plan.
                List<ImageSlice> slicesFiltered = slices.Where( s => s.Plan.PlanSetupId.Equals( planSetupId ) ).Distinct( ).OrderBy( s => s.SliceNumber ).ToList( );

                ImageSlice slice1 = new ImageSlice( "", "", "", 0, 0, 0, new Plan( "", 0, "", "" ), "");
                ImageSlice slice2 = new ImageSlice( "", "", "", 0, 0, 0, new Plan( "", 1, "", "" ), "");

                if ( slicesFiltered.Count >= 2 )
                {
                    slice1 = slicesFiltered.ElementAt( 10 );
                    slice2 = slicesFiltered.ElementAt( 11 );
                }

                double separation = 0;

                // Get separation between two subsequent slices.
                if ( slice2.SliceNumber == slice1.SliceNumber + 1 )
                {
                    separation = Math.Abs( slice1.Position - slice2.Position );
                    separation = Math.Round( separation, 2 );
                }

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.IMAGE;
                EditableStatus editable = EditableStatus.YES;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + slice1.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + slice1.Plan.PlanSetupId;
//                string rtInformation1 = RtGroup.PLAN.ToString( ) + ": " + slice1.Plan.PlanSetupId + " (" + slice1.Plan.PlanSetupStatus + ")";
                string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + slice1.Plan.CourseId + "; IMG SERIES: " + slice1.SeriesId + "; IMG ID: " + slice1.ImageId;
                string comment = "Unknown";

                // st/sr plan.
                if ( ( slice1.Plan.IsStereoNoBodyPlan ) && ( slice1.SliceModality.Equals( "CT" ) ) )
                {
                    if ( ( separation > 0 ) && ( separation <= 1 ) )
                    {
                        status = CheckResult.PASSED;
                        comment = "Slice separation '" + separation.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' valid (expected slice separation 0.75 or 1mm for ST plans).";
                    }
                    else if ( separation == 0)
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice separation check failed because there are two plans with identical ID. Please rename the plan in the z_Trial or N_Override course and repeat the test!";
                    }

                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice separation '" + separation.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' invalid (expected slice separation 0.75 or 1mm for ST plans)!";
                    }
                }

                // All other plans (no ST/SR plans).
                if ( ( !slice1.Plan.IsStereoNoBodyPlan ) && ( slice1.SliceModality.Equals( "CT" ) ) )
                {
                    if ( ( separation > 0 ) && ( separation <= 2 ) )
                    {
                        status = CheckResult.PASSED;
                        comment = "Slice separation '" + separation.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' valid (expected slice separation 2mm for non ST plans).";
                    }
                    else if (separation == 0)
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice separation check failed because there are two plans with identical ID. Please rename the plan in the z_Trial or N_Override course and repeat the test!";
                    }
                    else
                    {
                        status = CheckResult.FAILED;
                        comment = "Slice separation '" + separation.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' invalid (expected slice separation 2mm for non ST plans)!";
                    }
                }

                // No ct modality.
                if ( !slice1.SliceModality.Equals( "CT" ) )
                {
                    status = CheckResult.NOCHECK;
                    comment = "NO CHECK: Slice separation '" + separation.ToString( ) + "mm' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can only be validated for CT data sets.";
                }

                TestObject to = new TestObject( status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES );

                tobjects.Add( to );
            }

            return tobjects;
        }

        /// <summary>
        /// Slice counter validation.
        /// Less than 400 slices is valid. (Update 160912, MM)
        /// </summary>
        internal List<TestObject> SliceCounterValidator( List<ImageSlice> slices )
        { 

            int LimitSBRTSlices = 320;
            int LimitMODSlices = 375; // general limit for all the other plans
            int LimitSRSSlices = 400;
            int LimitBRASlices = 2000;

            List<TestObject> tobjects = new List<TestObject>( );

            List<string> planSetupIds = slices.Select(p => p.Plan.PlanSetupId).Where(p => !p.Equals("")).Distinct().ToList();

            // Iterate over plans.
            foreach ( string planSetupId in planSetupIds)
            {

                List<ImageSlice> slicesFiltered = slices.Where( s => s.Plan.PlanSetupId == planSetupId).Distinct( ).ToList( );

                ImageSlice slice1 = new ImageSlice( "", "", "", 0, 0, 0, new Plan( "", 0, "", "" ), "");

                // Get number of slices.
                int totalSlices = slicesFiltered.Count;

                if ( slicesFiltered.Count > 0 )
                {
                    slice1 = slicesFiltered.ElementAt( 0 );
                }

                CheckResult status = CheckResult.UNKNOWN;
                RtGroup rtGroup = RtGroup.IMAGE;
                EditableStatus editable = slice1.Plan.PlanSetupStatusEditable;
                string rtInformation0 = RtGroup.COURSE.ToString() + ": " + slice1.Plan.CourseId;
                string rtInformation1 = RtGroup.PLAN.ToString() + ": " + slice1.Plan.PlanSetupId;
                string rtInformation2 = RtGroup.COURSE.ToString( ) + ": " + slice1.Plan.CourseId + "; IMG SERIES: " + slice1.SeriesId + "; IMG ID: " + slice1.ImageId;
                string comment = "Unknown";

                bool isBrainPlan = false;
                bool isSBRTPlan = false;
                bool isCTExtOrShort = false;
                bool isBrachyPlan = false;

                // check if treating brain (only case in which exactrac is used)
                if (slice1.Plan.PlanSetupId.Length >= 6)
                {
                    if (Tools.PlanID_2_SiteAbbreviation(slice1.Plan.PlanSetupId).Equals("bra")) { isBrainPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("SR")) { isBrainPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("ST")) { isBrainPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("SB")) { isSBRTPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("RS")) { isSBRTPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("IS")) { isSBRTPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("BR")) { isBrachyPlan = true; }
                }

                if (slice1.Plan.PlanSetupId.Length >= 2)
                {
                    if (slice1.Plan.PlanSetupId.Substring(0, 2).Equals("ZY")) { isBrachyPlan = true; }
                }

                // check if the CT was extended or shortened
                if (slice1.ImageId.EndsWith("Sh") || slice1.ImageId.EndsWith("Sho") || slice1.ImageId.EndsWith("Ex") || slice1.ImageId.EndsWith("Ext") || slice1.ImageId.EndsWith("New") || slice1.ImageId.EndsWith("SHO") || slice1.ImageId.EndsWith("EXT"))
                {
                    isCTExtOrShort = true;
                }


                // Specific test for SRS / SRT / brain + exactrac

                if (isBrainPlan)
                {

                    if (!isCTExtOrShort)
                    {
                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices < LimitSRSSlices))
                        {
                            status = CheckResult.PASSED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' less than " + LimitSRSSlices.ToString() + " slices (expected < " + LimitSRSSlices.ToString() + " slices for SRS/SRT/BRA plans for ExacTrac (excluded CT edited ending with '_Sh' or '_Ex')).";
                        }

                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices >= LimitSRSSlices))
                        {
                            status = CheckResult.FAILED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' more than " + LimitSRSSlices.ToString() + " slices (expected < " + LimitSRSSlices.ToString() + " slices for SRS/SRT/BRA plans for ExacTrac (excluded CT edited ending with '_Sh' or '_Ex'))!";
                        }

                        if (!slice1.SliceModality.Equals("CT"))
                        {
                            status = CheckResult.NOCHECK;
                            comment = "NO CHECK: Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can not be validated (no CT modality).";
                        }
                    }
                    else
                    {
                        status = CheckResult.MANREV;
                        comment = "The image set '" + slice1.ImageId + "' of plan '" + slice1.Plan.PlanSetupId + "' has been extended or shortened (ends with '_Sh' or '_Ex').  Please check manually that N slices < 400 for SRS/SRT, < 320 for SBRT, < 375 for all rest";

                    }


                    TestObject to_ExacTrac = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                    tobjects.Add(to_ExacTrac);

                }
                else if (isSBRTPlan)  // check for SBRT plans
                {
                    if (!isCTExtOrShort)
                    {
                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices < LimitSBRTSlices))
                        {
                            status = CheckResult.PASSED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' less than " + LimitSBRTSlices.ToString() + " slices (expected < " + LimitSBRTSlices.ToString() + " slices for SBRT/RapidStereo/ImrtStereo plans (excluded CT edited ending with '_Sh' or '_Ex')).";
                        }

                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices >= LimitSBRTSlices))
                        {
                            status = CheckResult.FAILED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' more than " + LimitSBRTSlices.ToString() + " slices (expected < " + LimitSBRTSlices.ToString() + " slices for SBRT/RapidStereo/ImrtStereo plans (excluded CT edited ending with '_Sh' or '_Ex'))!";
                        }

                        if (!slice1.SliceModality.Equals("CT"))
                        {
                            status = CheckResult.NOCHECK;
                            comment = "NO CHECK: Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can not be validated (no CT modality).";
                        }
                    }
                    else
                    {
                        status = CheckResult.MANREV;
                        comment = "The image set '" + slice1.ImageId + "' of plan '" + slice1.Plan.PlanSetupId + "' has been extended or shortened (ends with '_Sh' or '_Ex'). Please check manually that N slices < 400 for SRS/SRT, < 320 for SBRT, < 375 for all rest";

                    }


                    TestObject to_ExacTrac = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                    tobjects.Add(to_ExacTrac);

                }
                else if (isBrachyPlan)  // check for Brachy plans
                {
                    if ((slice1.SliceModality.Equals("CT")) && (totalSlices < LimitBRASlices))
                    {
                        status = CheckResult.PASSED;
                        comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' less than " + LimitBRASlices.ToString() + " slices (expected < " + LimitBRASlices.ToString() + " slices for Brachy plans).";
                    }

                    if ((slice1.SliceModality.Equals("CT")) && (totalSlices >= LimitBRASlices))
                    {
                        status = CheckResult.FAILED;
                        comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' more than " + LimitBRASlices.ToString() + " slices (expected < " + LimitBRASlices.ToString() + " slices for Brachy plans).";
                    }

                    if (!slice1.SliceModality.Equals("CT"))
                    {
                        status = CheckResult.NOCHECK;
                        comment = "NO CHECK: Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can not be validated (no CT modality).";
                    }

                    TestObject to_Brachy = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                    tobjects.Add(to_Brachy);
                }
                else
                {

                    // general test for all the other plans

                    if (!isCTExtOrShort)
                    {
                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices < LimitMODSlices))
                        {
                            status = CheckResult.PASSED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' less than " + LimitMODSlices.ToString() + " slices (expected < " + LimitMODSlices.ToString() + " slices for CBCT matching (excluded CT edited ending with '_Sh' or '_Ex')).";
                        }

                        if ((slice1.SliceModality.Equals("CT")) && (totalSlices >= LimitMODSlices))
                        {
                            status = CheckResult.FAILED;
                            comment = "Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' more than " + LimitMODSlices.ToString() + " slices (expected < " + LimitMODSlices.ToString() + " slices for CBCT matching (excluded CT edited ending with '_Sh' or '_Ex')).";
                        }

                        if (!slice1.SliceModality.Equals("CT"))
                        {
                            status = CheckResult.NOCHECK;
                            comment = "NO CHECK: Number of slices '" + totalSlices.ToString() + "' for image set '" + slice1.ImageId + "' and modality '" + slice1.SliceModality + "' and plan '" + slice1.Plan.PlanSetupId + "' can not be validated (no CT modality).";
                        }
                    }
                    else
                    {
                        status = CheckResult.MANREV;
                        comment = "The image set '" + slice1.ImageId + "' of plan '" + slice1.Plan.PlanSetupId + "' has been extended or shortened (ends with '_Sh' or '_Ex').  Please check manually that N slices < 400 for SRS/SRT, < 320 for SBRT, < 375 for all rest";

                    }

                    TestObject to_CBCT = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.YES);

                    tobjects.Add(to_CBCT);

                }

            }
            return tobjects;
        }
    }
}