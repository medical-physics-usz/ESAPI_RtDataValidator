﻿using RtDataValidator.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.BLL
{
    /// <summary>
    /// Represents the structure set validator.
    /// </summary>
    class StructureSetValidator : Validator
    {

        /// <summary>
        /// Start structure set validator.
        /// </summary>
        public List<TestObject> GetValidationOutput(ValidationType type, Patient patient)
        {
            List<TestObject> tobjects = new List<TestObject>();

            StructureSetQuery qry = new StructureSetQuery();

            List<StructureSet> sets = qry.GetStructureSets(patient);

            // Empty data set.
            if (sets.Count == 0)
            {
                TestObjectOutput too = new TestObjectOutput();
                tobjects.Add(too.EmptyTestObject(RtGroup.STRUCT));
            }

            else
            {
                foreach (StructureSet structureset in sets)
                {
                    // tobjects.Add(StructureSetIdValidator(structureset)); // from 10.06.2021 using StructureSetIdImageIdValidator
                    tobjects.Add(StructureSetIdImageIdValidator(structureset));
                    tobjects.Add(StructureSetPhysicalMaterialTableValidator(structureset));
                }
            }
            return tobjects;
        }

        /// <summary>
        /// Structure set id validation.
        /// Format: {TreatmentSiteAbbreviation}_{DateStamp yy-MM-dd}
        /// Example: BRA_15-12-31.
        /// </summary>
        internal TestObject StructureSetIdValidator(StructureSet structureset)
        {

            bool isValidSetId = true;

            string sitevalue = "";
            string connector = "";
            string datestamp = "yy-MM-dd";

            // Example: BRA_15-12-31 is of length 12.
            if (structureset.StructureSetId.Length >= 12)
            {
                sitevalue = structureset.StructureSetId.Substring(0, 3);
                connector = structureset.StructureSetId.Substring(3, 1);
                datestamp = structureset.StructureSetId.Substring(4, 8);
            }

            XmlFileHandler xrSite = new XmlFileHandler();

            // Validate site abbreviation.
            bool isValidSite = xrSite.HasValueInXmlList(sitevalue, @"treatmentsites.xml", @"treatmentsites/treatmentsite/sitekey");

            // Validate connector between prefix and site.
            bool isValidConnector = false;

            if (connector.Equals("_"))
            {
                isValidConnector = true;
            }

            // Validate date format.
            bool isValidDateFormat = GenOperations.IsValidDateFormat(datestamp);

            if ((!isValidSite) || (!isValidConnector) || (!isValidDateFormat))
            {
                isValidSetId = false;
            }

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.STRUCT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId + " (" + structureset.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId + "; " + RtGroup.STRUCT.ToString() + ": " + structureset.StructureSetId;
            string comment = "Unknown";

            if (!isValidSetId)
            {
                status = CheckResult.FAILED;
                comment = "Structure set id '" + structureset.StructureSetId + "' invalid (expected '{SiteAbbreviation}{_}{Date(yy-MM-dd)} OR QA_,Z_')!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Structure set id '" + structureset.StructureSetId + "' valid.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Validate the ID of the structure set
        /// From 10.06.2021: it will be called as the image (eg. CT_21-06-10)
        /// </summary>
        internal TestObject StructureSetIdImageIdValidator(StructureSet structureset)
        {

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.STRUCT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId + " (" + structureset.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId + "; " + RtGroup.STRUCT.ToString() + ": " + structureset.StructureSetId;
            string comment = "Unknown";

            // check variable
            bool isValid = false;

            // evaluate only the first 11 characters
            string imageIdSubStr = "";
            string strucIdSubStr = "";

            // Example: CT_15-12-31 is of length 11.
            if (structureset.StructureSetId.Equals(structureset.ImageId))
            {
                isValid = true;
            }


            if (!isValid)
            {
                status = CheckResult.FAILED;
                comment = "Structure set id '" + structureset.StructureSetId + "' invalid (expected same id as the image " + structureset.ImageId + " and both need to be in the format CT_yy-mm-aa)!";
            }
            else
            {
                status = CheckResult.PASSED;
                comment = "Structure set id '" + structureset.StructureSetId + "' valid (expected same id as the image " + structureset.ImageId + " and both need to be in the format CT_yy-mm-aa)!";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;
        }

        /// <summary>
        /// Structure set physical material table validation.
        /// Needs to be set, cannot be empty.
        /// Implementation: MM, 161007
        /// </summary>
        internal TestObject StructureSetPhysicalMaterialTableValidator(StructureSet structureset)
        {
            // check whether physical material table is set
            bool isValidMaterialTable = !string.IsNullOrEmpty(structureset.PhysicalMaterialTable);

            CheckResult status = CheckResult.UNKNOWN;
            RtGroup rtGroup = RtGroup.STRUCT;
            EditableStatus editable = EditableStatus.YES;
            string rtInformation0 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId;
            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId;
//            string rtInformation1 = RtGroup.PLAN.ToString() + ": " + structureset.Plan.PlanSetupId + " (" + structureset.Plan.PlanSetupStatus + ")";
            string rtInformation2 = RtGroup.COURSE.ToString() + ": " + structureset.Plan.CourseId + "; " + RtGroup.STRUCT.ToString() + ": " + structureset.StructureSetId;
            string comment = "Unknown";

            if (isValidMaterialTable)
            {
                status = CheckResult.PASSED;
                comment = "Structure set '" + structureset.StructureSetId + "': Physical Material Table is set.";
            }
            else
            {
                status = CheckResult.FAILED;
                comment = "Structure set '" + structureset.StructureSetId + "': Physical Material Table is not set.";
            }

            TestObject to = new TestObject(status, rtGroup, editable, rtInformation0, rtInformation1, rtInformation2, comment, Printable.NO);

            return to;

        }   // internal TestObject StructureSetPhysicalMaterialTable(StructureSet structureset)
    }
}