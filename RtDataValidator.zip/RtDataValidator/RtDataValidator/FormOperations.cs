﻿using RtDataValidator.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RtDataValidator.UIL
{
    /// <summary>
    /// Represents the form operations.
    /// </summary>
    class FormOperations
    {

        public static bool ISVALIDPATIENT = false;
       
        public static readonly string NOPATIENTSELECTED = "No patient selected";

        public static readonly string LABELACTIVEVALIDATION = "ACTIVE VALIDATION";
        public static readonly string LABELCOMPLETEDVALIDATION = "COMPLETED VALIDATION";

        public static readonly string LABELALL = "ALL";
               
        public static readonly string LABELIMAGE = "IMAGE";
        public static readonly string LABELSTATUS = "STATUS";
        public static readonly string LABELGROUP = "RT-GROUP";
        public static readonly string LABELRTINFO1 = "PLAN OR ELEMENT";
        public static readonly string LABELRTINFO2 = "ADDITIONAL INFORMATION";
        public static readonly string LABELCOMMENT = "COMMENT";

        // Global patient id (used if loaded with Eclipse script).
        public static string PATIENTIDGLOBAL = "";

        // Global plan id (used if loaded with Eclipse script).
        public static string PLANSETUPIDGLOBAL = "";

        // Global course id (used if loaded with Eclipse script).
        public static string COURSEIDGLOBAL = "";

        // Global user id (used if loaded with Eclipse script).
        public static string USERIDGLOBAL = "";

        // Global PTVs UID (used to identify the plan).
        public static string PTVUID = "";

        // Global plan status (used if loaded with Eclipse script).
        public static string PLANSETUPSTATUSGLOBAL = "";

        // Global list comment objects.
        public static List<TestObject> tobjectsGLOBAL = new List<TestObject>();

        /// <summary>
        /// Filter by status.
        /// </summary>
        public static List<TestObject> FilterStatus(string filter, List<TestObject> tobjects)
        {
            tobjects = tobjects.Where(m => m.CheckResult.ToString().Equals(filter) || (filter.Equals(FormOperations.LABELALL))).ToList();

            return tobjects;
        }

        /// <summary>
        /// Filter by rt group.
        /// </summary>
        public static List<TestObject> FilterRtGroup(string filter, List<TestObject> tobjects)
        {
            tobjects = tobjects.Where(m => m.RtGroup.ToString().Equals(filter) || (filter.Equals(FormOperations.LABELALL))).ToList();

            return tobjects;
        }

        /// <summary>
        /// Filter by rt information.
        /// </summary>
        public static List<TestObject> FilterRtInformation1(string filter, List<TestObject> tobjects)
        {

            tobjects = tobjects.Where(m => m.RtInformation1.Equals(filter) || (filter.Equals(FormOperations.LABELALL))).ToList();

            return tobjects;
        }

        /// <summary>
        /// Filter by Course and Plan ID information.
        /// </summary>
        public static List<TestObject> FilterByCoursePlanInformation(string filterCourse, string filterPlan, List<TestObject> tobjects)
        {

            tobjects = tobjects.Where(m => m.RtInformation0.Equals(filterCourse) || (filterCourse.Equals(FormOperations.LABELALL)) || m.RtInformation0.Equals(RtGroup.COURSE.ToString() + ": ALL") ).ToList();
            tobjects = tobjects.Where(m => m.RtInformation1.Equals(filterPlan) || (filterPlan.Equals(FormOperations.LABELALL)) || m.RtInformation1.Equals("1-" + RtGroup.PATIENT.ToString())).ToList();

            return tobjects;
        }

        /// <summary>
        /// Filter by rt information.
        /// </summary>
        public static List<TestObject> FilterRtInformation2(string filter, List<TestObject> tobjects)
        {

            tobjects = tobjects.Where(m => m.RtInformation2.Equals(filter) || (filter.Equals(FormOperations.LABELALL))).ToList();

            return tobjects;
        }

        /// <summary>
        /// Filter quick settings.
        /// Get alls test objects where status is not passed and is editable.
        /// If plan setup id is not empty, then filter as well by plan.
        /// </summary>
        public static List<TestObject> FilterQuickSettingsPlan(List<TestObject> tobjects)
        {
            if (FormOperations.PLANSETUPIDGLOBAL.Equals(""))
            {
                tobjects = tobjects.Where(m => !m.CheckResult.Equals(CheckResult.PASSED)).Where(m => !m.EditableStatus.Equals(EditableStatus.NO)).OrderBy(s => s.CheckResult).ToList();    
            }
            else
            {
                tobjects = tobjects.Where(m => !m.CheckResult.Equals(CheckResult.PASSED)).Where(m => !m.EditableStatus.Equals(EditableStatus.NO)).Where(p => p.RtInformation1.Contains(FormOperations.PLANSETUPIDGLOBAL) || p.RtInformation1.Contains("1-PATIENT") || p.RtInformation1.Contains("2-IMAGE")).OrderBy(s => s.CheckResult).ToList();
            }

            return tobjects;
        }

        /// <summary>
        /// Filter by plan setup id.
        /// </summary>
        public static List<TestObject> FilterByPlanSetupId(List<TestObject> tobjects)
        {
            if (FormOperations.PLANSETUPIDGLOBAL.Equals(""))
            {
                tobjects = tobjects.OrderBy(s => s.CheckResult).ToList();
            }
            else
            {
                tobjects = tobjects.Where(p => p.RtInformation1.Contains(FormOperations.PLANSETUPIDGLOBAL) || p.RtInformation1.Contains("1-PATIENT") || p.RtInformation1.Contains("2-IMAGE")).OrderBy(s => s.CheckResult).ToList();
            }

            return tobjects;
        }

        /// <summary>
        /// Get status information string for label.
        /// </summary>
        public static string GetStatusInformation(List<TestObject> tobjects)
        {

            StringBuilder sb = new StringBuilder();

            sb.Append("Total: ");
            sb.Append(tobjects.Count.ToString());
            sb.Append("; ");
            sb.Append("Passed: ");
            sb.Append(tobjects.Where(t => t.CheckResult.Equals(CheckResult.PASSED)).Count().ToString());
            sb.Append("; ");
            sb.Append("Failed: ");
            sb.Append(tobjects.Where(t => t.CheckResult.Equals(CheckResult.FAILED)).Count().ToString());
            sb.Append("; ");
            sb.Append("Manual Review: ");
            sb.Append(tobjects.Where(t => t.CheckResult.Equals(CheckResult.MANREV)).Count().ToString());
            sb.Append("; ");
            sb.Append("Not Checked: ");
            sb.Append(tobjects.Where(t => t.CheckResult.Equals(CheckResult.NOCHECK)).Count().ToString());
            sb.Append(".");
            
            return sb.ToString();
        }
    }
}
